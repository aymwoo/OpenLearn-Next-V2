
import { helper } from "./utils.js";
export default {
  manifest: { id: "ext-sample", name: "Sample Plugin", version: "1.0.0" },
  activate: async function(ctx) { ctx.activated = true; helper(); }
};
