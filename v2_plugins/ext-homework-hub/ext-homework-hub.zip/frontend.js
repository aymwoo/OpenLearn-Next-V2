// ============================================================
// ext-homework-hub 前端脚本
// 在 OpenLearn 微前端沙箱中运行，负责教师端和学生端的 UI 渲染
// ============================================================

// 样式常量 —— 统一维护，方便后续调整
const STYLE = {
  primaryColor: '#2563eb',
  successColor: '#16a34a',
  warningColor: '#ea580c',
  dangerColor: '#dc2626',
  bgGray: '#f9fafb',
  borderColor: '#e5e7eb',
  textPrimary: '#111827',
  textSecondary: '#6b7280',
  radius: '8px',
};

// 工具函数：创建带样式的 DOM 元素
function el(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  Object.entries(attrs).forEach(([k, v]) => {
    if (k === 'style' && typeof v === 'object') {
      Object.assign(e.style, v);
    } else if (k.startsWith('on') && typeof v === 'function') {
      e.addEventListener(k.slice(2).toLowerCase(), v);
    } else {
      e.setAttribute(k, v);
    }
  });
  children.forEach((c) => {
    if (typeof c === 'string') e.appendChild(document.createTextNode(c));
    else if (c instanceof Node) e.appendChild(c);
  });
  return e;
}

// ============================================================
// 教师面板
// ============================================================
async function renderTeacherPanel(domNode, frontendCtx) {
  domNode.innerHTML = '';
  domNode.style.padding = '20px';
  domNode.style.fontFamily = 'system-ui, sans-serif';
  domNode.style.backgroundColor = '#fff';
  domNode.style.border = `1px solid ${STYLE.borderColor}`;
  domNode.style.borderRadius = '16px';
  domNode.style.boxShadow = '0 1px 3px 0 rgba(0, 0, 0, 0.05)';
  domNode.style.boxSizing = 'border-box';

  // ---------- 头部 ----------
  const header = el('div', {
    style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }
  },
    el('h2', { style: { margin: '0', fontSize: '20px', color: STYLE.textPrimary } }, '📋 作业中心'),
    el('button', {
      id: 'btn-new-assignment',
      style: {
        padding: '8px 16px', backgroundColor: STYLE.primaryColor, color: '#fff',
        border: 'none', borderRadius: STYLE.radius, cursor: 'pointer', fontSize: '14px'
      }
    }, '＋ 创建新作业')
  );
  domNode.appendChild(header);

  // ---------- 创建作业表单（默认隐藏） ----------
  const formContainer = el('div', {
    id: 'form-create-assignment',
    style: { display: 'none', marginBottom: '20px', padding: '16px', backgroundColor: STYLE.bgGray, borderRadius: STYLE.radius, border: `1px solid ${STYLE.borderColor}` }
  },
    el('h3', { style: { margin: '0 0 12px 0', fontSize: '16px' } }, '📝 创建新作业'),
    el('div', { style: { marginBottom: '10px' } },
      el('label', { style: { display: 'block', marginBottom: '4px', fontSize: '13px', color: STYLE.textSecondary } }, '作业标题'),
      el('input', { id: 'input-title', type: 'text', placeholder: '请输入作业标题', style: { width: '100%', padding: '8px', border: `1px solid ${STYLE.borderColor}`, borderRadius: '4px', fontSize: '14px', boxSizing: 'border-box' } })
    ),
    el('div', { style: { marginBottom: '10px' } },
      el('label', { style: { display: 'block', marginBottom: '4px', fontSize: '13px', color: STYLE.textSecondary } }, '作业描述'),
      el('textarea', { id: 'input-desc', placeholder: '请输入作业描述或要求', rows: '3', style: { width: '100%', padding: '8px', border: `1px solid ${STYLE.borderColor}`, borderRadius: '4px', fontSize: '14px', resize: 'vertical', boxSizing: 'border-box' } })
    ),
    el('div', { style: { marginBottom: '12px' } },
      el('label', { style: { display: 'block', marginBottom: '4px', fontSize: '13px', color: STYLE.textSecondary } }, '截止时间（可选）'),
      el('input', { id: 'input-deadline', type: 'datetime-local', style: { padding: '8px', border: `1px solid ${STYLE.borderColor}`, borderRadius: '4px', fontSize: '14px' } })
    ),
    el('div', { style: { display: 'flex', gap: '8px' } },
      el('button', {
        id: 'btn-submit-create',
        style: { padding: '8px 20px', backgroundColor: STYLE.successColor, color: '#fff', border: 'none', borderRadius: STYLE.radius, cursor: 'pointer', fontSize: '14px' }
      }, '✅ 发布作业'),
      el('button', {
        id: 'btn-cancel-create',
        style: { padding: '8px 20px', backgroundColor: '#fff', color: STYLE.textSecondary, border: `1px solid ${STYLE.borderColor}`, borderRadius: STYLE.radius, cursor: 'pointer', fontSize: '14px' }
      }, '取消')
    )
  );
  domNode.appendChild(formContainer);

  // ---------- 作业列表容器 ----------
  const listContainer = el('div', { id: 'assignment-list' });
  domNode.appendChild(listContainer);

  // ---------- 消息提示区 ----------
  const msgBox = el('div', { id: 'msg-box', style: { marginTop: '12px' } });
  domNode.appendChild(msgBox);

  // ---------- 事件绑定 ----------
  // 显示/隐藏创建表单
  domNode.querySelector('#btn-new-assignment').addEventListener('click', () => {
    formContainer.style.display = 'block';
  });
  domNode.querySelector('#btn-cancel-create').addEventListener('click', () => {
    formContainer.style.display = 'none';
    formContainer.querySelector('#input-title').value = '';
    formContainer.querySelector('#input-desc').value = '';
    formContainer.querySelector('#input-deadline').value = '';
  });

  // 创建作业
  const submitBtn = domNode.querySelector('#btn-submit-create');
  submitBtn.addEventListener('click', async () => {
    if (submitBtn.disabled) return;
    const title = domNode.querySelector('#input-title').value.trim();
    const description = domNode.querySelector('#input-desc').value.trim();
    const deadline = domNode.querySelector('#input-deadline').value;

    if (!title) {
      showMessage(msgBox, '请输入作业标题', 'warn');
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = '⏳ 发布中...';
    try {
      await frontendCtx.invokeCommand('create_assignment', { title, description, deadline });
      showMessage(msgBox, `作业「${title}」发布成功！`, 'success');
      formContainer.style.display = 'none';
      domNode.querySelector('#input-title').value = '';
      domNode.querySelector('#input-desc').value = '';
      domNode.querySelector('#input-deadline').value = '';
      await loadAssignmentList(listContainer, frontendCtx, msgBox, 'teacher');
    } catch (err) {
      showMessage(msgBox, `创建失败: ${err.message}`, 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = '✅ 发布作业';
    }
  });

  // 初始加载
  await loadAssignmentList(listContainer, frontendCtx, msgBox, 'teacher');
}

// ============================================================
// 学生面板
// ============================================================
async function renderStudentPanel(domNode, frontendCtx) {
  domNode.innerHTML = '';
  domNode.style.padding = '16px';
  domNode.style.fontFamily = 'system-ui, sans-serif';

  const header = el('h2', { style: { margin: '0 0 16px 0', fontSize: '20px', color: STYLE.textPrimary } }, '📖 我的作业');
  domNode.appendChild(header);

  const listContainer = el('div', { id: 'student-assignment-list' });
  domNode.appendChild(listContainer);

  const msgBox = el('div', { id: 'student-msg-box', style: { marginTop: '12px' } });
  domNode.appendChild(msgBox);

  await loadAssignmentList(listContainer, frontendCtx, msgBox, 'student');
}

// ============================================================
// 共用：加载作业列表
// ============================================================
async function loadAssignmentList(container, frontendCtx, msgBox, role) {
  container.innerHTML = '<p style="color:#9ca3af; text-align:center; padding:24px;">⏳ 加载中...</p>';

  try {
    const data = await frontendCtx.invokeCommand('list_assignments', { role });
    const assignments = data.assignments || [];

    if (assignments.length === 0) {
      container.innerHTML = '<p style="color:#9ca3af; text-align:center; padding:32px;">📭 暂无作业</p>';
      return;
    }

    container.innerHTML = '';
    assignments.forEach((asgn) => {
      const card = buildAssignmentCard(asgn, frontendCtx, msgBox, role, container);
      container.appendChild(card);
    });
  } catch (err) {
    container.innerHTML = `<p style="color:${STYLE.dangerColor}; text-align:center; padding:24px;">加载失败: ${err.message}</p>`;
  }
}

// ============================================================
// 构建单条作业卡片
// ============================================================
function buildAssignmentCard(asgn, frontendCtx, msgBox, role, listContainer) {
  const submitted = asgn.submission !== null;
  const graded = submitted && asgn.submission && asgn.submission.score >= 0;

  let statusBadge = '';
  if (role === 'student') {
    if (graded) {
      statusBadge = `<span style="background:#dcfce7;color:#166534;padding:2px 8px;border-radius:12px;font-size:12px;">已批改 ${asgn.submission.score}分</span>`;
    } else if (submitted) {
      statusBadge = `<span style="background:#dbeafe;color:#1e40af;padding:2px 8px;border-radius:12px;font-size:12px;">已提交</span>`;
    } else {
      statusBadge = `<span style="background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:12px;font-size:12px;">待提交</span>`;
    }
  }

  const card = el('div', {
    style: {
      border: `1px solid ${STYLE.borderColor}`,
      borderRadius: STYLE.radius,
      padding: '14px',
      marginBottom: '12px',
      backgroundColor: '#fff',
    }
  });

  // 作业基本信息
  const infoHtml = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;">
      <div style="flex:1;">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
          <strong style="font-size:15px;color:${STYLE.textPrimary};">${escapeHtml(asgn.title)}</strong>
          ${statusBadge}
        </div>
        ${asgn.description ? `<p style="margin:0 0 6px 0;font-size:13px;color:${STYLE.textSecondary};">${escapeHtml(asgn.description)}</p>` : ''}
        <div style="font-size:12px;color:${STYLE.textSecondary};">
          📅 发布时间: ${formatDate(asgn.createdAt)}
          ${asgn.deadline ? `&nbsp;&nbsp;⏰ 截止: ${formatDate(asgn.deadline)}` : ''}
          ${asgn.teacherId ? `&nbsp;&nbsp;👤 教师: ${escapeHtml(asgn.teacherId)}` : ''}
        </div>
      </div>
    </div>
  `;
  card.innerHTML = infoHtml;

  // ---------- 操作区 ----------
  const actions = el('div', { style: { marginTop: '10px', display: 'flex', gap: '8px', flexWrap: 'wrap' } });

  if (role === 'teacher') {
    // 教师操作按钮
    actions.appendChild(el('button', {
      style: btnStyle(STYLE.primaryColor),
      onClick: async () => {
        await toggleSubmissionList(card, asgn.id, frontendCtx, msgBox);
      }
    }, '📋 查看提交'));

    actions.appendChild(el('button', {
      style: btnStyle('#fff', STYLE.borderColor, STYLE.textPrimary),
      onClick: async () => {
        try {
          const r = await frontendCtx.invokeCommand('batch_download_urls', { assignmentId: asgn.id });
          if (!r.files || r.files.length === 0) {
            showMessage(msgBox, '暂无提交文件可下载', 'warn');
            return;
          }
          // 逐个触发下载
          r.files.forEach((f, i) => {
            setTimeout(() => window.open(f.downloadUrl, '_blank'), i * 300);
          });
          showMessage(msgBox, `开始下载 ${r.files.length} 个文件...`, 'success');
        } catch (err) {
          showMessage(msgBox, `下载失败: ${err.message}`, 'error');
        }
      }
    }, '📥 批量下载'));

    actions.appendChild(el('button', {
      style: btnStyle(STYLE.successColor),
      onClick: async () => {
        try {
          const r = await frontendCtx.invokeCommand('export_scores', { assignmentId: asgn.id });
          window.open(r.downloadUrl, '_blank');
          showMessage(msgBox, `成绩单已导出: ${r.fileName}`, 'success');
        } catch (err) {
          showMessage(msgBox, `导出失败: ${err.message}`, 'error');
        }
      }
    }, '📊 导出成绩'));

    // 统计信息
    actions.appendChild(el('span', {
      id: `stats-${asgn.id}`,
      style: { fontSize: '12px', color: STYLE.textSecondary, alignSelf: 'center', marginLeft: 'auto' }
    }, ''));
    // 异步加载统计
    frontendCtx.invokeCommand('get_stats', { assignmentId: asgn.id }).then((stats) => {
      const elm = card.querySelector(`#stats-${asgn.id}`);
      if (elm && stats) {
        elm.textContent = `已交 ${stats.totalSubmissions} | 已批 ${stats.gradedCount} | 均分 ${stats.averageScore ?? '-'}`;
      }
    }).catch(() => {});

  } else {
    // ---------- 学生操作区 ----------
    if (graded) {
      // 显示评分反馈
      const fb = el('div', {
        style: {
          marginTop: '8px', padding: '10px', backgroundColor: '#f0fdf4',
          borderRadius: '6px', border: '1px solid #bbf7d0'
        }
      });
      fb.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-weight:600;color:${STYLE.successColor};">✅ 得分: ${asgn.submission.score} 分</span>
          <span style="font-size:12px;color:${STYLE.textSecondary};">${formatDate(asgn.submission.submittedAt)}</span>
        </div>
        ${asgn.submission.feedback ? `<p style="margin:6px 0 0 0;font-size:13px;color:#374151;">💬 教师反馈: ${escapeHtml(asgn.submission.feedback)}</p>` : ''}
        <div style="margin-top:8px;padding-top:8px;border-top:1px dashed #bbf7d0;display:flex;justify-content:space-between;align-items:center;font-size:12px;color:${STYLE.textSecondary};">
          <span>📎 提交的文件: ${escapeHtml(asgn.submission.filename || '已提交')}</span>
          <div style="display:flex;gap:6px;">
            <button class="btn-preview-stu" style="${inlineBtnStyle(STYLE.primaryColor, 'transparent')}">👁️ 预览</button>
            <button class="btn-dl-stu" style="${inlineBtnStyle(STYLE.primaryColor, 'transparent')}">📥 下载</button>
          </div>
        </div>
      `;
      card.appendChild(fb);

      fb.querySelector('.btn-preview-stu').addEventListener('click', () => {
        openFilePreview(asgn.submission.filename, asgn.submission.filePath, frontendCtx);
      });
      fb.querySelector('.btn-dl-stu').addEventListener('click', () => {
        window.open(`/files${asgn.submission.filePath}`, '_blank');
      });
    }

    // 构造通用的文件上传 UI 区域
    const createUploadArea = (isReSubmit = false, onCancel = null) => {
      const uploadArea = el('div', {
        style: {
          marginTop: '12px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px'
        }
      });

      const fileInput = el('input', {
        type: 'file',
        id: `file-${asgn.id}-${isReSubmit ? 're' : 'init'}`,
        style: { display: 'none' }
      });

      const dropZone = el('div', {
        style: {
          border: `2px dashed ${STYLE.borderColor}`,
          borderRadius: '8px',
          padding: '20px 24px',
          textAlign: 'center',
          backgroundColor: '#fafafa',
          cursor: 'pointer',
          transition: 'all 0.2s ease',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '8px'
        },
        onDragOver: (e) => {
          e.preventDefault();
          dropZone.style.borderColor = STYLE.primaryColor;
          dropZone.style.backgroundColor = '#eff6ff';
        },
        onDragLeave: () => {
          dropZone.style.borderColor = STYLE.borderColor;
          dropZone.style.backgroundColor = '#fafafa';
        },
        onDrop: (e) => {
          e.preventDefault();
          dropZone.style.borderColor = STYLE.borderColor;
          dropZone.style.backgroundColor = '#fafafa';
          const files = e.dataTransfer?.files;
          if (files && files.length > 0) {
            fileInput.files = files;
            fileInput.dispatchEvent(new Event('change'));
          }
        },
        onClick: () => {
          fileInput.click();
        }
      });

      dropZone.addEventListener('mouseenter', () => {
        if (!fileInput.files?.length) {
          dropZone.style.borderColor = STYLE.primaryColor;
          dropZone.style.backgroundColor = '#f3f4f6';
        }
      });
      dropZone.addEventListener('mouseleave', () => {
        if (!fileInput.files?.length) {
          dropZone.style.borderColor = STYLE.borderColor;
          dropZone.style.backgroundColor = '#fafafa';
        }
      });

      const icon = el('span', { style: { fontSize: '28px' } }, '📁');
      const text = el('div', { style: { fontSize: '13px', color: STYLE.textSecondary, fontWeight: '500' } }, '点击或将作业文件拖拽到此处选择');
      const subText = el('div', { style: { fontSize: '11px', color: '#9ca3af' } }, '支持任意文件格式');

      dropZone.appendChild(icon);
      dropZone.appendChild(text);
      dropZone.appendChild(subText);

      const fileInfoRow = el('div', {
        style: {
          display: 'none',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: '10px 14px',
          backgroundColor: '#f3f4f6',
          borderRadius: '6px',
          border: `1px solid ${STYLE.borderColor}`,
          fontSize: '13px'
        }
      });

      const fileNameSpan = el('span', { style: { fontWeight: '500', color: STYLE.textPrimary, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginRight: '8px' } });
      const clearBtn = el('button', {
        style: {
          background: 'none',
          border: 'none',
          color: STYLE.dangerColor,
          cursor: 'pointer',
          fontSize: '14px',
          padding: '2px 6px'
        },
        onClick: (e) => {
          e.stopPropagation();
          fileInput.value = '';
          fileInput.dispatchEvent(new Event('change'));
        }
      }, '❌');

      fileInfoRow.appendChild(fileNameSpan);
      fileInfoRow.appendChild(clearBtn);

      const actionRow = el('div', {
        style: {
          display: 'none',
          gap: '8px',
          alignItems: 'center',
          marginTop: '4px'
        }
      });

      const uploadBtn = el('button', {
        style: btnStyle(STYLE.primaryColor),
        onClick: async () => {
          if (uploadBtn.disabled) return;
          const file = fileInput.files?.[0];
          if (!file) {
            showMessage(msgBox, '请先选择文件', 'warn');
            return;
          }

          uploadBtn.disabled = true;
          uploadBtn.textContent = '⏳ 提交中...';
          try {
            const base64 = await readFileAsBase64(file);
            const base64Content = base64.split(',')[1];

            showMessage(msgBox, '正在提交...', 'info');
            await frontendCtx.invokeCommand('submit', {
              assignmentId: asgn.id,
              filename: file.name,
              fileContentBase64: base64Content
            });
            showMessage(msgBox, '✅ 提交成功！', 'success');
            setTimeout(() => loadAssignmentList(listContainer, frontendCtx, msgBox, 'student'), 800);
          } catch (err) {
            showMessage(msgBox, `提交失败: ${err.message}`, 'error');
          } finally {
            uploadBtn.disabled = false;
            uploadBtn.textContent = '📤 确认提交作业';
          }
        }
      }, '📤 确认提交作业');

      actionRow.appendChild(uploadBtn);

      if (isReSubmit && onCancel) {
        const cancelBtn = el('button', {
          style: btnStyle('#fff', STYLE.borderColor, STYLE.textSecondary),
          onClick: onCancel
        }, '取消');
        actionRow.appendChild(cancelBtn);
      }

      fileInput.addEventListener('change', () => {
        const file = fileInput.files?.[0];
        if (file) {
          fileNameSpan.textContent = `📄 ${file.name} (${(file.size / 1024).toFixed(1)} KB)`;
          fileInfoRow.style.display = 'flex';
          dropZone.style.display = 'none';
          actionRow.style.display = 'flex';
        } else {
          fileInfoRow.style.display = 'none';
          dropZone.style.display = 'flex';
          actionRow.style.display = 'none';
        }
      });

      uploadArea.appendChild(fileInput);
      uploadArea.appendChild(dropZone);
      uploadArea.appendChild(fileInfoRow);
      uploadArea.appendChild(actionRow);

      return uploadArea;
    };

    if (!submitted) {
      card.appendChild(createUploadArea(false));
    } else if (!graded) {
      const pendingArea = el('div', {
        style: { marginTop: '10px', display: 'flex', flexDirection: 'column', gap: '8px' }
      });

      const pendingStatus = el('div', {
        style: { padding: '10px', backgroundColor: '#eff6ff', borderRadius: '6px', fontSize: '13px', color: '#1e40af', border: '1px solid #bfdbfe', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }
      });
      pendingStatus.innerHTML = `
        <span style="font-weight:500;">📎 已交: ${escapeHtml(asgn.submission.filename || '已提交')}</span>
        <div style="display:flex;gap:6px;align-items:center;margin-left:auto;margin-right:10px;">
          <button class="btn-preview-stu-pending" style="${inlineBtnStyle('#1e40af', 'transparent')}">👁️ 预览</button>
          <button class="btn-dl-stu-pending" style="${inlineBtnStyle('#1e40af', 'transparent')}">📥 下载</button>
        </div>
        <span style="font-size:11px;color:#6b7280;">🕐 ${formatDate(asgn.submission.submittedAt)}</span>
      `;

      let reUploadArea = null;
      const reSubmitBtn = el('button', {
        style: btnStyle('#fff', STYLE.primaryColor, STYLE.primaryColor),
        onClick: () => {
          pendingStatus.style.display = 'none';
          reSubmitBtn.style.display = 'none';
          
          reUploadArea = createUploadArea(true, () => {
            reUploadArea.remove();
            pendingStatus.style.display = 'flex';
            reSubmitBtn.style.display = 'block';
          });
          pendingArea.appendChild(reUploadArea);
        }
      }, '🔄 重新提交');

      pendingArea.appendChild(pendingStatus);
      pendingArea.appendChild(reSubmitBtn);
      card.appendChild(pendingArea);

      pendingStatus.querySelector('.btn-preview-stu-pending').addEventListener('click', () => {
        openFilePreview(asgn.submission.filename, asgn.submission.filePath, frontendCtx);
      });
      pendingStatus.querySelector('.btn-dl-stu-pending').addEventListener('click', () => {
        window.open(`/files${asgn.submission.filePath}`, '_blank');
      });
    }
  }

  card.appendChild(actions);

  // 提交详情展开区（教师端用）
  const detailArea = el('div', {
    id: `detail-${asgn.id}`,
    style: { display: 'none', marginTop: '10px', borderTop: `1px solid ${STYLE.borderColor}`, paddingTop: '10px' }
  });
  card.appendChild(detailArea);

  return card;
}

// ============================================================
// 展开/收起作业的提交列表（教师端）
// ============================================================
async function toggleSubmissionList(card, assignmentId, frontendCtx, msgBox) {
  const detailArea = card.querySelector(`#detail-${assignmentId}`);
  if (!detailArea) return;

  // 如果已展开，就收起
  if (detailArea.style.display === 'block') {
    detailArea.style.display = 'none';
    detailArea.innerHTML = '';
    return;
  }

  detailArea.style.display = 'block';
  detailArea.innerHTML = '<p style="color:#9ca3af;text-align:center;padding:12px;">⏳ 加载提交记录...</p>';

  try {
    const data = await frontendCtx.invokeCommand('list_submissions', { assignmentId });
    const submissions = data.submissions || [];

    detailArea.innerHTML = '';
    if (submissions.length === 0) {
      detailArea.innerHTML = '<p style="color:#9ca3af;text-align:center;padding:16px;">暂无提交记录</p>';
      return;
    }

    submissions.forEach((sub) => {
      const isGraded = sub.score >= 0;
      const row = el('div', {
        style: {
          padding: '10px', marginBottom: '8px', backgroundColor: STYLE.bgGray,
          borderRadius: '6px', border: '1px solid ' + STYLE.borderColor, fontSize: '13px'
        }
      });

      row.innerHTML = `
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
          <div>
            <span style="font-weight:600;">👤 ${escapeHtml(sub.studentId)}</span>
            <span style="color:${STYLE.textSecondary};margin-left:8px;">📎 ${escapeHtml(sub.filename)}</span>
            <span style="color:${STYLE.textSecondary};margin-left:8px;">🕐 ${formatDate(sub.submittedAt)}</span>
            ${isGraded ? `<span style="background:#dcfce7;color:#166534;padding:2px 8px;border-radius:12px;margin-left:8px;">${sub.score}分</span>` : '<span style="background:#fef3c7;color:#92400e;padding:2px 8px;border-radius:12px;margin-left:8px;">待批改</span>'}
          </div>
          <div style="display:flex;gap:6px;align-items:center;">
            <button class="btn-preview" style="${inlineBtnStyle(STYLE.primaryColor)}">👁️ 预览</button>
            <button class="btn-dl" data-url="/files${encodeURIComponent(sub.filePath)}" style="${inlineBtnStyle(STYLE.primaryColor)}">📥 下载</button>
            <button class="btn-grade-toggle" style="${inlineBtnStyle(isGraded ? '#fff' : STYLE.warningColor, isGraded ? STYLE.borderColor : STYLE.warningColor)}">${isGraded ? '✏️ 修改评分' : '📝 评分'}</button>
          </div>
        </div>
      `;

      // 评分表单（默认隐藏）
      const gradeForm = el('div', {
        style: { display: 'none', marginTop: '8px', padding: '10px', backgroundColor: '#fff', borderRadius: '6px', border: `1px dashed ${STYLE.borderColor}` }
      });
      gradeForm.innerHTML = `
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
          <label style="font-size:13px;">得分:</label>
          <input type="number" class="input-score" min="0" max="100" value="${isGraded ? sub.score : ''}" placeholder="0-100" style="width:70px;padding:4px 8px;border:1px solid ${STYLE.borderColor};border-radius:4px;font-size:13px;">
          <label style="font-size:13px;">反馈:</label>
          <input type="text" class="input-feedback" value="${escapeHtml(sub.feedback || '')}" placeholder="评语..." style="flex:1;min-width:120px;padding:4px 8px;border:1px solid ${STYLE.borderColor};border-radius:4px;font-size:13px;">
          <button class="btn-grade-submit" style="${inlineBtnStyle(STYLE.successColor)}">✅ 提交评分</button>
        </div>
      `;
      row.appendChild(gradeForm);

      // 预览按钮事件
      row.querySelector('.btn-preview').addEventListener('click', () => {
        openFilePreview(sub.filename, sub.filePath, frontendCtx);
      });

      // 下载按钮事件
      row.querySelector('.btn-dl').addEventListener('click', () => {
        window.open(`/files${sub.filePath}`, '_blank');
      });

      // 评分切换
      row.querySelector('.btn-grade-toggle').addEventListener('click', () => {
        gradeForm.style.display = gradeForm.style.display === 'none' ? 'block' : 'none';
      });

      // 提交评分
      row.querySelector('.btn-grade-submit').addEventListener('click', async () => {
        const score = parseFloat(row.querySelector('.input-score').value);
        const feedback = row.querySelector('.input-feedback').value;

        if (isNaN(score) || score < 0 || score > 100) {
          showMessage(msgBox, '请输入 0-100 的有效分数', 'warn');
          return;
        }

        try {
          await frontendCtx.invokeCommand('grade', {
            submissionId: sub.id,
            score,
            feedback
          });
          showMessage(msgBox, '评分提交成功！', 'success');
          // 简单刷新显示
          gradeForm.style.display = 'none';
          setTimeout(() => toggleSubmissionList(card, assignmentId, frontendCtx, msgBox), 500);
        } catch (err) {
          showMessage(msgBox, `评分失败: ${err.message}`, 'error');
        }
      });

      detailArea.appendChild(row);
    });

  } catch (err) {
    detailArea.innerHTML = `<p style="color:${STYLE.dangerColor};text-align:center;">加载失败: ${err.message}</p>`;
  }
}

// ============================================================
// 工具函数
// ============================================================
function showMessage(msgBox, text, type) {
  const colors = {
    success: '#16a34a',
    error: '#dc2626',
    warn: '#ea580c',
    info: '#2563eb'
  };
  msgBox.innerHTML = `<div style="padding:8px 12px;border-radius:6px;font-size:13px;color:#fff;background-color:${colors[type] || colors.info};margin-bottom:8px;">${text}</div>`;
  setTimeout(() => { msgBox.innerHTML = ''; }, 4000);
}

// 动态加载本地脚本
function loadLocalScript(url) {
  return new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${url}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement('script');
    script.src = url;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`加载依赖库失败: ${url}`));
    document.head.appendChild(script);
  });
}

// 在线文件预览主逻辑
async function openFilePreview(filename, filePath, frontendCtx) {
  const ext = filename.split('.').pop().toLowerCase();
  const fileUrl = `/files${filePath}`;
  
  // 1. 创建全屏 Modal Overlay
  const overlay = el('div', {
    id: 'preview-modal-overlay',
    style: {
      position: 'fixed', top: '0', left: '0', width: '100vw', height: '100vh',
      backgroundColor: 'rgba(15, 23, 42, 0.75)', backdropFilter: 'blur(4px)',
      zIndex: '9999', display: 'flex', justifyContent: 'center', alignItems: 'center',
      fontFamily: 'system-ui, sans-serif'
    }
  });

  const modal = el('div', {
    style: {
      width: '90vw', height: '90vh', backgroundColor: '#fff', borderRadius: '12px',
      boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
      display: 'flex', flexDirection: 'column', overflow: 'hidden', border: '1px solid #334155'
    }
  });

  const header = el('div', {
    style: {
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '16px 24px', backgroundColor: '#1e293b', color: '#fff',
      borderBottom: '1px solid #334155', userSelect: 'none'
    }
  });

  const titleArea = el('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } });
  titleArea.innerHTML = `<span style="font-size: 18px; font-weight: 600;">👁️ 预览: ${escapeHtml(filename)}</span>`;

  const actionsArea = el('div', { style: { display: 'flex', gap: '10px' } });
  
  const dlBtn = el('button', {
    style: {
      padding: '6px 14px', backgroundColor: STYLE.primaryColor, border: 'none',
      color: '#fff', borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: '500'
    },
    onClick: () => window.open(fileUrl, '_blank')
  }, '📥 下载');

  const closeBtn = el('button', {
    style: {
      padding: '6px 14px', backgroundColor: '#475569', border: 'none',
      color: '#fff', borderRadius: '6px', cursor: 'pointer', fontSize: '13px', fontWeight: '500'
    },
    onClick: () => overlay.remove()
  }, '关闭');

  actionsArea.appendChild(dlBtn);
  actionsArea.appendChild(closeBtn);
  header.appendChild(titleArea);
  header.appendChild(actionsArea);
  modal.appendChild(header);

  const body = el('div', {
    style: { flex: '1', overflow: 'auto', padding: '24px', backgroundColor: '#f8fafc', position: 'relative' }
  });
  modal.appendChild(body);

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  // 2. 显示 Loading 状态
  const spinner = el('div', {
    style: {
      position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '12px'
    }
  });
  spinner.innerHTML = `
    <div style="width:40px;height:40px;border:4px solid #e2e8f0;border-top-color:${STYLE.primaryColor};border-radius:50%;animation:spin 1s linear infinite;"></div>
    <span style="color:#64748b;font-size:14px;font-weight:500;">正在加载文件内容...</span>
    <style>
      @keyframes spin { to { transform: rotate(360deg); } }
    </style>
  `;
  body.appendChild(spinner);

  try {
    const pluginDir = `/plugins/${frontendCtx.pluginId}`;

    // 3. 根据类型拉取数据并渲染
    if (ext === 'pdf') {
      spinner.remove();
      const iframe = el('iframe', {
        src: fileUrl,
        style: { width: '100%', height: '100%', border: 'none', borderRadius: '8px', backgroundColor: '#fff' }
      });
      body.appendChild(iframe);
      
    } else if (['png', 'jpg', 'jpeg', 'gif', 'svg', 'webp'].includes(ext)) {
      spinner.remove();
      const imgContainer = el('div', {
        style: {
          display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100%',
          backgroundImage: 'radial-gradient(#cbd5e1 20%, transparent 20%), radial-gradient(#cbd5e1 20%, transparent 20%)',
          backgroundPosition: '0 0, 8px 8px', backgroundSize: '16px 16px', backgroundColor: '#e2e8f0',
          borderRadius: '8px', padding: '20px'
        }
      });
      const img = el('img', {
        src: fileUrl,
        style: { maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', borderRadius: '4px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)' }
      });
      imgContainer.appendChild(img);
      body.appendChild(imgContainer);

    } else {
      const response = await fetch(fileUrl);
      if (!response.ok) throw new Error(`拉取文件数据失败: ${response.statusText}`);

      if (ext === 'py') {
        const text = await response.text();
        spinner.remove();
        
        const escaped = escapeHtml(text);
        const codeLines = escaped.split('\n').map((line, idx) => `
          <div style="display:flex;line-height:1.6;font-family:'Fira Code','JetBrains Mono',monospace;font-size:14px;">
            <span style="width:50px;color:#94a3b8;text-align:right;padding-right:16px;user-select:none;border-right:1px solid #e2e8f0;margin-right:16px;">${idx+1}</span>
            <span style="white-space:pre-wrap;color:#334155;">${line || ' '}</span>
          </div>
        `).join('');

        body.innerHTML = `
          <div style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:20px;overflow-x:auto;box-shadow:0 1px 3px rgba(0,0,0,0.05);">
            ${codeLines}
          </div>
        `;

      } else if (ext === 'docx') {
        const arrayBuffer = await response.arrayBuffer();
        await loadLocalScript(`${pluginDir}/libs/mammoth.browser.min.js`);
        spinner.remove();

        const result = await window.mammoth.convertToHtml({ arrayBuffer });
        body.innerHTML = `
          <div class="docx-preview-container" style="background:#fff;max-width:850px;margin:0 auto;padding:48px 60px;box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);border-radius:8px;border:1px solid #e2e8f0;font-family:'Microsoft YaHei',SimSun,serif;line-height:1.8;color:#1e293b;">
            ${result.value || '<p style="color:#94a3b8;text-align:center;">暂无可见文本内容</p>'}
          </div>
          <style>
            .docx-preview-container p { margin-bottom: 1.2em; font-size: 15px; }
            .docx-preview-container h1, .docx-preview-container h2, .docx-preview-container h3 { margin-top: 1.5em; margin-bottom: 0.5em; color: #0f172a; font-weight: 700; }
            .docx-preview-container h1 { font-size: 24px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; }
            .docx-preview-container h2 { font-size: 20px; }
            .docx-preview-container h3 { font-size: 17px; }
            .docx-preview-container table { border-collapse: collapse; width: 100%; margin: 16px 0; }
            .docx-preview-container th, .docx-preview-container td { border: 1px solid #cbd5e1; padding: 8px 12px; font-size: 14px; }
            .docx-preview-container tr:nth-child(even) { background-color: #f8fafc; }
            .docx-preview-container th { background-color: #f1f5f9; font-weight: 600; }
            .docx-preview-container ul, .docx-preview-container ol { padding-left: 20px; margin-bottom: 1.2em; }
          </style>
        `;

      } else if (ext === 'xlsx' || ext === 'xls') {
        const arrayBuffer = await response.arrayBuffer();
        await loadLocalScript(`${pluginDir}/libs/xlsx.full.min.js`);
        spinner.remove();

        const workbook = window.XLSX.read(arrayBuffer, { type: 'array' });
        
        let tabsHtml = '';
        let sheetsHtml = '';
        
        workbook.SheetNames.forEach((sheetName, idx) => {
          const isActive = idx === 0;
          tabsHtml += `
            <button class="sheet-tab-btn" data-sheet="${idx}" style="padding:10px 20px;border:none;background:${isActive ? '#fff' : '#f1f5f9'};color:${isActive ? STYLE.primaryColor : '#64748b'};font-weight:${isActive ? '600' : '500'};border-bottom:${isActive ? '3px solid ' + STYLE.primaryColor : 'none'};cursor:pointer;font-size:14px;border-top-left-radius:6px;border-top-right-radius:6px;transition:all 0.2s;">
              📊 ${escapeHtml(sheetName)}
            </button>
          `;
          const sheet = workbook.Sheets[sheetName];
          const htmlTable = window.XLSX.utils.sheet_to_html(sheet);
          sheetsHtml += `
            <div class="sheet-content" id="sheet-content-${idx}" style="display:${isActive ? 'block' : 'none'};overflow:auto;padding:20px;background:#fff;border-radius:8px;border:1px solid #e2e8f0;height:calc(100% - 60px);box-shadow:0 1px 3px rgba(0,0,0,0.05);">
              ${htmlTable}
            </div>
          `;
        });

        body.style.display = 'flex';
        body.style.flexDirection = 'column';
        body.style.gap = '12px';
        body.style.height = '100%';
        body.style.boxSizing = 'border-box';

        body.innerHTML = `
          <div class="sheet-tab-bar" style="display:flex;gap:4px;border-bottom:1px solid #e2e8f0;padding-left:10px;">
            ${tabsHtml}
          </div>
          <div style="flex:1;position:relative;height:100%;">
            ${sheetsHtml}
          </div>
          <style>
            .sheet-content table { border-collapse: collapse; min-width: 100%; font-size: 13px; color: #334155; }
            .sheet-content th, .sheet-content td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
            .sheet-content tr:nth-child(even) { background-color: #f8fafc; }
            .sheet-content th { background-color: #f1f5f9; font-weight: bold; color: #0f172a; }
          </style>
        `;

        const tabBtns = body.querySelectorAll('.sheet-tab-btn');
        tabBtns.forEach(btn => {
          btn.addEventListener('click', () => {
            const sheetIdx = btn.getAttribute('data-sheet');
            tabBtns.forEach(b => {
              b.style.background = '#f1f5f9';
              b.style.color = '#64748b';
              b.style.borderBottom = 'none';
              b.style.fontWeight = '500';
            });
            btn.style.background = '#fff';
            btn.style.color = STYLE.primaryColor;
            btn.style.borderBottom = `3px solid ${STYLE.primaryColor}`;
            btn.style.fontWeight = '600';

            body.querySelectorAll('.sheet-content').forEach(content => {
              content.style.display = 'none';
            });
            const activeContent = body.querySelector(`#sheet-content-${sheetIdx}`);
            if (activeContent) activeContent.style.display = 'block';
          });
        });

      } else if (ext === 'md') {
        const text = await response.text();
        spinner.remove();
        await loadLocalScript(`${pluginDir}/libs/marked.min.js`);

        const parsedHtml = window.marked.parse(text);
        body.innerHTML = `
          <div class="md-preview-container" style="background:#fff;max-width:850px;margin:0 auto;padding:40px;box-shadow:0 4px 6px -1px rgba(0,0,0,0.05);border-radius:8px;border:1px solid #e2e8f0;font-family:system-ui,sans-serif;line-height:1.6;color:#1e293b;">
            ${parsedHtml}
          </div>
          <style>
            .md-preview-container p { margin-bottom: 1em; font-size: 15px; }
            .md-preview-container h1, .md-preview-container h2, .md-preview-container h3 { margin-top: 1.5em; margin-bottom: 0.5em; color: #0f172a; font-weight: 700; }
            .md-preview-container h1 { font-size: 24px; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; }
            .md-preview-container h2 { font-size: 20px; }
            .md-preview-container h3 { font-size: 17px; }
            .md-preview-container pre { background-color: #f1f5f9; padding: 12px; border-radius: 6px; overflow-x: auto; font-family: monospace; }
            .md-preview-container code { background-color: #f1f5f9; padding: 2px 4px; border-radius: 4px; font-family: monospace; font-size: 90%; }
            .md-preview-container pre code { padding: 0; background-color: transparent; }
            .md-preview-container table { border-collapse: collapse; width: 100%; margin: 16px 0; }
            .md-preview-container th, .md-preview-container td { border: 1px solid #cbd5e1; padding: 8px 12px; font-size: 14px; }
            .md-preview-container tr:nth-child(even) { background-color: #f8fafc; }
            .md-preview-container th { background-color: #f1f5f9; font-weight: 600; }
            .md-preview-container blockquote { border-left: 4px solid #cbd5e1; padding-left: 16px; margin: 0 0 16px 0; color: #64748b; }
          </style>
        `;
      } else {
        throw new Error(`暂不支持文件类型: .${ext}`);
      }
    }
  } catch (err) {
    spinner.remove();
    body.innerHTML = `
      <div style="text-align:center;padding:48px;color:${STYLE.dangerColor};">
        <span style="font-size: 48px; display: block; margin-bottom: 16px;">⚠️</span>
        <span style="font-size: 16px; font-weight: 600;">预览失败</span>
        <p style="color:#64748b;font-size:14px;margin-top:8px;">${escapeHtml(err.message)}</p>
      </div>
    `;
  }
}

function formatDate(isoStr) {
  if (!isoStr) return '-';
  const d = new Date(isoStr);
  if (isNaN(d.getTime())) return isoStr;
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function escapeHtml(str) {
  if (!str) return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function readFileAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('文件读取失败'));
    reader.readAsDataURL(file);
  });
}

function btnStyle(bgColor, borderColor, textColor) {
  return {
    padding: '6px 14px',
    backgroundColor: bgColor,
    color: textColor || '#fff',
    border: borderColor ? `1px solid ${borderColor}` : 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '13px',
    whiteSpace: 'nowrap'
  };
}

function inlineBtnStyle(bgColor, borderColor) {
  return `padding:4px 10px;background-color:${bgColor};color:${borderColor && bgColor === '#fff' ? '#374151' : '#fff'};border:${borderColor ? `1px solid ${borderColor}` : 'none'};border-radius:4px;cursor:pointer;font-size:12px;`;
}

// ============================================================
// 教师大屏页面 (teacher.tab)
// ============================================================
async function renderTeacherTab(domNode, frontendCtx, context) {
  const { renderType, mainNavCollapsed } = context;

  if (renderType === 'button') {
    domNode.innerHTML = '';
    const isSelected = frontendCtx.navigation.getTeacherTab() === 'homework-tab-view';
    
    const btn = el('button', {
      id: 'sidebar-nav-btn-homework',
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        padding: '12px',
        width: '100%',
        border: 'none',
        borderRadius: STYLE.radius,
        cursor: 'pointer',
        transition: 'all 0.2s',
        backgroundColor: isSelected ? STYLE.primaryColor : 'transparent',
        color: isSelected ? '#fff' : '#475569',
        fontWeight: isSelected ? '600' : '500',
        justifyContent: mainNavCollapsed ? 'center' : 'flex-start',
        boxShadow: isSelected ? '0 4px 6px -1px rgba(37, 99, 235, 0.2)' : 'none',
        marginBottom: '4px'
      }
    });

    const iconSpan = el('span', { style: { fontSize: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center' } }, '📝');
    btn.appendChild(iconSpan);

    if (!mainNavCollapsed) {
      const textSpan = el('span', { style: { fontSize: '14px', fontFamily: 'sans-serif' } }, '作业大屏');
      btn.appendChild(textSpan);
    }

    btn.addEventListener('click', () => {
      frontendCtx.navigation.setTeacherTab('homework-tab-view');
    });

    frontendCtx.navigation.subscribeTeacherTab((activeTab) => {
      const isSelectedNow = activeTab === 'homework-tab-view';
      const button = domNode.querySelector('#sidebar-nav-btn-homework');
      if (button) {
        button.style.backgroundColor = isSelectedNow ? STYLE.primaryColor : 'transparent';
        button.style.color = isSelectedNow ? '#fff' : '#475569';
        button.style.fontWeight = isSelectedNow ? '600' : '500';
        button.style.boxShadow = isSelectedNow ? '0 4px 6px -1px rgba(37, 99, 235, 0.2)' : 'none';
      }
    });

    domNode.appendChild(btn);
  } else {
    await renderTeacherTabPanel(domNode, frontendCtx);
  }
}

async function renderTeacherTabPanel(domNode, frontendCtx) {
  domNode.innerHTML = '';
  domNode.style.padding = '24px';
  domNode.style.fontFamily = 'system-ui, -apple-system, sans-serif';
  domNode.style.display = 'flex';
  domNode.style.flexDirection = 'column';
  domNode.style.gap = '20px';
  domNode.style.height = '100%';
  domNode.style.overflowY = 'auto';
  domNode.style.backgroundColor = '#f8fafc';

  const msgBox = el('div', { style: { padding: '8px', display: 'none', borderRadius: STYLE.radius, fontSize: '13px' } });
  
  // Header row
  const header = el('div', {
    style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: '0' }
  },
    el('h1', { style: { margin: '0', fontSize: '24px', fontWeight: '700', color: STYLE.textPrimary, display: 'flex', alignItems: 'center', gap: '8px' } }, '📝 作业管理与打分中心'),
    el('button', {
      id: 'btn-show-create-modal',
      style: {
        padding: '10px 18px',
        backgroundColor: STYLE.primaryColor,
        color: '#fff',
        border: 'none',
        borderRadius: STYLE.radius,
        cursor: 'pointer',
        fontSize: '14px',
        fontWeight: '600',
        boxShadow: '0 4px 6px -1px rgba(37, 99, 235, 0.2)'
      },
      onClick: () => {
        const modal = domNode.querySelector('#create-asgn-modal');
        if (modal) modal.style.display = 'flex';
      }
    }, '➕ 发布新作业')
  );
  domNode.appendChild(header);
  domNode.appendChild(msgBox);

  // Modal for creating assignments
  const createModal = el('div', {
    id: 'create-asgn-modal',
    style: {
      position: 'fixed',
      top: '0', left: '0', width: '100%', height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.4)',
      display: 'none',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: '1000'
    }
  });

  const modalContent = el('div', {
    style: {
      backgroundColor: '#fff',
      padding: '24px',
      borderRadius: '12px',
      width: '450px',
      boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)',
      display: 'flex',
      flexDirection: 'column',
      gap: '16px'
    }
  },
    el('h3', { style: { margin: '0', fontSize: '18px', fontWeight: '700', color: STYLE.textPrimary } }, '📋 发布新作业'),
    el('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } },
      el('label', { style: { fontSize: '13px', fontWeight: '500', color: STYLE.textSecondary } }, '作业标题 *'),
      el('input', { id: 'modal-input-title', type: 'text', placeholder: '例如：课后作业三 - 浮力计算', style: { padding: '8px 12px', border: '1px solid ' + STYLE.borderColor, borderRadius: '6px', fontSize: '13px' } })
    ),
    el('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } },
      el('label', { style: { fontSize: '13px', fontWeight: '500', color: STYLE.textSecondary } }, '作业要求/描述'),
      el('textarea', { id: 'modal-input-desc', placeholder: '写明具体作业要求、提交格式...', rows: '3', style: { padding: '8px 12px', border: '1px solid ' + STYLE.borderColor, borderRadius: '6px', fontSize: '13px', resize: 'vertical' } })
    ),
    el('div', { style: { display: 'flex', flexDirection: 'column', gap: '6px' } },
      el('label', { style: { fontSize: '13px', fontWeight: '500', color: STYLE.textSecondary } }, '截止日期'),
      el('input', { id: 'modal-input-deadline', type: 'datetime-local', style: { padding: '8px 12px', border: '1px solid ' + STYLE.borderColor, borderRadius: '6px', fontSize: '13px' } })
    ),
    el('div', { style: { display: 'flex', justifyContent: 'flex-end', gap: '12px', marginTop: '8px' } },
      el('button', {
        style: btnStyle('#fff', STYLE.borderColor, STYLE.textSecondary),
        onClick: () => { createModal.style.display = 'none'; }
      }, '取消'),
      el('button', {
        id: 'modal-btn-submit',
        style: btnStyle(STYLE.successColor),
        onClick: async () => {
          const submitBtn = createModal.querySelector('#modal-btn-submit');
          if (submitBtn.disabled) return;
          const title = createModal.querySelector('#modal-input-title').value.trim();
          const description = createModal.querySelector('#modal-input-desc').value.trim();
          const deadline = createModal.querySelector('#modal-input-deadline').value;

          if (!title) {
            alert('请输入作业标题');
            return;
          }

          submitBtn.disabled = true;
          submitBtn.textContent = '⏳ 发布中...';
          try {
            await frontendCtx.invokeCommand('create_assignment', { title, description, deadline });
            createModal.style.display = 'none';
            // Clear fields
            createModal.querySelector('#modal-input-title').value = '';
            createModal.querySelector('#modal-input-desc').value = '';
            createModal.querySelector('#modal-input-deadline').value = '';
            // Refresh
            await loadStatistics();
          } catch (err) {
            alert('发布失败: ' + err.message);
          } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = '✅ 确认发布';
          }
        }
      }, '✅ 确认发布')
    )
  );

  createModal.appendChild(modalContent);
  domNode.appendChild(createModal);

  // Cards Row
  const cardsRow = el('div', {
    style: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', flexShrink: '0' }
  });
  domNode.appendChild(cardsRow);

  // Workspace Split
  const workspace = el('div', {
    style: { display: 'grid', gridTemplateColumns: '320px 1fr', gap: '24px', flexGrow: '1', minHeight: '0' }
  });
  domNode.appendChild(workspace);

  // Left Column
  const leftCol = el('div', {
    style: { display: 'flex', flexDirection: 'column', gap: '12px', minHeight: '0' }
  });
  const searchInput = el('input', {
    type: 'text',
    placeholder: '🔍 搜索作业...',
    style: { padding: '10px 14px', border: '1px solid ' + STYLE.borderColor, borderRadius: STYLE.radius, fontSize: '13px', flexShrink: '0' }
  });
  const listContainer = el('div', {
    style: { flexGrow: '1', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '10px', paddingRight: '4px' }
  });
  leftCol.appendChild(searchInput);
  leftCol.appendChild(listContainer);
  workspace.appendChild(leftCol);

  // Right Column
  const rightCol = el('div', {
    style: { backgroundColor: '#fff', border: '1px solid ' + STYLE.borderColor, borderRadius: '12px', display: 'flex', flexDirection: 'column', minHeight: '0', overflow: 'hidden' }
  });
  workspace.appendChild(rightCol);

  let selectedAssignmentId = null;
  let allAssignments = [];

  // Function to load and render statistics
  async function loadStatistics() {
    listContainer.innerHTML = '<p style="color:#9ca3af;text-align:center;padding:24px;">⏳ 加载数据中...</p>';
    cardsRow.innerHTML = '';
    
    try {
      const stats = await frontendCtx.invokeCommand('get_statistics');
      allAssignments = stats.assignments || [];

      // Render cards
      const totalStudents = stats.totalStudents || 0;
      const subRate = stats.totalAssignments > 0 && totalStudents > 0 
        ? ((stats.totalSubmissions / (stats.totalAssignments * totalStudents)) * 100).toFixed(1)
        : '0.0';
      const gradingRate = stats.totalSubmissions > 0 
        ? ((stats.totalGraded / stats.totalSubmissions) * 100).toFixed(1)
        : '0.0';

      const createCard = (title, val, desc, color) => {
        return el('div', {
          style: {
            backgroundColor: '#fff', padding: '16px', borderRadius: '12px',
            border: '1px solid ' + STYLE.borderColor, boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05)'
          }
        },
          el('p', { style: { margin: '0', fontSize: '13px', fontWeight: '600', color: STYLE.textSecondary } }, title),
          el('h3', { style: { margin: '8px 0 4px 0', fontSize: '24px', fontWeight: '700', color: color || STYLE.textPrimary } }, val),
          el('p', { style: { margin: '0', fontSize: '11px', color: STYLE.textSecondary } }, desc)
        );
      };

      cardsRow.appendChild(createCard('发布作业数', stats.totalAssignments + ' 个', '课堂作业发布总数', '#1e293b'));
      cardsRow.appendChild(createCard('学生提交数', stats.totalSubmissions + ' 份', `全班共 ${totalStudents} 名学生，整体提交率 ${subRate}%`, STYLE.primaryColor));
      cardsRow.appendChild(createCard('平均成绩', stats.averageScore + ' 分', '全部已批改作业的平均得分', STYLE.successColor));
      cardsRow.appendChild(createCard('批改进度', gradingRate + '%', `已批改 ${stats.totalGraded} 份，剩余 ${stats.totalSubmissions - stats.totalGraded} 份待批改`, STYLE.warningColor));

      renderAssignmentList();
      
      // Auto select first assignment if none selected
      if (!selectedAssignmentId && allAssignments.length > 0) {
        selectAssignment(allAssignments[0].id);
      } else if (selectedAssignmentId) {
        selectAssignment(selectedAssignmentId);
      } else {
        renderRightColumnPlaceholder();
      }
    } catch (err) {
      listContainer.innerHTML = `<p style="color:${STYLE.dangerColor};text-align:center;padding:24px;">加载失败: ${err.message}</p>`;
    }
  }

  // Filter/render assignment list
  function renderAssignmentList() {
    const query = searchInput.value.trim().toLowerCase();
    listContainer.innerHTML = '';
    
    const filtered = allAssignments.filter(a => a.title.toLowerCase().includes(query));
    if (filtered.length === 0) {
      listContainer.innerHTML = '<p style="color:#9ca3af;text-align:center;padding:24px;">没有找到匹配的作业</p>';
      return;
    }

    filtered.forEach(asgn => {
      const isSelected = asgn.id === selectedAssignmentId;
      const card = el('div', {
        style: {
          padding: '14px', borderRadius: STYLE.radius, border: '1px solid ' + (isSelected ? STYLE.primaryColor : STYLE.borderColor),
          backgroundColor: isSelected ? '#f0fdf4' : '#fff', cursor: 'pointer', transition: 'all 0.2s',
          display: 'flex', flexDirection: 'column', gap: '6px',
          boxShadow: isSelected ? '0 4px 6px -1px rgba(34, 197, 94, 0.05)' : 'none'
        },
        onClick: () => selectAssignment(asgn.id)
      },
        el('h4', { style: { margin: '0', fontSize: '14px', fontWeight: '700', color: STYLE.textPrimary } }, asgn.title),
        el('div', { style: { display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: STYLE.textSecondary } },
          el('span', {}, `提交: ${asgn.subCount} 份`),
          el('span', {}, `平均分: ${asgn.avgScore} 分`)
        ),
        el('div', { style: { fontSize: '11px', color: STYLE.textSecondary } }, `截止时间: ${asgn.deadline ? formatDate(asgn.deadline) : '无'}`)
      );
      listContainer.appendChild(card);
    });
  }

  // Bind search input filter
  searchInput.addEventListener('input', renderAssignmentList);

  function renderRightColumnPlaceholder() {
    rightCol.innerHTML = `
      <div style="flex-grow:1;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#94a3b8;gap:12px;">
        <span style="font-size:48px;">👈</span>
        <span style="font-size:14px;font-weight:500;">请在左侧选择一个作业查看提交详情及批改</span>
      </div>
    `;
  }

  // Select an assignment and render details
  async function selectAssignment(id) {
    selectedAssignmentId = id;
    renderAssignmentList(); // Refresh selected state in list

    const asgn = allAssignments.find(a => a.id === id);
    if (!asgn) {
      renderRightColumnPlaceholder();
      return;
    }

    rightCol.innerHTML = '<p style="color:#9ca3af;text-align:center;padding:32px;">⏳ 加载作业详情...</p>';

    try {
      const data = await frontendCtx.invokeCommand('list_submissions', { assignmentId: id });
      const submissions = data.submissions || [];

      rightCol.innerHTML = '';
      
      // Right header
      const panelHeader = el('div', {
        style: { padding: '18px 24px', borderBottom: '1px solid ' + STYLE.borderColor, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: '0' }
      },
        el('div', { style: { display: 'flex', flexDirection: 'column', gap: '4px' } },
          el('h3', { style: { margin: '0', fontSize: '16px', fontWeight: '700', color: STYLE.textPrimary } }, asgn.title),
          el('p', { style: { margin: '0', fontSize: '12px', color: STYLE.textSecondary } }, `截止时间: ${asgn.deadline ? formatDate(asgn.deadline) : '无'}`)
        ),
        el('div', { style: { display: 'flex', gap: '8px' } },
          el('button', {
            style: {
              padding: '6px 12px', border: '1px solid ' + STYLE.borderColor, backgroundColor: '#fff',
              color: STYLE.textPrimary, borderRadius: '6px', fontSize: '12px', fontWeight: '600', cursor: 'pointer'
            },
            onClick: async () => {
              try {
                const res = await frontendCtx.invokeCommand('batch_download_urls', { assignmentId: id });
                if (!res.files || res.files.length === 0) {
                  alert('暂无学生提交文件，无法下载');
                  return;
                }
                // Open all URLs in sequence
                res.files.forEach(f => window.open(f.downloadUrl, '_blank'));
              } catch (e) {
                alert('批量下载失败: ' + e.message);
              }
            }
          }, '📥 批量下载'),
          el('button', {
            style: {
              padding: '6px 12px', border: 'none', backgroundColor: STYLE.successColor,
              color: '#fff', borderRadius: '6px', fontSize: '12px', fontWeight: '600', cursor: 'pointer'
            },
            onClick: () => {
              window.open(`/api/plugins/execute-command?type=ext-homework-hub.export_scores&assignmentId=${id}`, '_blank');
            }
          }, '📊 导出成绩')
        )
      );
      rightCol.appendChild(panelHeader);

      // Submissions table/list
      const tableContainer = el('div', {
        style: { flexGrow: '1', overflowY: 'auto', padding: '24px' }
      });
      rightCol.appendChild(tableContainer);

      if (submissions.length === 0) {
        tableContainer.innerHTML = '<p style="color:#9ca3af;text-align:center;padding:48px;">📭 暂无学生提交该作业</p>';
        return;
      }

      submissions.forEach(sub => {
        const isGraded = sub.score >= 0;
        const subRow = el('div', {
          style: {
            padding: '16px', marginBottom: '12px', backgroundColor: STYLE.bgGray,
            borderRadius: '8px', border: '1px solid ' + STYLE.borderColor,
            display: 'flex', flexDirection: 'column', gap: '10px'
          }
        });

        // Top line info
        const infoDiv = el('div', {
          style: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }
        },
          el('div', { style: { display: 'flex', alignItems: 'center', gap: '10px' } },
            el('span', { style: { fontWeight: '700', fontSize: '14px', color: STYLE.textPrimary } }, `👤 ${sub.studentName || '未命名'} (${sub.studentNumber || sub.studentId})`),
            isGraded
              ? el('span', { style: { backgroundColor: '#dcfce7', color: '#166534', padding: '2px 8px', borderRadius: '12px', fontSize: '11px', fontWeight: '600' } }, `${sub.score} 分`)
              : el('span', { style: { backgroundColor: '#fef3c7', color: '#92400e', padding: '2px 8px', borderRadius: '12px', fontSize: '11px', fontWeight: '600' } }, '待批改')
          ),
          el('div', { style: { display: 'flex', gap: '8px' } },
            el('button', {
              style: { padding: '4px 10px', backgroundColor: STYLE.primaryColor, border: 'none', color: '#fff', borderRadius: '4px', cursor: 'pointer', fontSize: '12px', fontWeight: '500' },
              onClick: () => openFilePreview(sub.filename, sub.filePath, frontendCtx)
            }, '👁️ 预览文件'),
            el('button', {
              style: { padding: '4px 10px', backgroundColor: '#fff', border: '1px solid ' + STYLE.borderColor, borderRadius: '4px', cursor: 'pointer', fontSize: '12px', color: STYLE.textPrimary },
              onClick: () => window.open(`/files${sub.filePath}`, '_blank')
            }, '📥 下载文件'),
            el('button', {
              style: { padding: '4px 10px', backgroundColor: isGraded ? '#fff' : STYLE.warningColor, border: isGraded ? '1px solid ' + STYLE.borderColor : 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '12px', color: isGraded ? STYLE.textPrimary : '#fff' },
              onClick: () => {
                const form = subRow.querySelector('.grading-form');
                if (form) form.style.display = form.style.display === 'none' ? 'block' : 'none';
              }
            }, isGraded ? '✏️ 修改评分' : '📝 评分')
          )
        );

        // File info & date
        const fileDiv = el('div', {
          style: { display: 'flex', gap: '16px', fontSize: '12px', color: STYLE.textSecondary }
        },
          el('span', {}, `📄 文件: ${sub.filename}`),
          el('span', {}, `提交于: ${formatDate(sub.submittedAt)}`)
        );

        // Graded score / feedback if exists
        const reviewDiv = el('div', {
          style: { display: isGraded ? 'block' : 'none', fontSize: '12px', backgroundColor: '#fff', padding: '8px 12px', borderRadius: '6px', border: '1px solid ' + STYLE.borderColor }
        },
          el('span', { style: { fontWeight: '600', color: STYLE.textPrimary } }, '老师评语: '),
          el('span', { style: { color: '#475569' } }, sub.feedback || '无评语')
        );

        // Grade submit form (hidden by default)
        const gradingForm = el('div', {
          className: 'grading-form',
          style: { display: 'none', padding: '12px', backgroundColor: '#fff', borderRadius: '6px', border: '1px dashed ' + STYLE.borderColor, marginTop: '4px' }
        },
          el('div', { style: { display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' } },
            el('label', { style: { fontSize: '13px', fontWeight: '500' } }, '评分:'),
            el('input', { type: 'number', className: 'grade-score-input', min: '0', max: '100', value: isGraded ? sub.score : '', placeholder: '0-100', style: { width: '80px', padding: '6px', border: '1px solid ' + STYLE.borderColor, borderRadius: '4px', fontSize: '13px' } }),
            el('label', { style: { fontSize: '13px', fontWeight: '500' } }, '评语:'),
            el('input', { type: 'text', className: 'grade-feedback-input', value: sub.feedback || '', placeholder: '输入评语...', style: { flexGrow: '1', minWidth: '150px', padding: '6px', border: '1px solid ' + STYLE.borderColor, borderRadius: '4px', fontSize: '13px' } }),
            el('button', {
              style: { padding: '6px 14px', backgroundColor: STYLE.successColor, border: 'none', color: '#fff', borderRadius: '4px', cursor: 'pointer', fontSize: '12px', fontWeight: '600' },
              onClick: async () => {
                const score = parseFloat(gradingForm.querySelector('.grade-score-input').value);
                const feedback = gradingForm.querySelector('.grade-feedback-input').value.trim();
                
                if (isNaN(score) || score < 0 || score > 100) {
                  alert('请输入 0 到 100 之间的有效得分');
                  return;
                }

                try {
                  await frontendCtx.invokeCommand('grade', { submissionId: sub.id, score, feedback });
                  await selectAssignment(id); // Reload assignment submissions
                  await loadStatistics(); // Reload cards and stats
                } catch (e) {
                  alert('评分失败: ' + e.message);
                }
              }
            }, '提交')
          )
        );

        subRow.appendChild(infoDiv);
        subRow.appendChild(fileDiv);
        subRow.appendChild(reviewDiv);
        subRow.appendChild(gradingForm);
        tableContainer.appendChild(subRow);
      });

    } catch (err) {
      rightCol.innerHTML = `<p style="color:${STYLE.dangerColor};text-align:center;padding:32px;">加载提交记录失败: ${err.message}</p>`;
    }
  }

  // Load everything
  await loadStatistics();
}

// ============================================================
// 主入口：注册教师面板、学生面板以及大屏Tab
// ============================================================
export default {
  activate: async (frontendCtx) => {
    // 1. 教师大屏 Tab
    frontendCtx.registerPanel({
      slot: 'teacher.tab',
      id: 'homework-tab-view',
      title: '作业中心大屏',
      render: async (domNode, context) => {
        await renderTeacherTab(domNode, frontendCtx, context);
      }
    });

    // 2. 教师快捷 Dashboard 卡片
    frontendCtx.registerPanel({
      slot: 'teacher.dashboard.widget',
      id: 'homework-teacher-widget',
      title: '作业中心',
      render: async (domNode) => {
        await renderTeacherPanel(domNode, frontendCtx);
      }
    });

    // 3. 学生侧边栏面板
    frontendCtx.registerPanel({
      slot: 'student.view',
      id: 'homework-student-view',
      title: '我的作业',
      render: async (domNode) => {
        await renderStudentPanel(domNode, frontendCtx);
      }
    });
  }
};

