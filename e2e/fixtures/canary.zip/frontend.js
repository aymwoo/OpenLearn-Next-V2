// server/__tests__/canary/canary-src/frontend.tsx
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
var frontend_default = {
  activate(ctx) {
    ctx.ui.registerExtensionPoint("teacher.tab", {
      id: "canary-tab",
      label: "\u91D1\u4E1D\u96C0",
      icon: "Bird",
      component: function CanaryTabPanel(props) {
        const [pingResult, setPingResult] = useState("\u7B49\u5F85\u8C03\u7528");
        const [loading, setLoading] = useState(false);
        const handlePing = async () => {
          setLoading(true);
          try {
            let res;
            if (typeof ctx.invokeCommand === "function") {
              res = await ctx.invokeCommand("canary.ping", { from: "frontend" });
            } else if (ctx.services?.frontendApi?.post) {
              res = await ctx.services.frontendApi.post("/api/plugins/execute-command", {
                type: "canary.ping",
                payload: { from: "frontend" }
              });
            } else {
              const fetchRes = await fetch("/api/plugins/execute-command", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ type: "canary.ping", payload: { from: "frontend" } })
              });
              res = await fetchRes.json();
            }
            setPingResult(JSON.stringify(res));
          } catch (e) {
            setPingResult(`\u9519\u8BEF: ${e?.message ?? e}`);
          } finally {
            setLoading(false);
          }
        };
        return /* @__PURE__ */ jsx("div", { "data-testid": "canary-teacher-tab-panel", className: "p-8 max-w-4xl mx-auto space-y-6", children: /* @__PURE__ */ jsxs("div", { className: "bg-white border rounded-2xl p-6 shadow-sm", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("span", { className: "text-2xl", children: "\u{1F424}" }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h1", { className: "text-xl font-bold text-gray-900", children: "\u91D1\u4E1D\u96C0\u63A2\u9488\u63A7\u5236\u53F0" }),
              /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-500", children: "\u5DF2\u6210\u529F\u901A\u8FC7 React \u6269\u5C55\u70B9\u6302\u8F7D\u5230\u6559\u5E08\u7AEF\u4E3B\u9762\u677F" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6 p-4 bg-gray-50 rounded-xl space-y-2 text-sm font-mono", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Props lessonId: " }),
              /* @__PURE__ */ jsx("span", { "data-testid": "canary-prop-lesson-id", className: "font-semibold", children: String(props?.lessonId ?? "null") })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Props classId: " }),
              /* @__PURE__ */ jsx("span", { "data-testid": "canary-prop-class-id", className: "font-semibold", children: String(props?.classId ?? "null") })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6 pt-6 border-t flex flex-col gap-3", children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                "data-testid": "canary-ping-button",
                onClick: handlePing,
                disabled: loading,
                className: "w-fit px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl transition shadow-sm disabled:opacity-50",
                children: loading ? "\u901A\u4FE1\u4E2D..." : "\u6D4B\u8BD5\u524D\u540E\u7AEF\u4E92\u901A (canary.ping)"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "text-sm", children: [
              /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "\u63A2\u9488\u56DE\u663E\u54CD\u5E94\uFF1A" }),
              /* @__PURE__ */ jsx("code", { "data-testid": "canary-ping-output", className: "px-2 py-1 bg-gray-100 rounded text-indigo-700 font-mono", children: pingResult })
            ] })
          ] })
        ] }) });
      }
    });
    ctx.ui.registerExtensionPoint("student.view", {
      id: "canary-student-view",
      label: "\u91D1\u4E1D\u96C0\u5B66\u751F\u9762\u677F",
      component: function CanaryStudentPanel(props) {
        return /* @__PURE__ */ jsxs("div", { "data-testid": "canary-student-panel", className: "p-4 bg-blue-50 border border-blue-200 rounded-xl", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-bold text-blue-900", children: "\u91D1\u4E1D\u96C0\u5B66\u751F\u7AEF\u63A2\u9488" }),
          /* @__PURE__ */ jsxs("p", { className: "text-sm text-blue-700", children: [
            "\u6CE8\u5165\u5B66\u751F ID: ",
            /* @__PURE__ */ jsx("span", { "data-testid": "canary-student-id", children: props?.studentId ?? "none" })
          ] })
        ] });
      }
    });
    ctx.ui.registerExtensionPoint("anchor:whiteboard-toolbar:rollcall", {
      id: "canary-anchor-rollcall-btn",
      label: "\u63A2\u9488\u951A\u70B9",
      position: 10,
      placement: "before",
      component: function CanaryAnchorButton(_props) {
        return /* @__PURE__ */ jsx(
          "button",
          {
            "data-testid": "canary-anchor-rollcall-btn",
            title: "\u63A2\u9488\u5FEB\u6377\u64CD\u4F5C",
            className: "p-2 rounded-xl text-indigo-600 bg-indigo-50 hover:bg-indigo-100 transition flex items-center justify-center text-xs",
            children: "\u{1F424}"
          }
        );
      }
    });
    ctx.ui.registerExtensionPoint("classroom.seating.toolbar", {
      id: "canary-seating-toolbar",
      label: "\u63A2\u9488\u673A\u623F\u6309\u94AE",
      component: function CanarySeatingToolbar(props) {
        return /* @__PURE__ */ jsx(
          "div",
          {
            "data-testid": "canary-seating-toolbar",
            className: "flex items-center gap-1.5 px-2.5 py-1 bg-indigo-50 border border-indigo-200 rounded-lg text-xs font-medium text-indigo-700 shadow-2xs",
            children: /* @__PURE__ */ jsxs("span", { children: [
              "\u{1F424} \u673A\u623F\u76D1\u63A7: ",
              props?.lab?.room_number ?? "\u672A\u6307\u5B9A"
            ] })
          }
        );
      }
    });
    ctx.ui.registerExtensionPoint("classroom.seating.legend", {
      id: "canary-seating-legend",
      label: "\u63A2\u9488\u56FE\u4F8B",
      component: function CanarySeatingLegend(_props) {
        return /* @__PURE__ */ jsxs("span", { "data-testid": "canary-seating-legend", className: "flex items-center gap-1.5 text-xs text-indigo-600 font-medium", children: [
          /* @__PURE__ */ jsx("span", { className: "w-2.5 h-2.5 rounded-full bg-indigo-500 shadow-xs" }),
          /* @__PURE__ */ jsx("span", { children: "\u63A2\u9488\u5C31\u7EEA" })
        ] });
      }
    });
    ctx.ui.registerExtensionPoint("classroom.seating.summary", {
      id: "canary-seating-summary",
      label: "\u63A2\u9488\u6C47\u603B",
      component: function CanarySeatingSummary(props) {
        return /* @__PURE__ */ jsxs(
          "div",
          {
            "data-testid": "canary-seating-summary",
            className: "col-span-full p-3 bg-gradient-to-r from-indigo-50 to-violet-50 border border-indigo-150 rounded-xl flex items-center justify-between text-xs text-indigo-950 font-sans shadow-2xs",
            children: [
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsx("span", { className: "text-base", children: "\u{1F424}" }),
                /* @__PURE__ */ jsx("span", { className: "font-bold", children: "\u91D1\u4E1D\u96C0\u5EA7\u4F4D\u63A2\u9488" })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4 font-mono", children: [
                /* @__PURE__ */ jsxs("span", { "data-testid": "canary-summary-total", children: [
                  "\u5DF2\u6392\u5EA7: ",
                  props?.stats?.assignedCount ?? 0
                ] }),
                /* @__PURE__ */ jsxs("span", { "data-testid": "canary-summary-class", children: [
                  "\u73ED\u7EA7: ",
                  props?.classId ?? "none"
                ] })
              ] })
            ]
          }
        );
      }
    });
    ctx.ui.registerExtensionPoint("classroom.seating.seat_badge", {
      id: "canary-seat-badge",
      label: "\u63A2\u9488\u5FBD\u7AE0",
      component: function CanarySeatBadge(props) {
        return /* @__PURE__ */ jsx(
          "span",
          {
            "data-testid": "canary-seat-badge",
            "data-student-id": props?.student?.id ?? "",
            className: "absolute -top-1 -right-1 text-xs select-none",
            title: `\u63A2\u9488\u6302\u8F7D: ${props?.student?.name ?? ""}`,
            children: "\u{1F424}"
          }
        );
      }
    });
    ctx.ui.registerExtensionPoint("whiteboard.autosave.status", {
      id: "canary-autosave-status",
      label: "\u63A2\u9488\u81EA\u52A8\u4FDD\u5B58\u72B6\u6001",
      component: function CanaryAutosaveStatus(props) {
        return /* @__PURE__ */ jsxs(
          "div",
          {
            "data-testid": "canary-autosave-status",
            className: "px-2.5 py-1 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-full text-xs font-medium flex items-center gap-1.5",
            children: [
              /* @__PURE__ */ jsx("span", { children: "\u{1F424} \u4E91\u7AEF\u955C\u50CF" }),
              /* @__PURE__ */ jsx("span", { "data-testid": "canary-autosave-lesson-id", className: "font-mono text-2xs", children: props?.lessonId ?? "none" })
            ]
          }
        );
      }
    });
    ctx.ui.registerExtensionPoint("whiteboard.autosave.action", {
      id: "canary-autosave-action",
      label: "\u63A2\u9488\u5373\u65F6\u5FEB\u7167",
      component: function CanaryAutosaveAction(props) {
        return /* @__PURE__ */ jsx(
          "button",
          {
            "data-testid": "canary-autosave-action-btn",
            onClick: () => props?.flush?.(),
            className: "px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border border-indigo-200 rounded-full text-xs font-bold transition cursor-pointer",
            children: "\u7ACB\u5373\u56FA\u5316"
          }
        );
      }
    });
  },
  deactivate(_ctx) {
  }
};
export {
  frontend_default as default
};
