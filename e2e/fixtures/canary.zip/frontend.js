// server/__tests__/canary/canary-src/frontend.tsx
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
var frontend_default = {
  activate(ctx) {
    ctx.ui.registerExtensionPoint("teacher.tab", {
      id: "canary-tab",
      label: "\u91D1\u4E1D\u96C0",
      icon: "Bird",
      component: function CanaryTabPanel(props) {
        const [pingResult, setPingResult] = useState("\u7B49\u5F85\u8C03\u7528");
        const [loading, setLoading] = useState(false);
        const handlePing = async () => {
          setLoading(true);
          try {
            let res;
            if (typeof ctx.invokeCommand === "function") {
              res = await ctx.invokeCommand("canary.ping", { from: "frontend" });
            } else if (ctx.services?.frontendApi?.post) {
              res = await ctx.services.frontendApi.post("/api/plugins/execute-command", {
                type: "canary.ping",
                payload: { from: "frontend" }
              });
            } else {
              const fetchRes = await fetch("/api/plugins/execute-command", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ type: "canary.ping", payload: { from: "frontend" } })
              });
              res = await fetchRes.json();
            }
            setPingResult(JSON.stringify(res));
          } catch (e) {
            setPingResult(`\u9519\u8BEF: ${e?.message ?? e}`);
          } finally {
            setLoading(false);
          }
        };
        return /* @__PURE__ */ jsx("div", { "data-testid": "canary-teacher-tab-panel", className: "p-8 max-w-4xl mx-auto space-y-6", children: /* @__PURE__ */ jsxs("div", { className: "bg-white border rounded-2xl p-6 shadow-sm", children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("span", { className: "text-2xl", children: "\u{1F424}" }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("h1", { className: "text-xl font-bold text-gray-900", children: "\u91D1\u4E1D\u96C0\u63A2\u9488\u63A7\u5236\u53F0" }),
              /* @__PURE__ */ jsx("p", { className: "text-sm text-gray-500", children: "\u5DF2\u6210\u529F\u901A\u8FC7 React \u6269\u5C55\u70B9\u6302\u8F7D\u5230\u6559\u5E08\u7AEF\u4E3B\u9762\u677F" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6 p-4 bg-gray-50 rounded-xl space-y-2 text-sm font-mono", children: [
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Props lessonId: " }),
              /* @__PURE__ */ jsx("span", { "data-testid": "canary-prop-lesson-id", className: "font-semibold", children: String(props?.lessonId ?? "null") })
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx("span", { className: "text-gray-400", children: "Props classId: " }),
              /* @__PURE__ */ jsx("span", { "data-testid": "canary-prop-class-id", className: "font-semibold", children: String(props?.classId ?? "null") })
            ] })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-6 pt-6 border-t flex flex-col gap-3", children: [
            /* @__PURE__ */ jsx(
              "button",
              {
                "data-testid": "canary-ping-button",
                onClick: handlePing,
                disabled: loading,
                className: "w-fit px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl transition shadow-sm disabled:opacity-50",
                children: loading ? "\u901A\u4FE1\u4E2D..." : "\u6D4B\u8BD5\u524D\u540E\u7AEF\u4E92\u901A (canary.ping)"
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "text-sm", children: [
              /* @__PURE__ */ jsx("span", { className: "text-gray-500", children: "\u63A2\u9488\u56DE\u663E\u54CD\u5E94\uFF1A" }),
              /* @__PURE__ */ jsx("code", { "data-testid": "canary-ping-output", className: "px-2 py-1 bg-gray-100 rounded text-indigo-700 font-mono", children: pingResult })
            ] })
          ] })
        ] }) });
      }
    });
    ctx.ui.registerExtensionPoint("student.view", {
      id: "canary-student-view",
      label: "\u91D1\u4E1D\u96C0\u5B66\u751F\u9762\u677F",
      component: function CanaryStudentPanel(props) {
        return /* @__PURE__ */ jsxs("div", { "data-testid": "canary-student-panel", className: "p-4 bg-blue-50 border border-blue-200 rounded-xl", children: [
          /* @__PURE__ */ jsx("h3", { className: "font-bold text-blue-900", children: "\u91D1\u4E1D\u96C0\u5B66\u751F\u7AEF\u63A2\u9488" }),
          /* @__PURE__ */ jsxs("p", { className: "text-sm text-blue-700", children: [
            "\u6CE8\u5165\u5B66\u751F ID: ",
            /* @__PURE__ */ jsx("span", { "data-testid": "canary-student-id", children: props?.studentId ?? "none" })
          ] })
        ] });
      }
    });
  },
  deactivate(_ctx) {
  }
};
export {
  frontend_default as default
};
