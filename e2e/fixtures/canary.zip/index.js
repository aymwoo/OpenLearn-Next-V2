// server/__tests__/canary/canary-src/index.ts
import * as sdk from "@openlearn/plugin-sdk";
import { IDatabaseToken } from "@openlearn/plugin-sdk";

// server/__tests__/canary/canary-src/contracts.ts
import { Token } from "@openlearn/plugin-sdk";
var CanaryProbeToken = new Token("ext-canary:ICanaryProbeService", "1.0.0");

// server/__tests__/canary/canary-src/index.ts
var REQUIRE_REJECT = ["xlsx", "fs", "lodash"];
var REQUIRE_OK = ["recharts", "react-markdown", "jspdf", "jspdf-autotable", "exceljs", "lucide-react", "uuid"];
var COUNTDOWN_TOKEN_NAME = "@openlearn/core:IClassroomCountdownService";
var index_default = {
  manifest: {
    id: "ext-canary",
    name: "\u91D1\u4E1D\u96C0\u63A2\u9488\u63D2\u4EF6",
    version: "1.0.0",
    main: "index.js"
  },
  activate: async (ctx) => {
    const results = /* @__PURE__ */ new Map();
    let eventCount = 0;
    let ticks = 0;
    let mode = "inline";
    const rawDb = await ctx.resolve(IDatabaseToken);
    let probeRow = rawDb.prepare("SELECT 1 AS one").get();
    if (probeRow instanceof Promise) {
      mode = "worker";
      probeRow = await probeRow;
    }
    async function probe(id, expected, fn) {
      let ok = false;
      let detail = "";
      try {
        detail = String(await fn());
        ok = true;
      } catch (e) {
        detail = e?.message ?? String(e);
      }
      results.set(id, { id, mode, ok, expected, detail: detail.slice(0, 2e3) });
      try {
        const tbl = ctx.db.table("probe_results");
        const prep = rawDb.prepare(`INSERT OR REPLACE INTO ${tbl} (id, mode, ok, expected, detail) VALUES (?,?,?,?,?)`);
        const runRes = prep.run(id, mode, ok ? 1 : 0, expected, detail.slice(0, 2e3));
        if (runRes instanceof Promise) await runRes;
      } catch {
      }
      return detail;
    }
    await ctx.db.ensureTable(
      "probe_results",
      "id TEXT PRIMARY KEY, mode TEXT, ok INTEGER, expected TEXT, detail TEXT"
    );
    await probe("2.1-pluginId", "ctx.pluginId \u975E\u7A7A\u5B57\u7B26\u4E32", () => {
      if (!ctx.pluginId) throw new Error("empty pluginId");
      return ctx.pluginId;
    });
    await probe("2.2-services", "services \u670D\u52A1\u96C6\u5408\u7B26\u5408\u5BF9\u5E94\u6A21\u5F0F\u89C4\u8303", () => {
      if (mode === "inline") {
        const keys = Object.keys(ctx.services).sort();
        const want = [
          "actionRegistry",
          "ai",
          "capability",
          "commandBus",
          "eventBus",
          "pointsDimension",
          "pointsLedger",
          "processManager",
          "storage"
        ];
        if (JSON.stringify(keys) !== JSON.stringify(want)) throw new Error(keys.join(","));
        return `keys=9, pointsDimension=${ctx.services.pointsDimension === null ? "null" : "set"}`;
      } else {
        return "keys=worker, pointsDimension=null";
      }
    });
    await probe("4.1-ensure-table", "\u81EA\u5EFA\u8868\u521B\u5EFA\u6210\u529F\u4E14\u5E26\u524D\u7F00", () => {
      return ctx.db.table("probe_results");
    });
    await probe("4.2-sql-identifier", "\u8868\u540D\u6CE8\u5165\u5FC5\u987B\u629B [SEC] Invalid SQL identifier", async () => {
      try {
        await ctx.db.ensureTable("canary-items", "id TEXT");
      } catch (e) {
        return `rejected:${e?.message ?? e}`;
      }
      throw new Error("unexpectedly created table with hyphen");
    });
    await probe("4.3-sql-semicolon", "schema \u5206\u53F7\u591A\u8BED\u53E5\u6CE8\u5165\u5FC5\u987B\u629B [SEC]", async () => {
      try {
        await ctx.db.ensureTable("canary_semi", "id TEXT; DROP TABLE users;");
      } catch (e) {
        return `rejected:${e?.message ?? e}`;
      }
      throw new Error("unexpectedly created table with semicolon");
    });
    await probe("4.4-sql-empty-schema", "\u7A7A schema \u5FC5\u987B\u629B [SEC]", async () => {
      try {
        await ctx.db.ensureTable("canary_empty", "");
      } catch (e) {
        return `rejected:${e?.message ?? e}`;
      }
      throw new Error("unexpectedly created table with empty schema");
    });
    await probe("4.7-db-exec", "exec \u8FD4\u56DE\u503C\uFF1Ainline \u4E3A\u540C\u6B65\uFF0Cworker \u4E3A Promise", async () => {
      const res = rawDb.exec?.("SELECT 1");
      const isPromise = res instanceof Promise;
      if (isPromise) await res;
      return isPromise ? "promise" : "sync";
    });
    await probe("4.8-db-transaction", "transaction \u652F\u6301\u60C5\u51B5\uFF1Ainline \u6709\uFF0Cworker \u65E0", async () => {
      return typeof rawDb.transaction === "function" ? "function" : "undefined";
    });
    let migrateRunCount = 0;
    await probe("4.10-db-migrate", "migrate \u5E42\u7B49\u6027\uFF1A\u540C\u4E00\u7248\u672C\u53EA\u6267\u884C\u4E00\u6B21 upgradeFn", async () => {
      const v = mode === "inline" ? 1 : 2;
      await ctx.db.migrate(v, async () => {
        migrateRunCount += 1;
      });
      await ctx.db.migrate(v, async () => {
        migrateRunCount += 1;
      });
      if (migrateRunCount !== 1) throw new Error(`migrate ran ${migrateRunCount} times`);
      return `ran:${migrateRunCount}`;
    });
    await probe("3.4-capabilities", "\u6743\u9650\u80FD\u529B\u63A2\u6D4B", async () => {
      const actorId = `plugin:${ctx.manifest?.id || "ext-canary"}`;
      const cap = ctx.services.capability;
      if (!cap || typeof cap.check !== "function") return "skipped";
      const read = await cap.check(actorId, "lesson:read");
      const control = await cap.check(actorId, "lesson:control");
      return `read:${Boolean(read)},control:${Boolean(control)}`;
    });
    await probe("6.1-provide", "ctx.provide \u5951\u7EA6\uFF1Ainline \u6CE8\u518C\u6210\u529F\uFF0Cworker \u8DF3\u8FC7", async () => {
      if (typeof ctx.provide === "function") {
        await ctx.provide(CanaryProbeToken, { ping: () => "pong" });
        return "provided";
      }
      return "worker:skipped";
    });
    const WORKER_ALLOWED_TOKENS = /* @__PURE__ */ new Set([
      "@openlearn/core:ICommandBusService",
      "@openlearn/core:IEventBusService",
      "@openlearn/core:IActionRegistryService",
      "@openlearn/core:ICapabilityService",
      "@openlearn/core:IProcessService",
      "@openlearn/core:IStorageService",
      "@openlearn/core:IAIService",
      "@openlearn/core:IDatabase",
      "@openlearn/core:IPluginHost"
    ]);
    const sdkEntries = Object.entries(sdk).filter(
      ([k, v]) => k.endsWith("Token") && v !== null && typeof v === "object" && typeof v.name === "string"
    );
    for (const [name, token] of sdkEntries) {
      const tokenName = token.name;
      const expectReject = name.includes("Countdown") || mode === "worker" && !WORKER_ALLOWED_TOKENS.has(tokenName);
      await probe(
        `2.5-token:${name}`,
        expectReject ? "\u5FC5\u987B\u5931\u8D25\uFF1ANo provider registered" : "\u5DF2\u6CE8\u518C\u670D\u52A1\u53EF\u89E3\u6790",
        async () => {
          try {
            const svc = await ctx.resolve(token);
            if (expectReject) throw new Error("unexpectedly resolved");
            return `resolved:${svc !== null && svc !== void 0}`;
          } catch (e) {
            if (expectReject) return `rejected:${e?.message ?? e}`;
            throw e;
          }
        }
      );
    }
    await probe("2.5-token:IClassroomCountdownServiceToken(synthetic)", "\u5FC5\u987B\u5931\u8D25\uFF1ANo provider registered", async () => {
      const t = new sdk.Token(COUNTDOWN_TOKEN_NAME);
      try {
        await ctx.resolve(t);
      } catch (e) {
        return `rejected:${e?.message ?? e}`;
      }
      throw new Error("unexpectedly resolved");
    });
    for (const m of REQUIRE_OK) {
      await probe(`6-require:${m}`, "\u767D\u540D\u5355\u5185\u53EF\u52A0\u8F7D", () => {
        const mod = ctx.require(m);
        return `required:${mod !== null && mod !== void 0}`;
      });
    }
    for (const m of REQUIRE_REJECT) {
      await probe(`6-require:${m}`, "\u767D\u540D\u5355\u5916\u5FC5\u987B\u629B Allowed modules \u6216\u5B89\u5168\u9519\u8BEF", () => {
        try {
          ctx.require(m);
        } catch (e) {
          return `rejected:${e?.message ?? e}`;
        }
        throw new Error("unexpectedly required");
      });
    }
    await ctx.services.commandBus.registerHandler("canary.ping", {
      execute: async (cmd) => {
        return { pong: true, mode, src: cmd?.payload?.src ?? "direct" };
      }
    });
    await ctx.services.eventBus.subscribe("lesson.created", () => {
      eventCount += 1;
    });
    if (mode === "inline" && ctx.services.processManager?.registerInterval) {
      await ctx.services.processManager.registerInterval("canary-heartbeat", 1e3, () => {
        ticks += 1;
      });
    } else {
      setInterval(() => {
        ticks += 1;
      }, 1e3);
    }
    ctx.http.get("/status", async () => ({
      ok: true,
      mode,
      pluginId: ctx.pluginId,
      dbProbe: probeRow?.one === 1 ? "ok" : "unexpected"
    }));
    ctx.http.get("/probes", async () => ({
      mode,
      eventCount,
      count: results.size,
      probes: [...results.values()]
    }));
    ctx.http.get("/items/:id", async (req) => ({ itemId: req.params.id, role: req.actor.role }));
    ctx.http.post("/echo", async (req) => ({ bytes: JSON.stringify(req.body ?? {}).length }));
    ctx.http.get("/public", async () => ({ public: true }));
    ctx.http.get("/ticks", async () => ({ ticks }));
  },
  deactivate: async () => {
  }
};
export {
  index_default as default
};
