// packages/core/di/errors.ts
var TokenError = class extends Error {
  constructor(message) {
    super(`[Token] ${message}`);
    this.name = "TokenError";
  }
};

// packages/core/di/token.ts
var TOKEN_NAME_RE = /^@[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+:[a-zA-Z0-9_]+$/;
var Token = class {
  constructor(name, version = "1.0.0") {
    if (!name || typeof name !== "string") {
      throw new TokenError(
        `Token name must be a non-empty string, got: ${String(name)}`
      );
    }
    if (!TOKEN_NAME_RE.test(name)) {
      throw new TokenError(
        `Invalid Token name format: "${name}". Expected: @scope/domain:ServiceName`
      );
    }
    this.name = name;
    this.version = version;
  }
};

// packages/core/di/interfaces.ts
var ICommandBusServiceToken = new Token(
  "@openlearn/core:ICommandBusService"
);
var IEventBusServiceToken = new Token(
  "@openlearn/core:IEventBusService"
);
var IActionRegistryServiceToken = new Token(
  "@openlearn/core:IActionRegistryService"
);
var ICapabilityServiceToken = new Token(
  "@openlearn/core:ICapabilityService"
);
var IProcessServiceToken = new Token(
  "@openlearn/core:IProcessService"
);
var IStorageServiceToken = new Token(
  "@openlearn/core:IStorageService"
);
var IAIServiceToken = new Token(
  "@openlearn/core:IAIService"
);
var IDatabaseToken = new Token(
  "@openlearn/core:IDatabase"
);
var IPluginHostToken = new Token(
  "@openlearn/core:IPluginHost"
);
var ISemesterGradeServiceToken = new Token(
  "@openlearn/core:ISemesterGradeService"
);

// packages/plugins/leaderboard/index.ts
var POINT_PRESETS = {
  positive: [
    { reason: "\u4E3B\u52A8\u56DE\u7B54\u95EE\u9898", points: 5, category: "\u8BFE\u5802\u4E92\u52A8" },
    { reason: "\u4F5C\u4E1A\u5B8C\u6210\u4F18\u79C0", points: 10, category: "\u4F5C\u4E1A\u8868\u73B0" },
    { reason: "\u5E2E\u52A9\u540C\u5B66\u89E3\u7B54", points: 3, category: "\u4E92\u52A9\u5408\u4F5C" },
    { reason: "\u8BFE\u5802\u79EF\u6781\u53D1\u8A00", points: 3, category: "\u8BFE\u5802\u4E92\u52A8" },
    { reason: "\u5C0F\u7EC4\u6C47\u62A5\u51FA\u8272", points: 8, category: "\u56E2\u961F\u534F\u4F5C" },
    { reason: "\u8003\u8BD5\u6210\u7EE9\u8FDB\u6B65", points: 10, category: "\u5B66\u4E1A\u8FDB\u6B65" },
    { reason: "\u6309\u65F6\u5B8C\u6210\u9884\u4E60\u4EFB\u52A1", points: 5, category: "\u5B66\u4E60\u4E60\u60EF" },
    { reason: "\u5B9E\u9A8C\u64CD\u4F5C\u89C4\u8303", points: 5, category: "\u5B9E\u8DF5\u80FD\u529B" }
  ],
  negative: [
    { reason: "\u4E0A\u8BFE\u8FDF\u5230", points: -2, category: "\u7EAA\u5F8B\u8003\u52E4" },
    { reason: "\u672A\u5B8C\u6210\u8BFE\u540E\u4F5C\u4E1A", points: -5, category: "\u4F5C\u4E1A\u8868\u73B0" },
    { reason: "\u8BFE\u5802\u55A7\u54D7\u6270\u4E71\u79E9\u5E8F", points: -3, category: "\u7EAA\u5F8B\u8003\u52E4" },
    { reason: "\u4E0A\u8BFE\u671F\u95F4\u4F7F\u7528\u624B\u673A", points: -5, category: "\u7EAA\u5F8B\u8003\u52E4" },
    { reason: "\u6284\u88AD\u4ED6\u4EBA\u4F5C\u4E1A", points: -10, category: "\u5B66\u672F\u8BDA\u4FE1" }
  ]
};
var BOARD_STYLE = {
  title: "\u{1F3C6} \u8BFE\u5802\u79EF\u5206\u6392\u884C\u699C",
  personalTitle: "\u{1F3C6} \u4E2A\u4EBA\u79EF\u5206\u6392\u884C\u699C",
  groupTitle: "\u{1F465} \u5C0F\u7EC4\u79EF\u5206\u6392\u884C\u699C",
  divider: "\u2501".repeat(28),
  medalColors: ["#FFD700", "#C0C0C0", "#CD7F32"]
  // 金/银/铜
};
var index_default = {
  manifest: {
    id: "ext-classroom-leaderboard",
    name: "\u8BFE\u5802\u79EF\u5206\u6392\u884C\u699C",
    version: "1.0.0"
  },
  // ── 插件激活入口 ──────────────────────────────────────────────
  activate: async (ctx) => {
    const { commandBus, actionRegistry, eventBus, storage } = ctx.services;
    console.log(`[Leaderboard] \u{1F680} \u6FC0\u6D3B\u63D2\u4EF6: ${ctx.pluginId} v${ctx.manifest.version}`);
    await ctx.db.ensureTable(
      "records",
      `id TEXT PRIMARY KEY,
       student_id TEXT NOT NULL,
       student_name TEXT NOT NULL,
       class_id TEXT NOT NULL,
       points INTEGER NOT NULL,
       reason TEXT NOT NULL,
       category TEXT DEFAULT '\u5176\u4ED6',
       operator TEXT DEFAULT 'teacher',
       created_at INTEGER NOT NULL`
    );
    console.log("[Leaderboard] \u2705 \u6570\u636E\u5E93\u8868\u521D\u59CB\u5316\u5B8C\u6210");
    await actionRegistry.register({
      id: "ext-leaderboard-add-points",
      commandType: "leaderboard.add_points",
      description: "\u3010\u8BFE\u5802\u79EF\u5206\u7BA1\u7406\u3011\u7ED9\u5B66\u751F\u6DFB\u52A0\u6216\u6263\u9664\u79EF\u5206\u3002\u52A0\u5206\u573A\u666F\uFF1A\u56DE\u7B54\u95EE\u9898(+5)\u3001\u4F18\u79C0\u4F5C\u4E1A(+10)\u3001\u5E2E\u52A9\u540C\u5B66(+3)\u3001\u79EF\u6781\u53D1\u8A00(+3)\u3002\u6263\u5206\u573A\u666F\uFF1A\u8FDF\u5230(-2)\u3001\u7F3A\u4EA4\u4F5C\u4E1A(-5)\u3001\u8BFE\u5802\u55A7\u54D7(-3)\u3002\u8BF7\u59CB\u7EC8\u63D0\u4F9B reason \u5B57\u6BB5\u8BF4\u660E\u539F\u56E0\u3002",
      capabilityRequired: "whiteboard:write",
      inputSchema: {
        type: "OBJECT",
        properties: {
          studentId: {
            type: "STRING",
            description: "\u5B66\u751F ID"
          },
          studentName: {
            type: "STRING",
            description: "\u5B66\u751F\u59D3\u540D\uFF08\u7528\u4E8E\u6392\u884C\u699C\u663E\u793A\uFF09"
          },
          classId: {
            type: "STRING",
            description: "\u73ED\u7EA7 ID"
          },
          points: {
            type: "INTEGER",
            description: "\u79EF\u5206\u53D8\u52A8\u503C\uFF08\u6B63\u6570\u52A0\u5206\uFF0C\u8D1F\u6570\u6263\u5206\uFF09"
          },
          reason: {
            type: "STRING",
            description: '\u79EF\u5206\u53D8\u52A8\u539F\u56E0\uFF0C\u5982"\u4E3B\u52A8\u56DE\u7B54\u95EE\u9898"'
          },
          category: {
            type: "STRING",
            description: "\u79EF\u5206\u5206\u7C7B\uFF1A\u8BFE\u5802\u4E92\u52A8/\u4F5C\u4E1A\u8868\u73B0/\u7EAA\u5F8B\u8003\u52E4/\u4E92\u52A9\u5408\u4F5C/\u56E2\u961F\u534F\u4F5C/\u5B66\u4E1A\u8FDB\u6B65/\u5B66\u4E60\u4E60\u60EF/\u5B9E\u8DF5\u80FD\u529B/\u5B66\u672F\u8BDA\u4FE1"
          }
        },
        required: ["studentId", "studentName", "classId", "points", "reason"]
      }
    });
    await actionRegistry.register({
      id: "ext-leaderboard-show",
      commandType: "leaderboard.show_board",
      description: "\u3010\u767D\u677F\u5C55\u793A\u6392\u884C\u699C\u3011\u5728\u8BFE\u5802\u4E92\u52A8\u767D\u677F\u4E0A\u5C55\u793A\u5F53\u524D\u73ED\u7EA7\u7684\u79EF\u5206\u6392\u884C\u699C\u3002\u652F\u6301\u4E2A\u4EBA\u6392\u884C(personal)\u548C\u5C0F\u7EC4\u6392\u884C(group)\u4E24\u79CD\u6A21\u5F0F\u3002\u6392\u884C\u699C\u4F1A\u6E32\u67D3\u4E3A\u9192\u76EE\u7684\u683C\u5F0F\u5316\u6587\u672C\uFF0C\u5168\u73ED\u5B66\u751F\u53EF\u89C1\u3002",
      capabilityRequired: "whiteboard:write",
      inputSchema: {
        type: "OBJECT",
        properties: {
          lessonId: {
            type: "STRING",
            description: "\u5173\u8054\u7684\u8BFE\u65F6 ID\uFF08\u7528\u4E8E\u5B9A\u4F4D\u753B\u677F\uFF09"
          },
          classId: {
            type: "STRING",
            description: "\u73ED\u7EA7 ID"
          },
          mode: {
            type: "STRING",
            description: "\u6392\u884C\u6A21\u5F0F\uFF1Apersonal\uFF08\u4E2A\u4EBA\u6392\u884C\uFF09\u6216 group\uFF08\u5C0F\u7EC4\u6392\u884C\uFF09\uFF0C\u9ED8\u8BA4 personal"
          },
          topN: {
            type: "INTEGER",
            description: "\u663E\u793A\u524D N \u540D\u5B66\u751F\uFF0C\u9ED8\u8BA4 10"
          }
        },
        required: ["lessonId", "classId"]
      }
    });
    await actionRegistry.register({
      id: "ext-leaderboard-ranking",
      commandType: "leaderboard.get_ranking",
      description: "\u3010\u67E5\u8BE2\u79EF\u5206\u6392\u540D\u3011\u83B7\u53D6\u6307\u5B9A\u73ED\u7EA7\u7684\u5B66\u751F\u79EF\u5206\u6392\u540D\u6570\u636E\uFF0C\u8FD4\u56DE\u5B66\u751FID\u3001\u59D3\u540D\u3001\u603B\u79EF\u5206\u548C\u6392\u540D\u3002",
      capabilityRequired: "management:read",
      inputSchema: {
        type: "OBJECT",
        properties: {
          classId: {
            type: "STRING",
            description: "\u73ED\u7EA7 ID"
          },
          mode: {
            type: "STRING",
            description: "\u6392\u884C\u6A21\u5F0F\uFF1Apersonal / group\uFF0C\u9ED8\u8BA4 personal"
          },
          limit: {
            type: "INTEGER",
            description: "\u8FD4\u56DE\u524D N \u540D\uFF0C\u9ED8\u8BA4\u5168\u90E8"
          }
        },
        required: ["classId"]
      }
    });
    await actionRegistry.register({
      id: "ext-leaderboard-history",
      commandType: "leaderboard.get_history",
      description: "\u3010\u79EF\u5206\u5386\u53F2\u67E5\u8BE2\u3011\u67E5\u8BE2\u6307\u5B9A\u5B66\u751F\u6216\u6574\u4E2A\u73ED\u7EA7\u7684\u79EF\u5206\u53D8\u52A8\u5386\u53F2\u8BB0\u5F55\u3002",
      capabilityRequired: "management:read",
      inputSchema: {
        type: "OBJECT",
        properties: {
          studentId: {
            type: "STRING",
            description: "\u5B66\u751F ID\uFF08\u53EF\u9009\uFF0C\u4E0D\u4F20\u5219\u67E5\u5168\u73ED\uFF09"
          },
          classId: {
            type: "STRING",
            description: "\u73ED\u7EA7 ID"
          },
          limit: {
            type: "INTEGER",
            description: "\u8FD4\u56DE\u6700\u8FD1 N \u6761\u8BB0\u5F55\uFF0C\u9ED8\u8BA4 50"
          }
        },
        required: ["classId"]
      }
    });
    await actionRegistry.register({
      id: "ext-leaderboard-presets",
      commandType: "leaderboard.get_presets",
      description: "\u3010\u79EF\u5206\u539F\u56E0\u6A21\u677F\u3011\u83B7\u53D6\u79EF\u5206\u52A0\u51CF\u7684\u9884\u8BBE\u539F\u56E0\u6A21\u677F\u5217\u8868\uFF0C\u5305\u542B\u5EFA\u8BAE\u7684\u5206\u503C\u548C\u5206\u7C7B\u3002",
      capabilityRequired: "",
      inputSchema: {
        type: "OBJECT",
        properties: {},
        required: []
      }
    });
    console.log("[Leaderboard] \u2705 AI Actions \u6CE8\u518C\u5B8C\u6210 (5 \u4E2A)");
    await commandBus.registerHandler("leaderboard.add_points", {
      execute: async (command) => {
        const payload = command.payload;
        const {
          studentId,
          studentName,
          classId,
          points,
          reason,
          category = "\u5176\u4ED6"
        } = payload;
        if (!studentId || !studentName || !classId || points === void 0) {
          return {
            success: false,
            error: "\u7F3A\u5C11\u5FC5\u9700\u53C2\u6570\uFF1AstudentId, studentName, classId, points"
          };
        }
        if (typeof points !== "number" || points === 0) {
          return {
            success: false,
            error: "\u79EF\u5206\u503C\u5FC5\u987B\u4E3A\u975E\u96F6\u6570\u5B57"
          };
        }
        try {
          const db = await ctx.resolve(IDatabaseToken);
          const recordId = "lbr_" + Math.random().toString(36).slice(2, 10);
          const timestamp = Date.now();
          db.prepare(
            `INSERT INTO ${ctx.db.table("records")}
             (id, student_id, student_name, class_id, points, reason, category, operator, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
          ).run(
            recordId,
            studentId,
            studentName,
            classId,
            points,
            reason,
            category,
            command.actorId || "teacher",
            timestamp
          );
          const totalRow = db.prepare(
            `SELECT COALESCE(SUM(points), 0) as total
               FROM ${ctx.db.table("records")}
               WHERE student_id = ? AND class_id = ?`
          ).get(studentId, classId);
          const totalPoints = totalRow?.total ?? points;
          const rankRow = db.prepare(
            `SELECT COUNT(*) + 1 as rank FROM (
                 SELECT student_id, SUM(points) as total
                 FROM ${ctx.db.table("records")}
                 WHERE class_id = ?
                 GROUP BY student_id
                 HAVING total > ?
               )`
          ).get(classId, totalPoints);
          const rank = rankRow?.rank ?? 1;
          await eventBus.publish({
            id: `evt_${recordId}`,
            type: "leaderboard.points_changed",
            source: ctx.pluginId,
            payload: {
              recordId,
              studentId,
              studentName,
              classId,
              points,
              reason,
              category,
              totalPoints,
              rank
            },
            timestamp
          });
          const emoji = points > 0 ? "\u{1F44D}" : "\u26A0\uFE0F";
          console.log(
            `[Leaderboard] ${emoji} ${studentName} ${points > 0 ? "+" : ""}${points}\u5206 \u2192 \u7D2F\u8BA1 ${totalPoints} \u5206 (\u7B2C ${rank} \u540D) | \u539F\u56E0: ${reason}`
          );
          return {
            success: true,
            recordId,
            studentName,
            pointsChanged: points,
            totalPoints,
            rank,
            message: points > 0 ? `${studentName} +${points}\u5206\uFF01\u5F53\u524D\u7D2F\u8BA1 ${totalPoints} \u5206\uFF0C\u6392\u540D\u7B2C ${rank}` : `${studentName} ${points}\u5206\u3002\u5F53\u524D\u7D2F\u8BA1 ${totalPoints} \u5206\uFF0C\u6392\u540D\u7B2C ${rank}`
          };
        } catch (err) {
          console.error("[Leaderboard] \u79EF\u5206\u64CD\u4F5C\u5931\u8D25:", err.message);
          return { success: false, error: err.message };
        }
      }
    });
    await commandBus.registerHandler("leaderboard.get_ranking", {
      execute: async (command) => {
        const payload = command.payload;
        const { classId, mode = "personal", limit = 50 } = payload;
        if (!classId) {
          return { success: false, error: "\u7F3A\u5C11\u5FC5\u9700\u53C2\u6570\uFF1AclassId" };
        }
        try {
          const db = await ctx.resolve(IDatabaseToken);
          const rows = db.prepare(
            `SELECT
                 student_id,
                 student_name,
                 SUM(points) as total_points,
                 COUNT(*) as record_count,
                 MAX(created_at) as last_updated
               FROM ${ctx.db.table("records")}
               WHERE class_id = ?
               GROUP BY student_id
               ORDER BY total_points DESC
               LIMIT ?`
          ).all(classId, limit);
          const ranking = rows.map((row, index) => ({
            rank: index + 1,
            studentId: row.student_id,
            studentName: row.student_name,
            totalPoints: row.total_points,
            recordCount: row.record_count,
            lastUpdated: row.last_updated,
            medal: index === 0 ? "\u{1F947}" : index === 1 ? "\u{1F948}" : index === 2 ? "\u{1F949}" : ""
          }));
          const stats = db.prepare(
            `SELECT
                 COUNT(DISTINCT student_id) as total_students,
                 SUM(points) as class_total_points,
                 AVG(points) as avg_per_record
               FROM ${ctx.db.table("records")}
               WHERE class_id = ?`
          ).get(classId);
          return {
            success: true,
            classId,
            mode,
            ranking,
            stats: {
              totalStudents: stats?.total_students ?? 0,
              classTotalPoints: stats?.class_total_points ?? 0,
              avgPerRecord: stats?.avg_per_record ? Math.round(stats.avg_per_record * 10) / 10 : 0
            },
            generatedAt: Date.now()
          };
        } catch (err) {
          console.error("[Leaderboard] \u67E5\u8BE2\u6392\u884C\u5931\u8D25:", err.message);
          return { success: false, error: err.message };
        }
      }
    });
    await commandBus.registerHandler("leaderboard.show_board", {
      execute: async (command) => {
        const payload = command.payload;
        const {
          lessonId,
          classId,
          mode = "personal",
          topN = 10
        } = payload;
        if (!lessonId || !classId) {
          return { success: false, error: "\u7F3A\u5C11\u5FC5\u9700\u53C2\u6570\uFF1AlessonId, classId" };
        }
        try {
          const rankingResult = await commandBus.execute({
            id: "int_" + Math.random().toString(36).slice(2),
            type: "leaderboard.get_ranking",
            actorId: command.actorId || `plugin:${ctx.pluginId}`,
            payload: { classId, mode, limit: topN },
            timestamp: Date.now()
          });
          if (!rankingResult?.success) {
            throw new Error(
              `\u83B7\u53D6\u6392\u884C\u6570\u636E\u5931\u8D25: ${rankingResult?.error || "\u672A\u77E5\u9519\u8BEF"}`
            );
          }
          const ranking = rankingResult.ranking || [];
          const stats = rankingResult.stats || {};
          const title = mode === "group" ? BOARD_STYLE.groupTitle : BOARD_STYLE.personalTitle;
          let boardText = `${title}
${BOARD_STYLE.divider}
`;
          if (ranking.length === 0) {
            boardText += "\n   \u{1F4ED} \u6682\u65E0\u79EF\u5206\u8BB0\u5F55\n   \u5FEB\u53BB\u7ED9\u540C\u5B66\u4EEC\u52A0\u5206\u5427\uFF01\n";
          } else {
            for (let i = 0; i < ranking.length; i++) {
              const item = ranking[i];
              const medal = item.medal || `${i + 1}.`;
              const barLength = Math.max(
                1,
                Math.round(
                  item.totalPoints / Math.max(1, ranking[0]?.totalPoints || 1) * 10
                )
              );
              const bar = "\u2588".repeat(barLength) + "\u2591".repeat(10 - barLength);
              boardText += `${medal} ${item.studentName.padEnd(8)} ${bar} ${item.totalPoints}\u5206
`;
            }
          }
          boardText += `${BOARD_STYLE.divider}
`;
          boardText += `\u{1F4CA} \u5171 ${stats.totalStudents || ranking.length} \u4EBA | `;
          boardText += `\u603B\u5206: ${stats.classTotalPoints || 0}`;
          const drawResult = await commandBus.execute({
            id: "int_draw_" + Math.random().toString(36).slice(2),
            type: "whiteboard.draw",
            actorId: command.actorId || `plugin:${ctx.pluginId}`,
            payload: {
              lessonId,
              type: "text",
              data: JSON.stringify({
                text: boardText,
                x: 60,
                y: 40,
                fontSize: 16,
                fill: "#1e293b",
                fontFamily: "monospace",
                width: 420,
                align: "left"
              })
            },
            timestamp: Date.now()
          });
          const elementId = drawResult?.elementId;
          await storage.set("last_board_element", {
            lessonId,
            elementId,
            classId,
            mode,
            topN
          });
          console.log(
            `[Leaderboard] \u{1F4CA} \u6392\u884C\u699C\u5DF2\u5C55\u793A\u5230\u767D\u677F (elementId: ${elementId})`
          );
          return {
            success: true,
            elementId,
            ranking,
            message: `\u6392\u884C\u699C\u5DF2\u5C55\u793A\u5230\u767D\u677F\uFF01\u5171 ${ranking.length} \u540D\u5B66\u751F\u4E0A\u699C\u3002`
          };
        } catch (err) {
          console.error("[Leaderboard] \u767D\u677F\u5C55\u793A\u5931\u8D25:", err.message);
          return { success: false, error: err.message };
        }
      }
    });
    await commandBus.registerHandler("leaderboard.get_history", {
      execute: async (command) => {
        const payload = command.payload;
        const { studentId, classId, limit = 50 } = payload;
        if (!classId) {
          return { success: false, error: "\u7F3A\u5C11\u5FC5\u9700\u53C2\u6570\uFF1AclassId" };
        }
        try {
          const db = await ctx.resolve(IDatabaseToken);
          let sql = `SELECT * FROM ${ctx.db.table("records")} WHERE class_id = ?`;
          const params = [classId];
          if (studentId) {
            sql += " AND student_id = ?";
            params.push(studentId);
          }
          sql += " ORDER BY created_at DESC LIMIT ?";
          params.push(limit);
          const rows = db.prepare(sql).all(...params);
          const summarySql = studentId ? `SELECT
                 SUM(points) as total_points,
                 COUNT(*) as total_records,
                 SUM(CASE WHEN points > 0 THEN points ELSE 0 END) as positive_points,
                 SUM(CASE WHEN points < 0 THEN points ELSE 0 END) as negative_points
               FROM ${ctx.db.table("records")}
               WHERE class_id = ? AND student_id = ?` : `SELECT
                 SUM(points) as total_points,
                 COUNT(*) as total_records,
                 SUM(CASE WHEN points > 0 THEN points ELSE 0 END) as positive_points,
                 SUM(CASE WHEN points < 0 THEN points ELSE 0 END) as negative_points
               FROM ${ctx.db.table("records")}
               WHERE class_id = ?`;
          const summaryParams = studentId ? [classId, studentId] : [classId];
          const summary = db.prepare(summarySql).get(...summaryParams);
          return {
            success: true,
            classId,
            studentId: studentId || null,
            records: rows,
            summary: {
              totalPoints: summary?.total_points ?? 0,
              totalRecords: summary?.total_records ?? 0,
              positivePoints: summary?.positive_points ?? 0,
              negativePoints: summary?.negative_points ?? 0
            }
          };
        } catch (err) {
          console.error("[Leaderboard] \u67E5\u8BE2\u5386\u53F2\u5931\u8D25:", err.message);
          return { success: false, error: err.message };
        }
      }
    });
    await commandBus.registerHandler("leaderboard.get_presets", {
      execute: async () => {
        return {
          success: true,
          presets: POINT_PRESETS
        };
      }
    });
    await commandBus.registerHandler("leaderboard.reset", {
      execute: async (command) => {
        const payload = command.payload;
        const { classId } = payload;
        if (!classId) {
          return { success: false, error: "\u7F3A\u5C11\u5FC5\u9700\u53C2\u6570\uFF1AclassId" };
        }
        try {
          const db = await ctx.resolve(IDatabaseToken);
          const rankingResult = await commandBus.execute({
            id: "int_backup_" + Math.random().toString(36).slice(2),
            type: "leaderboard.get_ranking",
            actorId: command.actorId || `plugin:${ctx.pluginId}`,
            payload: { classId, limit: 1e3 },
            timestamp: Date.now()
          });
          const backupKey = `semester_backup_${classId}_${Date.now()}`;
          await storage.set(backupKey, {
            classId,
            ranking: rankingResult?.ranking || [],
            stats: rankingResult?.stats || {},
            archivedAt: Date.now()
          });
          const result = db.prepare(
            `DELETE FROM ${ctx.db.table("records")} WHERE class_id = ?`
          ).run(classId);
          console.log(
            `[Leaderboard] \u{1F504} \u73ED\u7EA7 ${classId} \u79EF\u5206\u5DF2\u91CD\u7F6E\uFF0C\u5220\u9664 ${result.changes} \u6761\u8BB0\u5F55\uFF0C\u5907\u4EFD\u81F3 ${backupKey}`
          );
          return {
            success: true,
            deletedRecords: result.changes,
            backupKey,
            message: `\u79EF\u5206\u5DF2\u91CD\u7F6E\uFF01\u5171\u5F52\u6863 ${result.changes} \u6761\u8BB0\u5F55\uFF0C\u5907\u4EFD\u51ED\u8BC1: ${backupKey}`
          };
        } catch (err) {
          console.error("[Leaderboard] \u91CD\u7F6E\u5931\u8D25:", err.message);
          return { success: false, error: err.message };
        }
      }
    });
    console.log("[Leaderboard] \u2705 \u547D\u4EE4\u5904\u7406\u5668\u6CE8\u518C\u5B8C\u6210 (6 \u4E2A)");
    await eventBus.subscribe("student.registered", async (event) => {
      const payload = event.payload;
      const studentId = payload?.id;
      const studentName = payload?.name;
      if (!studentId) return;
      console.log(
        `[Leaderboard] \u{1F44B} \u68C0\u6D4B\u5230\u65B0\u5B66\u751F\u6CE8\u518C: ${studentName || studentId}\uFF0C\u5982\u9700\u521D\u59CB\u5316\u79EF\u5206\u8BF7\u4F7F\u7528 leaderboard.add_points`
      );
    });
    await eventBus.subscribe("leaderboard.points_changed", async (_event) => {
      try {
        const lastBoard = await storage.get("last_board_element");
        if (!lastBoard?.lessonId || !lastBoard?.classId) return;
        const { lessonId, classId, mode, topN } = lastBoard;
        await commandBus.execute({
          id: "int_refresh_" + Math.random().toString(36).slice(2),
          type: "leaderboard.show_board",
          actorId: `plugin:${ctx.pluginId}`,
          payload: { lessonId, classId, mode, topN },
          timestamp: Date.now()
        });
        console.log("[Leaderboard] \u{1F504} \u6392\u884C\u699C\u81EA\u52A8\u5237\u65B0");
      } catch {
      }
    });
    const existingConfig = await storage.get("config");
    if (!existingConfig) {
      await storage.set("config", {
        defaultTopN: 10,
        autoRefreshBoard: true,
        pointPresets: POINT_PRESETS,
        boardPosition: { x: 60, y: 40 },
        boardFontSize: 16
      });
      console.log("[Leaderboard] \u2699\uFE0F \u9ED8\u8BA4\u914D\u7F6E\u5DF2\u521D\u59CB\u5316");
    }
    console.log("[Leaderboard] \u2705 \u4E8B\u4EF6\u8BA2\u9605\u5DF2\u8BBE\u7F6E");
    console.log("[Leaderboard] \u{1F389} \u63D2\u4EF6\u6FC0\u6D3B\u5B8C\u6210\uFF01");
  },
  // ── 插件停用清理 ──────────────────────────────────────────
  deactivate: async () => {
    console.log("[Leaderboard] \u{1F44B} \u63D2\u4EF6\u5DF2\u505C\u7528\uFF0C\u8D44\u6E90\u7531 PluginHost \u81EA\u52A8\u6E05\u7406");
  }
};
export {
  index_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsicGFja2FnZXMvY29yZS9kaS9lcnJvcnMudHMiLCAicGFja2FnZXMvY29yZS9kaS90b2tlbi50cyIsICJwYWNrYWdlcy9jb3JlL2RpL2ludGVyZmFjZXMudHMiLCAicGFja2FnZXMvcGx1Z2lucy9sZWFkZXJib2FyZC9pbmRleC50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyoqXG4gKiBOYW1lZCBlcnJvciBjbGFzc2VzIGZvciB0aGUgREkgY29udGFpbmVyLlxuICpcbiAqIEVhY2ggZXJyb3IgaW5jbHVkZXMgdGhlIHJlbGV2YW50IFRva2VuIG5hbWUocykgYW5kIGNvbnRleHR1YWwgaW5mb3JtYXRpb25cbiAqIHRvIGFpZCBkZWJ1Z2dpbmcuICBFcnJvciBtZXNzYWdlcyBmb2xsb3cgdGhlIHByb2plY3QgbG9nZ2luZyBjb252ZW50aW9uXG4gKiAoYFtTdWJzeXN0ZW1dYCBwcmVmaXggdGFncyBcdTIwMTQgc2VlIENPTlZFTlRJT05TLm1kKS5cbiAqL1xuXG4vKipcbiAqIFRocm93biBieSB0aGUgVG9rZW4gY29uc3RydWN0b3Igd2hlbiB0aGUgbmFtZSBpcyBlbXB0eSBvciBkb2VzIG5vdCBtYXRjaFxuICogdGhlIHJlcXVpcmVkIG5hbWluZyBmb3JtYXQgYEBzY29wZS9kb21haW46U2VydmljZU5hbWVgLlxuICovXG5leHBvcnQgY2xhc3MgVG9rZW5FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IobWVzc2FnZTogc3RyaW5nKSB7XG4gICAgc3VwZXIoYFtUb2tlbl0gJHttZXNzYWdlfWApO1xuICAgIHRoaXMubmFtZSA9ICdUb2tlbkVycm9yJztcbiAgfVxufVxuXG4vKipcbiAqIFRocm93biBieSBTZXJ2aWNlUmVnaXN0cnkucmVnaXN0ZXIoKSB3aGVuIGEgVG9rZW4gaXMgYWxyZWFkeSByZWdpc3RlcmVkLlxuICpcbiAqIFRoZSBlcnJvciBtZXNzYWdlIGhpbnRzIGF0IGByZWdpc3Rlck9yUmVwbGFjZSgpYCBhcyB0aGUgZXhwbGljaXQgb3ZlcndyaXRlXG4gKiBwYXRoIChzZWUgRC0wOCkuXG4gKi9cbmV4cG9ydCBjbGFzcyBEdXBsaWNhdGVSZWdpc3RyYXRpb25FcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IocHVibGljIHJlYWRvbmx5IHRva2VuTmFtZTogc3RyaW5nKSB7XG4gICAgc3VwZXIoXG4gICAgICBgW1NlcnZpY2VSZWdpc3RyeV0gRHVwbGljYXRlIHJlZ2lzdHJhdGlvbjogXCIke3Rva2VuTmFtZX1cIiBpcyBhbHJlYWR5IHJlZ2lzdGVyZWQuIGAgK1xuICAgICAgICBgVXNlIHJlZ2lzdGVyT3JSZXBsYWNlKCkgdG8gb3ZlcndyaXRlLmBcbiAgICApO1xuICAgIHRoaXMubmFtZSA9ICdEdXBsaWNhdGVSZWdpc3RyYXRpb25FcnJvcic7XG4gIH1cbn1cblxuLyoqXG4gKiBUaHJvd24gYnkgU2VydmljZVJlZ2lzdHJ5LnJlZ2lzdGVyKCkgd2hlbiBvbmUgb3IgbW9yZSByZXF1aXJlZFxuICogZGVwZW5kZW5jaWVzIGFyZSBub3QgeWV0IHJlZ2lzdGVyZWQgKHNlZSBELTA2KS5cbiAqL1xuZXhwb3J0IGNsYXNzIE1pc3NpbmdEZXBlbmRlbmN5RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHB1YmxpYyByZWFkb25seSB0b2tlbk5hbWU6IHN0cmluZyxcbiAgICBwdWJsaWMgcmVhZG9ubHkgbWlzc2luZ0RlcHM6IHN0cmluZ1tdXG4gICkge1xuICAgIHN1cGVyKFxuICAgICAgYFtTZXJ2aWNlUmVnaXN0cnldIENhbm5vdCByZWdpc3RlciBcIiR7dG9rZW5OYW1lfVwiOiBtaXNzaW5nIGRlcGVuZGVuY2llczogYCArXG4gICAgICAgIGAke21pc3NpbmdEZXBzLmpvaW4oJywgJyl9YFxuICAgICk7XG4gICAgdGhpcy5uYW1lID0gJ01pc3NpbmdEZXBlbmRlbmN5RXJyb3InO1xuICB9XG59XG5cbi8qKlxuICogVGhyb3duIHdoZW4gYSBjaXJjdWxhciBkZXBlbmRlbmN5IGlzIGRldGVjdGVkIGR1cmluZyByZXNvbHV0aW9uLlxuICpcbiAqIFRoZSBgY3ljbGVUb2tlbnNgIGFycmF5IGxpc3RzIHRoZSBUb2tlbiBuYW1lcyB0aGF0IHBhcnRpY2lwYXRlIGluIHRoZVxuICogY3ljbGUgKHNlZSBST0FETUFQIFNDLTQpLlxuICovXG5leHBvcnQgY2xhc3MgQ2lyY3VsYXJEZXBlbmRlbmN5RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyByZWFkb25seSBjeWNsZVRva2Vuczogc3RyaW5nW10pIHtcbiAgICBzdXBlcihcbiAgICAgIGBbU2VydmljZVJlZ2lzdHJ5XSBDaXJjdWxhciBkZXBlbmRlbmN5IGRldGVjdGVkIGludm9sdmluZzogYCArXG4gICAgICAgIGAke2N5Y2xlVG9rZW5zLmpvaW4oJyBcdTIxOTIgJyl9YFxuICAgICk7XG4gICAgdGhpcy5uYW1lID0gJ0NpcmN1bGFyRGVwZW5kZW5jeUVycm9yJztcbiAgfVxufVxuXG4vKipcbiAqIFRocm93biBieSBTZXJ2aWNlUmVnaXN0cnkudW5yZWdpc3RlcigpIHdoZW4gb3RoZXIgcmVnaXN0ZXJlZCBzZXJ2aWNlc1xuICogc3RpbGwgZGVwZW5kIG9uIHRoZSBUb2tlbiBiZWluZyByZW1vdmVkIChzZWUgRC0wOSkuXG4gKi9cbmV4cG9ydCBjbGFzcyBIYXNEZXBlbmRlbnRFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IoXG4gICAgcHVibGljIHJlYWRvbmx5IHRva2VuTmFtZTogc3RyaW5nLFxuICAgIHB1YmxpYyByZWFkb25seSBkZXBlbmRlbnRzOiBzdHJpbmdbXVxuICApIHtcbiAgICBzdXBlcihcbiAgICAgIGBbU2VydmljZVJlZ2lzdHJ5XSBDYW5ub3QgdW5yZWdpc3RlciBcIiR7dG9rZW5OYW1lfVwiOiBzdGlsbCBoYXMgZGVwZW5kZW50czogYCArXG4gICAgICAgIGAke2RlcGVuZGVudHMuam9pbignLCAnKX0uIFVucmVnaXN0ZXIgdGhlbSBmaXJzdC5gXG4gICAgKTtcbiAgICB0aGlzLm5hbWUgPSAnSGFzRGVwZW5kZW50RXJyb3InO1xuICB9XG59XG4iLCAiLyoqXG4gKiBUb2tlbjxUPiBcdTIwMTQgYSB0eXBlLXNhZmUgc2VydmljZSBpZGVudGlmaWVyIGZvciB0aGUgREkgY29udGFpbmVyLlxuICpcbiAqIEluc3BpcmVkIGJ5IHRoZSBKdXB5dGVyTGFiL0x1bWlubyBUb2tlbiBkZXNpZ24gcGF0dGVybi4gIFRoZSBnZW5lcmljXG4gKiBwYXJhbWV0ZXIgYFRgIGlzIGEgKipwaGFudG9tIHR5cGUqKjogaXQgY2FycmllcyB0aGUgc2VydmljZSBpbnRlcmZhY2VcbiAqIHR5cGUgYXQgY29tcGlsZSB0aW1lIGJ1dCBpcyBuZXZlciB1c2VkIGF0IHJ1bnRpbWUuXG4gKlxuICogIyMgTmFtaW5nIGNvbnZlbnRpb25cbiAqXG4gKiBgQHNjb3BlL2RvbWFpbjpTZXJ2aWNlTmFtZWAgXHUyMDE0IGUuZy4gYEBvcGVubGVhcm4vY29yZTpJQ29tbWFuZEJ1c1NlcnZpY2VgLlxuICogVGhlIGNvbnN0cnVjdG9yIHZhbGlkYXRlcyB0aGUgZm9ybWF0IGFuZCByZWplY3RzIG5hbWVzIHRoYXQgY29udGFpblxuICogc3BhY2VzLCBDaGluZXNlIGNoYXJhY3RlcnMsIG9yIG90aGVyIHNwZWNpYWwgY2hhcmFjdGVycyAoc2VlIFBpdGZhbGwgNFxuICogaW4gUkVTRUFSQ0gubWQgXHUyMDE0IFBoYXNlIDMgbWF5IHVzZSB0b2tlbiBuYW1lcyBpbiBVUkwgLyBmaWxlLXBhdGggY29udGV4dHMpLlxuICpcbiAqICMjIFVzYWdlXG4gKlxuICogYGBgdHNcbiAqIGludGVyZmFjZSBJQ29tbWFuZEJ1c1NlcnZpY2UgeyBleGVjdXRlKGNtZDogdW5rbm93bik6IFByb21pc2U8dW5rbm93bj4gfVxuICogZXhwb3J0IGNvbnN0IElDb21tYW5kQnVzU2VydmljZVRva2VuID0gbmV3IFRva2VuPElDb21tYW5kQnVzU2VydmljZT4oXG4gKiAgICdAb3BlbmxlYXJuL2NvcmU6SUNvbW1hbmRCdXNTZXJ2aWNlJ1xuICogKTtcbiAqIGBgYFxuICovXG5pbXBvcnQgeyBUb2tlbkVycm9yIH0gZnJvbSAnLi9lcnJvcnMuanMnO1xuXG4vLyBUb2tlbiBuYW1pbmcgcmVnZXg6IEBzY29wZS9kb21haW46TmFtZVxuLy8gc2NvcGUgIDogbGV0dGVycywgZGlnaXRzLCB1bmRlcnNjb3JlLCBoeXBoZW5cbi8vIGRvbWFpbiA6IGxldHRlcnMsIGRpZ2l0cywgdW5kZXJzY29yZSwgaHlwaGVuXG4vLyBuYW1lICAgOiBsZXR0ZXJzLCBkaWdpdHMsIHVuZGVyc2NvcmVcbmNvbnN0IFRPS0VOX05BTUVfUkUgPSAvXkBbYS16QS1aMC05Xy1dK1xcL1thLXpBLVowLTlfLV0rOlthLXpBLVowLTlfXSskLztcblxuZXhwb3J0IGNsYXNzIFRva2VuPFQ+IHtcbiAgLy8gUGhhbnRvbSB0eXBlIHBhcmFtZXRlciBcdTIwMTQgY2FycmllcyB0aGUgc2VydmljZSBpbnRlcmZhY2UgdHlwZSBhdFxuICAvLyBjb21waWxlIHRpbWUgb25seS4gIE5ldmVyIGFjY2Vzc2VkIGF0IHJ1bnRpbWUuXG4gIC8vIFBoYW50b20gdHlwZSBcdTIwMTQgY2FycmllcyB0aGUgc2VydmljZSBpbnRlcmZhY2UgYXQgY29tcGlsZSB0aW1lIG9ubHkuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgcHJpdmF0ZSByZWFkb25seSBfcGhhbnRvbVNlcnZpY2UhOiBUO1xuXG4gIC8qKiBUaGUgc3RyaW5nIGlkZW50aWZpZXIsIGUuZy4gYEBvcGVubGVhcm4vY29yZTpJQ29tbWFuZEJ1c1NlcnZpY2VgLiAqL1xuICBwdWJsaWMgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xuXG4gIC8qKiBcdThCRURcdTRFNDlcdTUzMTZcdTcyNDhcdTY3MkNcdTUzRjdcdUZGMDhzZW12ZXJcdUZGMDlcdUZGMENcdTlFRDhcdThCQTQgJzEuMC4wJ1x1MzAwMiAqL1xuICBwdWJsaWMgcmVhZG9ubHkgdmVyc2lvbjogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKG5hbWU6IHN0cmluZywgdmVyc2lvbjogc3RyaW5nID0gJzEuMC4wJykge1xuICAgIGlmICghbmFtZSB8fCB0eXBlb2YgbmFtZSAhPT0gJ3N0cmluZycpIHtcbiAgICAgIHRocm93IG5ldyBUb2tlbkVycm9yKFxuICAgICAgICBgVG9rZW4gbmFtZSBtdXN0IGJlIGEgbm9uLWVtcHR5IHN0cmluZywgZ290OiAke1N0cmluZyhuYW1lKX1gXG4gICAgICApO1xuICAgIH1cblxuICAgIGlmICghVE9LRU5fTkFNRV9SRS50ZXN0KG5hbWUpKSB7XG4gICAgICB0aHJvdyBuZXcgVG9rZW5FcnJvcihcbiAgICAgICAgYEludmFsaWQgVG9rZW4gbmFtZSBmb3JtYXQ6IFwiJHtuYW1lfVwiLiBgICtcbiAgICAgICAgICBgRXhwZWN0ZWQ6IEBzY29wZS9kb21haW46U2VydmljZU5hbWVgXG4gICAgICApO1xuICAgIH1cblxuICAgIHRoaXMubmFtZSA9IG5hbWU7XG4gICAgdGhpcy52ZXJzaW9uID0gdmVyc2lvbjtcbiAgfVxufVxuIiwgIi8qKlxuICogSVNlcnZpY2UgaW50ZXJmYWNlcyBhbmQgVG9rZW4gaW5zdGFuY2VzIFx1MjAxNCBjZW50cmFsaXplZCBzZXJ2aWNlIGNvbnRyYWN0IGRlZmluaXRpb25zLlxuICpcbiAqIFRoaXMgZmlsZSBkZWZpbmVzIHRoZSB0eXBlLXNhZmUgc2VydmljZSBpbnRlcmZhY2VzIChJU2VydmljZSkgYW5kIGNvcnJlc3BvbmRpbmdcbiAqIFRva2VuIGluc3RhbmNlcyBmb3IgYWxsIDcgY29yZSBzdWJzeXN0ZW1zLiBQbHVnaW4gZGV2ZWxvcGVycyBpbXBvcnQgZnJvbSBhIHNpbmdsZVxuICogZW50cnkgcG9pbnQgdG8gZ2V0IGJvdGggdGhlIGludGVyZmFjZSB0eXBlIGFuZCB0aGUgREkgVG9rZW4uXG4gKlxuICogIyMgRGVzaWduIGRlY2lzaW9uc1xuICpcbiAqIC0gKipBbGwgbWV0aG9kcyByZXR1cm4gUHJvbWlzZTxUPioqIChELTEwKTogRXZlbiBjdXJyZW50bHktc3luY2hyb25vdXMgb3BlcmF0aW9uc1xuICogICBhcmUgd3JhcHBlZCBpbiBhc3luYyBzaWduYXR1cmVzIHNvIHRoZSBpbnRlcmZhY2Ugc3RheXMgY29uc2lzdGVudCBhY3Jvc3MgbG9jYWxcbiAqICAgYW5kIHJlbW90ZSAoV29ya2VyIFRocmVhZCkgaW1wbGVtZW50YXRpb25zIGluIGZ1dHVyZSBwaGFzZXMgKEQtMTcpLlxuICogLSAqKk5vIGRpc3Bvc2UvY2xlYW51cCBsaWZlY3ljbGUqKiAoRC0wNSk6IElTZXJ2aWNlIGludGVyZmFjZXMgYXJlIHB1cmUgY2FwYWJpbGl0eVxuICogICBjb250cmFjdHM7IGxpZmVjeWNsZSBtYW5hZ2VtZW50IGJlbG9uZ3MgdG8gdGhlIERJIGNvbnRhaW5lciBsYXllci5cbiAqIC0gKipSZXR1cm4gdHlwZXMgdGlnaHRlbmVkKiogKEQtMTEpOiBgYW55YCBuYXJyb3dlZCB0byBgdW5rbm93bmAgb3IgY29uY3JldGUgdHlwZXNcbiAqICAgKGUuZy4gYGdldEFnZW50VG9vbHMoKTogUHJvbWlzZTx1bmtub3duW10+YCBpbnN0ZWFkIG9mIGBQcm9taXNlPGFueVtdPmApLlxuICogICBQYXlsb2FkL3BhcmFtcyByZXRhaW4gYHVua25vd25gIHdoZXJlIHRoZSBjYWxsZXIgZGVmaW5lcyB0aGUgc2hhcGUuXG4gKiAtICoqVG9rZW4gbmFtaW5nIGZvcm1hdCBgSVNlcnZpY2VOYW1lVG9rZW5gKiogKEQtMTMpOiBJZGVudGlmaWVyIGBAb3BlbmxlYXJuL2NvcmU6SVNlcnZpY2VOYW1lYCxcbiAqICAgdmFsaWRhdGVkIGF0IGNvbnN0cnVjdGlvbiB0aW1lIGJ5IFRva2VuJ3MgVE9LRU5fTkFNRV9SRSByZWdleC5cbiAqXG4gKiAjIyBVc2FnZVxuICpcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBJQ29tbWFuZEJ1c1NlcnZpY2UsIElDb21tYW5kQnVzU2VydmljZVRva2VuIH0gZnJvbSAnLi9pbnRlcmZhY2VzLmpzJztcbiAqIC8vIEluIGEgcGx1Z2luJ3MgYWN0aXZhdGUoY3R4KTpcbiAqIGNvbnN0IGNtZEJ1cyA9IGF3YWl0IGN0eC5yZXNvbHZlKElDb21tYW5kQnVzU2VydmljZVRva2VuKTtcbiAqIGF3YWl0IGNtZEJ1cy5leGVjdXRlKC4uLik7XG4gKiBgYGBcbiAqL1xuXG5pbXBvcnQgeyBUb2tlbiB9IGZyb20gJy4vdG9rZW4uanMnO1xuaW1wb3J0IHR5cGUge1xuICBQbGF0Zm9ybUNvbW1hbmQsXG4gIENvbW1hbmRIYW5kbGVyLFxuICBDb21tYW5kTWV0YWRhdGEsXG59IGZyb20gJy4uL2NvbW1hbmQtYnVzL2luZGV4LmpzJztcbmltcG9ydCB0eXBlIHsgUGxhdGZvcm1FdmVudCwgRXZlbnRTdWJzY3JpYmVyIH0gZnJvbSAnLi4vZXZlbnQtYnVzL2luZGV4LmpzJztcbmltcG9ydCB0eXBlIHsgQWN0aW9uRGVzY3JpcHRvciB9IGZyb20gJy4uL3JlZ2lzdHJ5L2luZGV4LmpzJztcbmltcG9ydCB0eXBlIHsgUHJvY2Vzc0hhbmRsZXIgfSBmcm9tICcuLi9wcm9jZXNzLW1hbmFnZXIvaW5kZXguanMnO1xuXG4vLyBcdTI1MDBcdTI1MDAgMS4gSUNvbW1hbmRCdXNTZXJ2aWNlIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuXG5leHBvcnQgaW50ZXJmYWNlIElDb21tYW5kQnVzU2VydmljZSB7XG4gIC8qKlxuICAgKiBFeGVjdXRlIGEgY29tbWFuZCB0aHJvdWdoIHRoZSBmdWxsIGludGVyY2VwdG9yIHBpcGVsaW5lLlxuICAgKiBDb3JyZXNwb25kcyB0byBDb21tYW5kQnVzLmV4ZWN1dGUoKS5cbiAgICovXG4gIGV4ZWN1dGU8VCBleHRlbmRzIFBsYXRmb3JtQ29tbWFuZD4oY29tbWFuZDogVCk6IFByb21pc2U8dW5rbm93bj47XG5cbiAgLyoqXG4gICAqIFJlZ2lzdGVyIGEgaGFuZGxlciBmb3IgYSBjb21tYW5kIHR5cGUuXG4gICAqIENvcnJlc3BvbmRzIHRvIENvbW1hbmRCdXMucmVnaXN0ZXJIYW5kbGVyKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIHJlZ2lzdGVySGFuZGxlcihjb21tYW5kVHlwZTogc3RyaW5nLCBoYW5kbGVyOiBDb21tYW5kSGFuZGxlcik6IFByb21pc2U8dm9pZD47XG5cbiAgLyoqXG4gICAqIFVucmVnaXN0ZXIgYSBoYW5kbGVyIGZvciBhIGNvbW1hbmQgdHlwZS5cbiAgICogQ29ycmVzcG9uZHMgdG8gQ29tbWFuZEJ1cy51bnJlZ2lzdGVySGFuZGxlcigpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICB1bnJlZ2lzdGVySGFuZGxlcihjb21tYW5kVHlwZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPjtcblxuICAvKipcbiAgICogQ3JlYXRlIGEgY29tbWFuZCBlbnZlbG9wZSB3aXRoIG1ldGFkYXRhLlxuICAgKiBDb3JyZXNwb25kcyB0byBDb21tYW5kQnVzLmNyZWF0ZUNvbW1hbmQoKSBcdTIwMTQgbWFkZSBhc3luYyBmb3IgY3Jvc3MtcnVudGltZSBjb21wYXRpYmlsaXR5LlxuICAgKi9cbiAgY3JlYXRlQ29tbWFuZDxUPihcbiAgICB0eXBlOiBzdHJpbmcsXG4gICAgcGF5bG9hZDogVCxcbiAgICBhY3RvcklkOiBzdHJpbmcsXG4gICAgbWV0YWRhdGE/OiBDb21tYW5kTWV0YWRhdGEsXG4gICk6IFByb21pc2U8UGxhdGZvcm1Db21tYW5kPFQ+PjtcblxuICAvKipcbiAgICogU2V0IGEgY29tbWFuZCBpbnRlcmNlcHRvciAoY2FwYWJpbGl0eSBjaGVjaywgaGlnaC1yaXNrIGFwcHJvdmFsLCBldGMuKS5cbiAgICogQ29ycmVzcG9uZHMgdG8gQ29tbWFuZEJ1cy5zZXRJbnRlcmNlcHRvcigpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICBzZXRJbnRlcmNlcHRvcihcbiAgICBpbnRlcmNlcHRvcjogKGNvbW1hbmQ6IFBsYXRmb3JtQ29tbWFuZCkgPT4gUHJvbWlzZTx2b2lkPixcbiAgKTogUHJvbWlzZTx2b2lkPjtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIDIuIElFdmVudEJ1c1NlcnZpY2UgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmV4cG9ydCBpbnRlcmZhY2UgSUV2ZW50QnVzU2VydmljZSB7XG4gIC8qKlxuICAgKiBQdWJsaXNoIGFuIGV2ZW50IHRvIGFsbCBtYXRjaGluZyBzdWJzY3JpYmVycyAoaW5jbHVkaW5nIHdpbGRjYXJkIGAqYCkuXG4gICAqIENvcnJlc3BvbmRzIHRvIEV2ZW50QnVzLnB1Ymxpc2goKSBcdTIwMTQgYWxyZWFkeSBhc3luYywga2VwdCBhc3luYy5cbiAgICovXG4gIHB1Ymxpc2goZXZlbnQ6IFBsYXRmb3JtRXZlbnQpOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8qKlxuICAgKiBTdWJzY3JpYmUgdG8gZXZlbnRzIG9mIGEgZ2l2ZW4gdHlwZS5cbiAgICogQ29ycmVzcG9uZHMgdG8gRXZlbnRCdXMuc3Vic2NyaWJlKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIHN1YnNjcmliZShldmVudFR5cGU6IHN0cmluZywgc3Vic2NyaWJlcjogRXZlbnRTdWJzY3JpYmVyKTogUHJvbWlzZTx2b2lkPjtcblxuICAvKipcbiAgICogVW5zdWJzY3JpYmUgZnJvbSBldmVudHMgb2YgYSBnaXZlbiB0eXBlLlxuICAgKiBDb3JyZXNwb25kcyB0byBFdmVudEJ1cy51bnN1YnNjcmliZSgpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICB1bnN1YnNjcmliZShldmVudFR5cGU6IHN0cmluZywgc3Vic2NyaWJlcjogRXZlbnRTdWJzY3JpYmVyKTogUHJvbWlzZTx2b2lkPjtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIDMuIElBY3Rpb25SZWdpc3RyeVNlcnZpY2UgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmV4cG9ydCBpbnRlcmZhY2UgSUFjdGlvblJlZ2lzdHJ5U2VydmljZSB7XG4gIC8qKlxuICAgKiBSZWdpc3RlciBhbiBhY3Rpb24gZGVzY3JpcHRvciAodG9vbCkgZGlzY292ZXJhYmxlIGJ5IHRoZSBBSSBBZ2VudC5cbiAgICogQ29ycmVzcG9uZHMgdG8gQWN0aW9uUmVnaXN0cnkucmVnaXN0ZXIoKSBcdTIwMTQgbWFkZSBhc3luYyBmb3IgY3Jvc3MtcnVudGltZSBjb21wYXRpYmlsaXR5LlxuICAgKi9cbiAgcmVnaXN0ZXIoZGVzY3JpcHRvcjogQWN0aW9uRGVzY3JpcHRvcik6IFByb21pc2U8dm9pZD47XG5cbiAgLyoqXG4gICAqIFVucmVnaXN0ZXIgYW4gYWN0aW9uIGJ5IGl0cyBpZC5cbiAgICogQ29ycmVzcG9uZHMgdG8gQWN0aW9uUmVnaXN0cnkudW5yZWdpc3RlcigpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICB1bnJlZ2lzdGVyKGlkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8qKlxuICAgKiBHZXQgYWxsIHJlZ2lzdGVyZWQgYWN0aW9uIGRlc2NyaXB0b3JzLlxuICAgKiBDb3JyZXNwb25kcyB0byBBY3Rpb25SZWdpc3RyeS5nZXRBbGxBY3Rpb25zKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIGdldEFsbEFjdGlvbnMoKTogUHJvbWlzZTxBY3Rpb25EZXNjcmlwdG9yW10+O1xuXG4gIC8qKlxuICAgKiBHZXQgdG9vbHMgZm9ybWF0dGVkIGZvciBAZ29vZ2xlL2dlbmFpIGZ1bmN0aW9uRGVjbGFyYXRpb25zLlxuICAgKiBDb3JyZXNwb25kcyB0byBBY3Rpb25SZWdpc3RyeS5nZXRBZ2VudFRvb2xzKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICogUmV0dXJuIHR5cGUgdGlnaHRlbmVkIGZyb20gYGFueVtdYCB0byBgdW5rbm93bltdYCBwZXIgRC0xMS5cbiAgICovXG4gIGdldEFnZW50VG9vbHMoKTogUHJvbWlzZTx1bmtub3duW10+O1xuXG4gIC8qKlxuICAgKiBGaW5kIGFuIGFjdGlvbiBkZXNjcmlwdG9yIGJ5IGl0cyB0b29sIG5hbWUgKHNhbml0aXplZCBjb21tYW5kIHR5cGUpLlxuICAgKiBDb3JyZXNwb25kcyB0byBBY3Rpb25SZWdpc3RyeS5nZXRBY3Rpb25CeVRvb2xOYW1lKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIGdldEFjdGlvbkJ5VG9vbE5hbWUoXG4gICAgdG9vbE5hbWU6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxBY3Rpb25EZXNjcmlwdG9yIHwgdW5kZWZpbmVkPjtcblxuICAvKipcbiAgICogRmluZCBhbiBhY3Rpb24gZGVzY3JpcHRvciBieSBpdHMgZXhhY3QgY29tbWFuZCB0eXBlIHN0cmluZy5cbiAgICogQ29ycmVzcG9uZHMgdG8gQWN0aW9uUmVnaXN0cnkuZ2V0QWN0aW9uQnlDb21tYW5kVHlwZSgpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICBnZXRBY3Rpb25CeUNvbW1hbmRUeXBlKFxuICAgIGNvbW1hbmRUeXBlOiBzdHJpbmcsXG4gICk6IFByb21pc2U8QWN0aW9uRGVzY3JpcHRvciB8IHVuZGVmaW5lZD47XG59XG5cbi8vIFx1MjUwMFx1MjUwMCA0LiBJQ2FwYWJpbGl0eVNlcnZpY2UgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmV4cG9ydCBpbnRlcmZhY2UgSUNhcGFiaWxpdHlTZXJ2aWNlIHtcbiAgLyoqXG4gICAqIEdyYW50IGEgY2FwYWJpbGl0eSB0byBhbiBhY3Rvci5cbiAgICogQ29ycmVzcG9uZHMgdG8gQ2FwYWJpbGl0eUd1YXJkLmdyYW50KCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIGdyYW50KGFjdG9ySWQ6IHN0cmluZywgY2FwOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8qKlxuICAgKiBSZXZva2UgYWxsIGNhcGFiaWxpdGllcyBmcm9tIGFuIGFjdG9yLlxuICAgKiBDb3JyZXNwb25kcyB0byBDYXBhYmlsaXR5R3VhcmQucmV2b2tlQWxsKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIHJldm9rZUFsbChhY3RvcklkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+O1xuXG4gIC8qKlxuICAgKiBDaGVjayB3aGV0aGVyIGFuIGFjdG9yIGhhcyBhIHJlcXVpcmVkIGNhcGFiaWxpdHkgKHN1cHBvcnRzIHdpbGRjYXJkIG1hdGNoaW5nKS5cbiAgICogQ29ycmVzcG9uZHMgdG8gQ2FwYWJpbGl0eUd1YXJkLmNoZWNrKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIGNoZWNrKGFjdG9ySWQ6IHN0cmluZywgcmVxdWlyZWRDYXA6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj47XG59XG5cbi8vIFx1MjUwMFx1MjUwMCA1LiBJUHJvY2Vzc1NlcnZpY2UgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbmV4cG9ydCBpbnRlcmZhY2UgSVByb2Nlc3NTZXJ2aWNlIHtcbiAgLyoqXG4gICAqIFNwYXduIGEgbmV3IGJhY2tncm91bmQgcHJvY2Vzcy5cbiAgICogQ29ycmVzcG9uZHMgdG8gUHJvY2Vzc01hbmFnZXIuc3Bhd24oKSBcdTIwMTQgbWFkZSBhc3luYyBmb3IgY3Jvc3MtcnVudGltZSBjb21wYXRpYmlsaXR5LlxuICAgKiBQYXlsb2FkIHRpZ2h0ZW5lZCBmcm9tIGBhbnlgIHRvIGB1bmtub3duYCBwZXIgRC0xMS5cbiAgICovXG4gIHNwYXduKG5hbWU6IHN0cmluZywgdGFza1R5cGU6IHN0cmluZywgcGF5bG9hZDogdW5rbm93bik6IFByb21pc2U8c3RyaW5nPjtcblxuICAvKipcbiAgICogS2lsbCBhIHJ1bm5pbmcgcHJvY2VzcyBieSBpdHMgaWQuXG4gICAqIENvcnJlc3BvbmRzIHRvIFByb2Nlc3NNYW5hZ2VyLmtpbGwoKSBcdTIwMTQgbWFkZSBhc3luYyBmb3IgY3Jvc3MtcnVudGltZSBjb21wYXRpYmlsaXR5LlxuICAgKi9cbiAga2lsbChwcm9jZXNzSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD47XG5cbiAgLyoqXG4gICAqIFJlZ2lzdGVyIGEgaGFuZGxlciBmb3IgYSB0YXNrIHR5cGUuXG4gICAqIENvcnJlc3BvbmRzIHRvIFByb2Nlc3NNYW5hZ2VyLnJlZ2lzdGVySGFuZGxlcigpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICByZWdpc3RlckhhbmRsZXIoXG4gICAgdGFza1R5cGU6IHN0cmluZyxcbiAgICBoYW5kbGVyOiBQcm9jZXNzSGFuZGxlcixcbiAgKTogUHJvbWlzZTx2b2lkPjtcblxuICAvKipcbiAgICogVW5yZWdpc3RlciBhIGhhbmRsZXIgZm9yIGEgdGFzayB0eXBlLlxuICAgKiBDb3JyZXNwb25kcyB0byBQcm9jZXNzTWFuYWdlci51bnJlZ2lzdGVySGFuZGxlcigpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICB1bnJlZ2lzdGVySGFuZGxlcih0YXNrVHlwZTogc3RyaW5nKTogUHJvbWlzZTx2b2lkPjtcblxuICAvKipcbiAgICogUmVnaXN0ZXIgYSByZWN1cnJpbmcgaW50ZXJ2YWwgcHJvY2Vzcy5cbiAgICogQ29ycmVzcG9uZHMgdG8gUHJvY2Vzc01hbmFnZXIucmVnaXN0ZXJJbnRlcnZhbCgpIFx1MjAxNCBtYWRlIGFzeW5jIGZvciBjcm9zcy1ydW50aW1lIGNvbXBhdGliaWxpdHkuXG4gICAqL1xuICByZWdpc3RlckludGVydmFsKFxuICAgIG5hbWU6IHN0cmluZyxcbiAgICBpbnRlcnZhbE1zOiBudW1iZXIsXG4gICAgdGlja0ZuOiAobG9nOiAobXNnOiBzdHJpbmcpID0+IHZvaWQpID0+IHZvaWQsXG4gICk6IFByb21pc2U8c3RyaW5nPjtcblxuICAvKipcbiAgICogUmVzdG9yZSBydW5uaW5nIHByb2Nlc3NlcyBmcm9tIERCIGFmdGVyIHNlcnZlciByZXN0YXJ0LlxuICAgKiBDb3JyZXNwb25kcyB0byBQcm9jZXNzTWFuYWdlci5yZXN0b3JlKCkgXHUyMDE0IG1hZGUgYXN5bmMgZm9yIGNyb3NzLXJ1bnRpbWUgY29tcGF0aWJpbGl0eS5cbiAgICovXG4gIHJlc3RvcmUoKTogUHJvbWlzZTx2b2lkPjtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIDYuIElTdG9yYWdlU2VydmljZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqXG4gKiBLZXJuZWwtbGV2ZWwgcGVyc2lzdGVudCBrZXktdmFsdWUgc3RvcmFnZS5cbiAqXG4gKiBCYXNlZCBvbiB0aGUgd3JhcHBlZFN0b3JhZ2UgQVBJIGZyb20gUGx1Z2luUnVudGltZSAoRC0xMikuXG4gKiBVc2VzIFNRTGl0ZSBgcGx1Z2luX3N0b3JhZ2VgIHRhYmxlIHdpdGggYCdfX2tlcm5lbF9fJ2AgbmFtZXNwYWNlO1xuICogcGVyLXBsdWdpbiBpc29sYXRpb24gaXMgZW5mb3JjZWQgYnkgdGhlIFBsdWdpblJ1bnRpbWUgd3JhcHBlciBsYXllci5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBJU3RvcmFnZVNlcnZpY2Uge1xuICAvKiogR2V0IGEgdmFsdWUgYnkga2V5LiBSZXR1cm5zIGBudWxsYCBpZiB0aGUga2V5IGRvZXMgbm90IGV4aXN0LiAqL1xuICBnZXQoa2V5OiBzdHJpbmcpOiBQcm9taXNlPHVua25vd24+O1xuXG4gIC8qKiBTZXQgYSB2YWx1ZSBieSBrZXkuIE92ZXJ3cml0ZXMgZXhpc3RpbmcgdmFsdWVzLiAqL1xuICBzZXQoa2V5OiBzdHJpbmcsIHZhbHVlOiB1bmtub3duKTogUHJvbWlzZTx2b2lkPjtcblxuICAvKiogRGVsZXRlIGEgdmFsdWUgYnkga2V5LiBOby1vcCBpZiB0aGUga2V5IGRvZXMgbm90IGV4aXN0LiAqL1xuICBkZWxldGUoa2V5OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+O1xufVxuXG4vLyBcdTI1MDBcdTI1MDAgNy4gSUFJU2VydmljZSBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcblxuLyoqXG4gKiBLZXJuZWwtbGV2ZWwgQUkgdGV4dCBnZW5lcmF0aW9uLlxuICpcbiAqIEJhc2VkIG9uIHRoZSB3cmFwcGVkQUkuZ2VuZXJhdGVUZXh0IEFQSSBmcm9tIFBsdWdpblJ1bnRpbWUgKEQtMTIpLlxuICogSW1wbGVtZW50cyBhIHR3by10aWVyIGZhbGxiYWNrOiB0aGlyZC1wYXJ0eSBBSSBwcm92aWRlciAoREIpIFx1MjE5MiBHZW1pbmkgU0RLLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElBSVNlcnZpY2Uge1xuICAvKipcbiAgICogR2VuZXJhdGUgdGV4dCB2aWEgdGhlIGNvbmZpZ3VyZWQgQUkgcHJvdmlkZXIgb3IgR2VtaW5pIGZhbGxiYWNrLlxuICAgKlxuICAgKiBAcGFyYW0gcHJvbXB0IC0gVGhlIHVzZXIgbWVzc2FnZSAvIHByb21wdCB0ZXh0LlxuICAgKiBAcGFyYW0gb3B0aW9ucyAtIE9wdGlvbmFsIHN5c3RlbSBpbnN0cnVjdGlvbiBhbmQgdGVtcGVyYXR1cmUuXG4gICAqIEByZXR1cm5zIFRoZSB0cmltbWVkIHJlc3BvbnNlIHRleHQuXG4gICAqL1xuICBnZW5lcmF0ZVRleHQoXG4gICAgcHJvbXB0OiBzdHJpbmcsXG4gICAgb3B0aW9ucz86IHsgc3lzdGVtSW5zdHJ1Y3Rpb24/OiBzdHJpbmc7IHRlbXBlcmF0dXJlPzogbnVtYmVyIH0sXG4gICk6IFByb21pc2U8c3RyaW5nPjtcbn1cblxuLy8gXHUyNTAwXHUyNTAwIFRva2VuIGluc3RhbmNlcyAoRC0xMykgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG5cbi8qKlxuICogVG9rZW4gZm9yIElDb21tYW5kQnVzU2VydmljZS5cbiAqIElkZW50aWZpZXI6IEBvcGVubGVhcm4vY29yZTpJQ29tbWFuZEJ1c1NlcnZpY2VcbiAqL1xuZXhwb3J0IGNvbnN0IElDb21tYW5kQnVzU2VydmljZVRva2VuID0gbmV3IFRva2VuPElDb21tYW5kQnVzU2VydmljZT4oXG4gICdAb3BlbmxlYXJuL2NvcmU6SUNvbW1hbmRCdXNTZXJ2aWNlJyxcbik7XG5cbi8qKlxuICogVG9rZW4gZm9yIElFdmVudEJ1c1NlcnZpY2UuXG4gKiBJZGVudGlmaWVyOiBAb3BlbmxlYXJuL2NvcmU6SUV2ZW50QnVzU2VydmljZVxuICovXG5leHBvcnQgY29uc3QgSUV2ZW50QnVzU2VydmljZVRva2VuID0gbmV3IFRva2VuPElFdmVudEJ1c1NlcnZpY2U+KFxuICAnQG9wZW5sZWFybi9jb3JlOklFdmVudEJ1c1NlcnZpY2UnLFxuKTtcblxuLyoqXG4gKiBUb2tlbiBmb3IgSUFjdGlvblJlZ2lzdHJ5U2VydmljZS5cbiAqIElkZW50aWZpZXI6IEBvcGVubGVhcm4vY29yZTpJQWN0aW9uUmVnaXN0cnlTZXJ2aWNlXG4gKi9cbmV4cG9ydCBjb25zdCBJQWN0aW9uUmVnaXN0cnlTZXJ2aWNlVG9rZW4gPSBuZXcgVG9rZW48SUFjdGlvblJlZ2lzdHJ5U2VydmljZT4oXG4gICdAb3BlbmxlYXJuL2NvcmU6SUFjdGlvblJlZ2lzdHJ5U2VydmljZScsXG4pO1xuXG4vKipcbiAqIFRva2VuIGZvciBJQ2FwYWJpbGl0eVNlcnZpY2UuXG4gKiBJZGVudGlmaWVyOiBAb3BlbmxlYXJuL2NvcmU6SUNhcGFiaWxpdHlTZXJ2aWNlXG4gKi9cbmV4cG9ydCBjb25zdCBJQ2FwYWJpbGl0eVNlcnZpY2VUb2tlbiA9IG5ldyBUb2tlbjxJQ2FwYWJpbGl0eVNlcnZpY2U+KFxuICAnQG9wZW5sZWFybi9jb3JlOklDYXBhYmlsaXR5U2VydmljZScsXG4pO1xuXG4vKipcbiAqIFRva2VuIGZvciBJUHJvY2Vzc1NlcnZpY2UuXG4gKiBJZGVudGlmaWVyOiBAb3BlbmxlYXJuL2NvcmU6SVByb2Nlc3NTZXJ2aWNlXG4gKi9cbmV4cG9ydCBjb25zdCBJUHJvY2Vzc1NlcnZpY2VUb2tlbiA9IG5ldyBUb2tlbjxJUHJvY2Vzc1NlcnZpY2U+KFxuICAnQG9wZW5sZWFybi9jb3JlOklQcm9jZXNzU2VydmljZScsXG4pO1xuXG4vKipcbiAqIFRva2VuIGZvciBJU3RvcmFnZVNlcnZpY2UuXG4gKiBJZGVudGlmaWVyOiBAb3BlbmxlYXJuL2NvcmU6SVN0b3JhZ2VTZXJ2aWNlXG4gKi9cbmV4cG9ydCBjb25zdCBJU3RvcmFnZVNlcnZpY2VUb2tlbiA9IG5ldyBUb2tlbjxJU3RvcmFnZVNlcnZpY2U+KFxuICAnQG9wZW5sZWFybi9jb3JlOklTdG9yYWdlU2VydmljZScsXG4pO1xuXG4vKipcbiAqIFRva2VuIGZvciBJQUlTZXJ2aWNlLlxuICogSWRlbnRpZmllcjogQG9wZW5sZWFybi9jb3JlOklBSVNlcnZpY2VcbiAqL1xuZXhwb3J0IGNvbnN0IElBSVNlcnZpY2VUb2tlbiA9IG5ldyBUb2tlbjxJQUlTZXJ2aWNlPihcbiAgJ0BvcGVubGVhcm4vY29yZTpJQUlTZXJ2aWNlJyxcbik7XG5cbi8qKlxuICogVG9rZW4gZm9yIERhdGFiYXNlLlxuICogSWRlbnRpZmllcjogQG9wZW5sZWFybi9jb3JlOklEYXRhYmFzZVxuICovXG5leHBvcnQgY29uc3QgSURhdGFiYXNlVG9rZW4gPSBuZXcgVG9rZW48aW1wb3J0KCdiZXR0ZXItc3FsaXRlMycpLkRhdGFiYXNlPihcbiAgJ0BvcGVubGVhcm4vY29yZTpJRGF0YWJhc2UnLFxuKTtcblxuaW1wb3J0IHR5cGUgeyBQbHVnaW5Ib3N0IH0gZnJvbSAnLi4vcGx1Z2luLWhvc3QvaW5kZXguanMnO1xuXG4vKipcbiAqIFRva2VuIGZvciBQbHVnaW5Ib3N0LlxuICogSWRlbnRpZmllcjogQG9wZW5sZWFybi9jb3JlOklQbHVnaW5Ib3N0XG4gKi9cbmV4cG9ydCBjb25zdCBJUGx1Z2luSG9zdFRva2VuID0gbmV3IFRva2VuPFBsdWdpbkhvc3Q+KFxuICAnQG9wZW5sZWFybi9jb3JlOklQbHVnaW5Ib3N0Jyxcbik7XG5cbi8qKlxuICogSW50ZXJmYWNlIGZvciBTZW1lc3RlckdyYWRlU2VydmljZS5cbiAqIEhhbmRsZXMgc3luY2luZyBmaW5hbCBjYWxjdWxhdGVkIHJlZ3VsYXIgc2NvcmVzIGludG8gdGhlIGhvc3QncyBzZW1lc3RlciBncmFkZXMgc3lzdGVtLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElTZW1lc3RlckdyYWRlU2VydmljZSB7XG4gIC8qKlxuICAgKiBTeW5jIGNhbGN1bGF0ZWQgcmVndWxhciBzY29yZSB0byBob3N0IGRhdGFiYXNlIHN0cnVjdHVyZXMuXG4gICAqIEludGVybmFsIGltcGxlbWVudGF0aW9uIGhhbmRsZXMgbWFwcGluZyBsZXNzb25JZCAtPiBjbGFzc0lkLCBlbnN1cmluZyB0aGVcbiAgICogcmVwcmVzZW50YXRpdmUgYXNzaWdubWVudCBleGlzdHMsIGFuZCBpbnNlcnRpbmcvdXBkYXRpbmcgYXNzaWdubWVudF9zdWJtaXNzaW9ucy5cbiAgICovXG4gIHNhdmVTZW1lc3RlckdyYWRlKGxlc3NvbklkOiBzdHJpbmcsIHN0dWRlbnRJZDogc3RyaW5nLCBncmFkZTogbnVtYmVyKTogUHJvbWlzZTx2b2lkPjtcbn1cblxuLyoqXG4gKiBUb2tlbiBmb3IgSVNlbWVzdGVyR3JhZGVTZXJ2aWNlLlxuICogSWRlbnRpZmllcjogQG9wZW5sZWFybi9jb3JlOklTZW1lc3RlckdyYWRlU2VydmljZVxuICovXG5leHBvcnQgY29uc3QgSVNlbWVzdGVyR3JhZGVTZXJ2aWNlVG9rZW4gPSBuZXcgVG9rZW48SVNlbWVzdGVyR3JhZGVTZXJ2aWNlPihcbiAgJ0BvcGVubGVhcm4vY29yZTpJU2VtZXN0ZXJHcmFkZVNlcnZpY2UnXG4pO1xuXG5cbiIsICIvKipcbiAqIFx1OEJGRVx1NTgwMlx1NzlFRlx1NTIwNlx1NjM5Mlx1ODg0Q1x1Njk5Q1x1NjNEMlx1NEVGNiAoQ2xhc3Nyb29tIExlYWRlcmJvYXJkKVxuICpcbiAqIFx1NTI5Rlx1ODBGRFx1Njk4Mlx1OEZGMFx1RkYxQVxuICogLSBcdTY1NTlcdTVFMDhcdTUzRUZcdTdFRDlcdTVCNjZcdTc1MUZcdTUyQTBcdTUxQ0ZcdTc5RUZcdTUyMDZcdUZGMDhcdTY1MkZcdTYzMDFcdTk4ODRcdThCQkVcdTUzOUZcdTU2RTBcdTZBMjFcdTY3N0ZcdUZGMDlcbiAqIC0gXHU3NjdEXHU2NzdGXHU1QjlFXHU2NUY2XHU2MzkyXHU4ODRDXHU2OTlDXHU1QzU1XHU3OTNBXHVGRjA4XHU0RTJBXHU0RUJBL1x1NUMwRlx1N0VDNFx1NEUyNFx1NzlDRFx1NkEyMVx1NUYwRlx1RkYwOVxuICogLSBcdTc5RUZcdTUyMDZcdTUzRDhcdTUyQThcdTUzODZcdTUzRjJcdTY3RTVcdThCRTJcbiAqIC0gXHU1QjY2XHU2NzFGXHU5MUNEXHU3RjZFXG4gKiAtIEFJIEFnZW50IFx1NTNFRlx1NTNEMVx1NzNCMFx1NUU3Nlx1OEMwM1x1NzUyOFx1NzlFRlx1NTIwNlx1N0JBMVx1NzQwNlx1NURFNVx1NTE3N1xuICogLSBcdThCRkVcdTU4MDJcdTVERTVcdTUxNzdcdTY4MEZcdTRFMDBcdTk1MkVcdTY0Q0RcdTRGNUNcbiAqXG4gKiBcdTYyODBcdTY3MkZcdTZGMTRcdTc5M0FcdUZGMUFcbiAqIC0gY3R4LmRiLmVuc3VyZVRhYmxlICAgIFx1MjE5MiBcdTgxRUFcdTVFRkFcdTg4NjhcdTYzMDFcdTRFNDVcdTUzMTZcbiAqIC0gY3R4LnNlcnZpY2VzLnN0b3JhZ2UgIFx1MjE5MiBLViBcdTkxNERcdTdGNkVcdTVCNThcdTUwQThcbiAqIC0gY3R4LnNlcnZpY2VzLmV2ZW50QnVzIFx1MjE5MiBcdTRFOEJcdTRFRjZcdThCQTJcdTk2MDVcdUZGMDhcdTc2RDFcdTU0MkNcdTVCNjZcdTc1MUZcdTZDRThcdTUxOENcdUZGMDlcbiAqIC0gY3R4LnJlc29sdmUoSURhdGFiYXNlKSBcdTIxOTIgXHU3NkY0XHU2M0E1XHU4QkJGXHU5NUVFXHU0RTNCXHU2NTcwXHU2MzZFXHU1RTkzXG4gKiAtIGNvbW1hbmRCdXMuZXhlY3V0ZSAgICAgXHUyMTkyIFx1OEMwM1x1NzUyOFx1NTE4NVx1NjgzOFx1NzY3RFx1Njc3Rlx1NTQ3RFx1NEVFNFxuICogLSBhY3Rpb25SZWdpc3RyeSAgICAgICAgIFx1MjE5MiBcdTZDRThcdTUxOEMgQUkgXHU1REU1XHU1MTc3XG4gKiAtIGNsYXNzcm9vbVRvb2xzICAgICAgICAgXHUyMTkyIFx1OEJGRVx1NTgwMlx1NURFNVx1NTE3N1x1NjgwRlx1NjMwOVx1OTRBRVxuICogLSBwcm9jZXNzTWFuYWdlciAgICAgICAgIFx1MjE5MiBcdTVCOUFcdTY1RjZcdTRFRkJcdTUyQTFcdUZGMDhcdTVCNjZcdTY3MUZcdTgxRUFcdTUyQThcdTZDNDdcdTYwM0JcdUZGMDlcbiAqL1xuXG5pbXBvcnQgdHlwZSB7IFBsdWdpbkNvbnRleHQgfSBmcm9tICcuLi8uLi9jb3JlL3BsdWdpbi1ob3N0L3R5cGVzLmpzJztcbmltcG9ydCB7IElEYXRhYmFzZVRva2VuIH0gZnJvbSAnLi4vLi4vY29yZS9kaS9pbnRlcmZhY2VzLmpzJztcblxuLy8gXHUyNTAwXHUyNTAwIFx1NzlFRlx1NTIwNlx1NTM5Rlx1NTZFMFx1OTg4NFx1OEJCRVx1NkEyMVx1Njc3RiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbmNvbnN0IFBPSU5UX1BSRVNFVFMgPSB7XG4gIHBvc2l0aXZlOiBbXG4gICAgeyByZWFzb246ICdcdTRFM0JcdTUyQThcdTU2REVcdTdCNTRcdTk1RUVcdTk4OTgnLCBwb2ludHM6IDUsIGNhdGVnb3J5OiAnXHU4QkZFXHU1ODAyXHU0RTkyXHU1MkE4JyB9LFxuICAgIHsgcmVhc29uOiAnXHU0RjVDXHU0RTFBXHU1QjhDXHU2MjEwXHU0RjE4XHU3OUMwJywgcG9pbnRzOiAxMCwgY2F0ZWdvcnk6ICdcdTRGNUNcdTRFMUFcdTg4NjhcdTczQjAnIH0sXG4gICAgeyByZWFzb246ICdcdTVFMkVcdTUyQTlcdTU0MENcdTVCNjZcdTg5RTNcdTdCNTQnLCBwb2ludHM6IDMsIGNhdGVnb3J5OiAnXHU0RTkyXHU1MkE5XHU1NDA4XHU0RjVDJyB9LFxuICAgIHsgcmVhc29uOiAnXHU4QkZFXHU1ODAyXHU3OUVGXHU2NzgxXHU1M0QxXHU4QTAwJywgcG9pbnRzOiAzLCBjYXRlZ29yeTogJ1x1OEJGRVx1NTgwMlx1NEU5Mlx1NTJBOCcgfSxcbiAgICB7IHJlYXNvbjogJ1x1NUMwRlx1N0VDNFx1NkM0N1x1NjJBNVx1NTFGQVx1ODI3MicsIHBvaW50czogOCwgY2F0ZWdvcnk6ICdcdTU2RTJcdTk2MUZcdTUzNEZcdTRGNUMnIH0sXG4gICAgeyByZWFzb246ICdcdTgwMDNcdThCRDVcdTYyMTBcdTdFRTlcdThGREJcdTZCNjUnLCBwb2ludHM6IDEwLCBjYXRlZ29yeTogJ1x1NUI2Nlx1NEUxQVx1OEZEQlx1NkI2NScgfSxcbiAgICB7IHJlYXNvbjogJ1x1NjMwOVx1NjVGNlx1NUI4Q1x1NjIxMFx1OTg4NFx1NEU2MFx1NEVGQlx1NTJBMScsIHBvaW50czogNSwgY2F0ZWdvcnk6ICdcdTVCNjZcdTRFNjBcdTRFNjBcdTYwRUYnIH0sXG4gICAgeyByZWFzb246ICdcdTVCOUVcdTlBOENcdTY0Q0RcdTRGNUNcdTg5QzRcdTgzMDMnLCBwb2ludHM6IDUsIGNhdGVnb3J5OiAnXHU1QjlFXHU4REY1XHU4MEZEXHU1MjlCJyB9LFxuICBdLFxuICBuZWdhdGl2ZTogW1xuICAgIHsgcmVhc29uOiAnXHU0RTBBXHU4QkZFXHU4RkRGXHU1MjMwJywgcG9pbnRzOiAtMiwgY2F0ZWdvcnk6ICdcdTdFQUFcdTVGOEJcdTgwMDNcdTUyRTQnIH0sXG4gICAgeyByZWFzb246ICdcdTY3MkFcdTVCOENcdTYyMTBcdThCRkVcdTU0MEVcdTRGNUNcdTRFMUEnLCBwb2ludHM6IC01LCBjYXRlZ29yeTogJ1x1NEY1Q1x1NEUxQVx1ODg2OFx1NzNCMCcgfSxcbiAgICB7IHJlYXNvbjogJ1x1OEJGRVx1NTgwMlx1NTVBN1x1NTREN1x1NjI3MFx1NEU3MVx1NzlFOVx1NUU4RicsIHBvaW50czogLTMsIGNhdGVnb3J5OiAnXHU3RUFBXHU1RjhCXHU4MDAzXHU1MkU0JyB9LFxuICAgIHsgcmVhc29uOiAnXHU0RTBBXHU4QkZFXHU2NzFGXHU5NUY0XHU0RjdGXHU3NTI4XHU2MjRCXHU2NzNBJywgcG9pbnRzOiAtNSwgY2F0ZWdvcnk6ICdcdTdFQUFcdTVGOEJcdTgwMDNcdTUyRTQnIH0sXG4gICAgeyByZWFzb246ICdcdTYyODRcdTg4QURcdTRFRDZcdTRFQkFcdTRGNUNcdTRFMUEnLCBwb2ludHM6IC0xMCwgY2F0ZWdvcnk6ICdcdTVCNjZcdTY3MkZcdThCREFcdTRGRTEnIH0sXG4gIF0sXG59O1xuXG4vLyBcdTI1MDBcdTI1MDAgXHU2MzkyXHU4ODRDXHU2OTlDXHU2RTMyXHU2N0QzXHU5MTREXHU3RjZFIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuY29uc3QgQk9BUkRfU1RZTEUgPSB7XG4gIHRpdGxlOiAnXHVEODNDXHVERkM2IFx1OEJGRVx1NTgwMlx1NzlFRlx1NTIwNlx1NjM5Mlx1ODg0Q1x1Njk5QycsXG4gIHBlcnNvbmFsVGl0bGU6ICdcdUQ4M0NcdURGQzYgXHU0RTJBXHU0RUJBXHU3OUVGXHU1MjA2XHU2MzkyXHU4ODRDXHU2OTlDJyxcbiAgZ3JvdXBUaXRsZTogJ1x1RDgzRFx1REM2NSBcdTVDMEZcdTdFQzRcdTc5RUZcdTUyMDZcdTYzOTJcdTg4NENcdTY5OUMnLFxuICBkaXZpZGVyOiAnXHUyNTAxJy5yZXBlYXQoMjgpLFxuICBtZWRhbENvbG9yczogWycjRkZENzAwJywgJyNDMEMwQzAnLCAnI0NEN0YzMiddLCAvLyBcdTkxRDEvXHU5NEY2L1x1OTREQ1xufTtcblxuZXhwb3J0IGRlZmF1bHQge1xuICBtYW5pZmVzdDoge1xuICAgIGlkOiAnZXh0LWNsYXNzcm9vbS1sZWFkZXJib2FyZCcsXG4gICAgbmFtZTogJ1x1OEJGRVx1NTgwMlx1NzlFRlx1NTIwNlx1NjM5Mlx1ODg0Q1x1Njk5QycsXG4gICAgdmVyc2lvbjogJzEuMC4wJyxcbiAgfSxcblxuICAvLyBcdTI1MDBcdTI1MDAgXHU2M0QyXHU0RUY2XHU2RkMwXHU2RDNCXHU1MTY1XHU1M0UzIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICBhY3RpdmF0ZTogYXN5bmMgKGN0eDogUGx1Z2luQ29udGV4dCkgPT4ge1xuICAgIGNvbnN0IHsgY29tbWFuZEJ1cywgYWN0aW9uUmVnaXN0cnksIGV2ZW50QnVzLCBzdG9yYWdlIH0gPVxuICAgICAgY3R4LnNlcnZpY2VzO1xuXG4gICAgY29uc29sZS5sb2coYFtMZWFkZXJib2FyZF0gXHVEODNEXHVERTgwIFx1NkZDMFx1NkQzQlx1NjNEMlx1NEVGNjogJHtjdHgucGx1Z2luSWR9IHYke2N0eC5tYW5pZmVzdC52ZXJzaW9ufWApO1xuXG4gICAgLy8gXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXG4gICAgLy8gMS4gXHU1MjFEXHU1OUNCXHU1MzE2XHU4MUVBXHU1RUZBXHU4ODY4XG4gICAgLy8gXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXG4gICAgYXdhaXQgY3R4LmRiLmVuc3VyZVRhYmxlKFxuICAgICAgJ3JlY29yZHMnLFxuICAgICAgYGlkIFRFWFQgUFJJTUFSWSBLRVksXG4gICAgICAgc3R1ZGVudF9pZCBURVhUIE5PVCBOVUxMLFxuICAgICAgIHN0dWRlbnRfbmFtZSBURVhUIE5PVCBOVUxMLFxuICAgICAgIGNsYXNzX2lkIFRFWFQgTk9UIE5VTEwsXG4gICAgICAgcG9pbnRzIElOVEVHRVIgTk9UIE5VTEwsXG4gICAgICAgcmVhc29uIFRFWFQgTk9UIE5VTEwsXG4gICAgICAgY2F0ZWdvcnkgVEVYVCBERUZBVUxUICdcdTUxNzZcdTRFRDYnLFxuICAgICAgIG9wZXJhdG9yIFRFWFQgREVGQVVMVCAndGVhY2hlcicsXG4gICAgICAgY3JlYXRlZF9hdCBJTlRFR0VSIE5PVCBOVUxMYCxcbiAgICApO1xuXG4gICAgY29uc29sZS5sb2coJ1tMZWFkZXJib2FyZF0gXHUyNzA1IFx1NjU3MFx1NjM2RVx1NUU5M1x1ODg2OFx1NTIxRFx1NTlDQlx1NTMxNlx1NUI4Q1x1NjIxMCcpO1xuXG4gICAgLy8gXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXG4gICAgLy8gMi4gXHU2Q0U4XHU1MThDIEFJIEFnZW50IFx1NTNFRlx1NTNEMVx1NzNCMFx1NzY4NCBBY3Rpb25zXG4gICAgLy8gXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXHUyNTUwXG5cbiAgICAvLyBBY3Rpb24gQVx1RkYxQVx1NTJBMFx1NTFDRlx1NzlFRlx1NTIwNlxuICAgIGF3YWl0IGFjdGlvblJlZ2lzdHJ5LnJlZ2lzdGVyKHtcbiAgICAgIGlkOiAnZXh0LWxlYWRlcmJvYXJkLWFkZC1wb2ludHMnLFxuICAgICAgY29tbWFuZFR5cGU6ICdsZWFkZXJib2FyZC5hZGRfcG9pbnRzJyxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAnXHUzMDEwXHU4QkZFXHU1ODAyXHU3OUVGXHU1MjA2XHU3QkExXHU3NDA2XHUzMDExXHU3RUQ5XHU1QjY2XHU3NTFGXHU2REZCXHU1MkEwXHU2MjE2XHU2MjYzXHU5NjY0XHU3OUVGXHU1MjA2XHUzMDAyJyArXG4gICAgICAgICdcdTUyQTBcdTUyMDZcdTU3M0FcdTY2NkZcdUZGMUFcdTU2REVcdTdCNTRcdTk1RUVcdTk4OTgoKzUpXHUzMDAxXHU0RjE4XHU3OUMwXHU0RjVDXHU0RTFBKCsxMClcdTMwMDFcdTVFMkVcdTUyQTlcdTU0MENcdTVCNjYoKzMpXHUzMDAxXHU3OUVGXHU2NzgxXHU1M0QxXHU4QTAwKCszKVx1MzAwMicgK1xuICAgICAgICAnXHU2MjYzXHU1MjA2XHU1NzNBXHU2NjZGXHVGRjFBXHU4RkRGXHU1MjMwKC0yKVx1MzAwMVx1N0YzQVx1NEVBNFx1NEY1Q1x1NEUxQSgtNSlcdTMwMDFcdThCRkVcdTU4MDJcdTU1QTdcdTU0RDcoLTMpXHUzMDAyJyArXG4gICAgICAgICdcdThCRjdcdTU5Q0JcdTdFQzhcdTYzRDBcdTRGOUIgcmVhc29uIFx1NUI1N1x1NkJCNVx1OEJGNFx1NjYwRVx1NTM5Rlx1NTZFMFx1MzAwMicsXG4gICAgICBjYXBhYmlsaXR5UmVxdWlyZWQ6ICd3aGl0ZWJvYXJkOndyaXRlJyxcbiAgICAgIGlucHV0U2NoZW1hOiB7XG4gICAgICAgIHR5cGU6ICdPQkpFQ1QnLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgc3R1ZGVudElkOiB7XG4gICAgICAgICAgICB0eXBlOiAnU1RSSU5HJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnXHU1QjY2XHU3NTFGIElEJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHN0dWRlbnROYW1lOiB7XG4gICAgICAgICAgICB0eXBlOiAnU1RSSU5HJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnXHU1QjY2XHU3NTFGXHU1OUQzXHU1NDBEXHVGRjA4XHU3NTI4XHU0RThFXHU2MzkyXHU4ODRDXHU2OTlDXHU2NjNFXHU3OTNBXHVGRjA5JyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNsYXNzSWQ6IHtcbiAgICAgICAgICAgIHR5cGU6ICdTVFJJTkcnLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdcdTczRURcdTdFQTcgSUQnLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcG9pbnRzOiB7XG4gICAgICAgICAgICB0eXBlOiAnSU5URUdFUicsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1x1NzlFRlx1NTIwNlx1NTNEOFx1NTJBOFx1NTAzQ1x1RkYwOFx1NkI2M1x1NjU3MFx1NTJBMFx1NTIwNlx1RkYwQ1x1OEQxRlx1NjU3MFx1NjI2M1x1NTIwNlx1RkYwOScsXG4gICAgICAgICAgfSxcbiAgICAgICAgICByZWFzb246IHtcbiAgICAgICAgICAgIHR5cGU6ICdTVFJJTkcnLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdcdTc5RUZcdTUyMDZcdTUzRDhcdTUyQThcdTUzOUZcdTU2RTBcdUZGMENcdTU5ODJcIlx1NEUzQlx1NTJBOFx1NTZERVx1N0I1NFx1OTVFRVx1OTg5OFwiJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGNhdGVnb3J5OiB7XG4gICAgICAgICAgICB0eXBlOiAnU1RSSU5HJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnXHU3OUVGXHU1MjA2XHU1MjA2XHU3QzdCXHVGRjFBXHU4QkZFXHU1ODAyXHU0RTkyXHU1MkE4L1x1NEY1Q1x1NEUxQVx1ODg2OFx1NzNCMC9cdTdFQUFcdTVGOEJcdTgwMDNcdTUyRTQvXHU0RTkyXHU1MkE5XHU1NDA4XHU0RjVDL1x1NTZFMlx1OTYxRlx1NTM0Rlx1NEY1Qy9cdTVCNjZcdTRFMUFcdThGREJcdTZCNjUvXHU1QjY2XHU0RTYwXHU0RTYwXHU2MEVGL1x1NUI5RVx1OERGNVx1ODBGRFx1NTI5Qi9cdTVCNjZcdTY3MkZcdThCREFcdTRGRTEnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHJlcXVpcmVkOiBbJ3N0dWRlbnRJZCcsICdzdHVkZW50TmFtZScsICdjbGFzc0lkJywgJ3BvaW50cycsICdyZWFzb24nXSxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICAvLyBBY3Rpb24gQlx1RkYxQVx1NzY3RFx1Njc3Rlx1NUM1NVx1NzkzQVx1NjM5Mlx1ODg0Q1x1Njk5Q1xuICAgIGF3YWl0IGFjdGlvblJlZ2lzdHJ5LnJlZ2lzdGVyKHtcbiAgICAgIGlkOiAnZXh0LWxlYWRlcmJvYXJkLXNob3cnLFxuICAgICAgY29tbWFuZFR5cGU6ICdsZWFkZXJib2FyZC5zaG93X2JvYXJkJyxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAnXHUzMDEwXHU3NjdEXHU2NzdGXHU1QzU1XHU3OTNBXHU2MzkyXHU4ODRDXHU2OTlDXHUzMDExXHU1NzI4XHU4QkZFXHU1ODAyXHU0RTkyXHU1MkE4XHU3NjdEXHU2NzdGXHU0RTBBXHU1QzU1XHU3OTNBXHU1RjUzXHU1MjREXHU3M0VEXHU3RUE3XHU3Njg0XHU3OUVGXHU1MjA2XHU2MzkyXHU4ODRDXHU2OTlDXHUzMDAyJyArXG4gICAgICAgICdcdTY1MkZcdTYzMDFcdTRFMkFcdTRFQkFcdTYzOTJcdTg4NEMocGVyc29uYWwpXHU1NDhDXHU1QzBGXHU3RUM0XHU2MzkyXHU4ODRDKGdyb3VwKVx1NEUyNFx1NzlDRFx1NkEyMVx1NUYwRlx1MzAwMicgK1xuICAgICAgICAnXHU2MzkyXHU4ODRDXHU2OTlDXHU0RjFBXHU2RTMyXHU2N0QzXHU0RTNBXHU5MTkyXHU3NkVFXHU3Njg0XHU2ODNDXHU1RjBGXHU1MzE2XHU2NTg3XHU2NzJDXHVGRjBDXHU1MTY4XHU3M0VEXHU1QjY2XHU3NTFGXHU1M0VGXHU4OUMxXHUzMDAyJyxcbiAgICAgIGNhcGFiaWxpdHlSZXF1aXJlZDogJ3doaXRlYm9hcmQ6d3JpdGUnLFxuICAgICAgaW5wdXRTY2hlbWE6IHtcbiAgICAgICAgdHlwZTogJ09CSkVDVCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBsZXNzb25JZDoge1xuICAgICAgICAgICAgdHlwZTogJ1NUUklORycsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1x1NTE3M1x1ODA1NFx1NzY4NFx1OEJGRVx1NjVGNiBJRFx1RkYwOFx1NzUyOFx1NEU4RVx1NUI5QVx1NEY0RFx1NzUzQlx1Njc3Rlx1RkYwOScsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBjbGFzc0lkOiB7XG4gICAgICAgICAgICB0eXBlOiAnU1RSSU5HJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnXHU3M0VEXHU3RUE3IElEJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIG1vZGU6IHtcbiAgICAgICAgICAgIHR5cGU6ICdTVFJJTkcnLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdcdTYzOTJcdTg4NENcdTZBMjFcdTVGMEZcdUZGMUFwZXJzb25hbFx1RkYwOFx1NEUyQVx1NEVCQVx1NjM5Mlx1ODg0Q1x1RkYwOVx1NjIxNiBncm91cFx1RkYwOFx1NUMwRlx1N0VDNFx1NjM5Mlx1ODg0Q1x1RkYwOVx1RkYwQ1x1OUVEOFx1OEJBNCBwZXJzb25hbCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB0b3BOOiB7XG4gICAgICAgICAgICB0eXBlOiAnSU5URUdFUicsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1x1NjYzRVx1NzkzQVx1NTI0RCBOIFx1NTQwRFx1NUI2Nlx1NzUxRlx1RkYwQ1x1OUVEOFx1OEJBNCAxMCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgcmVxdWlyZWQ6IFsnbGVzc29uSWQnLCAnY2xhc3NJZCddLFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIC8vIEFjdGlvbiBDXHVGRjFBXHU2N0U1XHU4QkUyXHU2MzkyXHU4ODRDXHU2NTcwXHU2MzZFXG4gICAgYXdhaXQgYWN0aW9uUmVnaXN0cnkucmVnaXN0ZXIoe1xuICAgICAgaWQ6ICdleHQtbGVhZGVyYm9hcmQtcmFua2luZycsXG4gICAgICBjb21tYW5kVHlwZTogJ2xlYWRlcmJvYXJkLmdldF9yYW5raW5nJyxcbiAgICAgIGRlc2NyaXB0aW9uOlxuICAgICAgICAnXHUzMDEwXHU2N0U1XHU4QkUyXHU3OUVGXHU1MjA2XHU2MzkyXHU1NDBEXHUzMDExXHU4M0I3XHU1M0Q2XHU2MzA3XHU1QjlBXHU3M0VEXHU3RUE3XHU3Njg0XHU1QjY2XHU3NTFGXHU3OUVGXHU1MjA2XHU2MzkyXHU1NDBEXHU2NTcwXHU2MzZFXHVGRjBDXHU4RkQ0XHU1NkRFXHU1QjY2XHU3NTFGSURcdTMwMDFcdTU5RDNcdTU0MERcdTMwMDFcdTYwM0JcdTc5RUZcdTUyMDZcdTU0OENcdTYzOTJcdTU0MERcdTMwMDInLFxuICAgICAgY2FwYWJpbGl0eVJlcXVpcmVkOiAnbWFuYWdlbWVudDpyZWFkJyxcbiAgICAgIGlucHV0U2NoZW1hOiB7XG4gICAgICAgIHR5cGU6ICdPQkpFQ1QnLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgY2xhc3NJZDoge1xuICAgICAgICAgICAgdHlwZTogJ1NUUklORycsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1x1NzNFRFx1N0VBNyBJRCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBtb2RlOiB7XG4gICAgICAgICAgICB0eXBlOiAnU1RSSU5HJyxcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiAnXHU2MzkyXHU4ODRDXHU2QTIxXHU1RjBGXHVGRjFBcGVyc29uYWwgLyBncm91cFx1RkYwQ1x1OUVEOFx1OEJBNCBwZXJzb25hbCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBsaW1pdDoge1xuICAgICAgICAgICAgdHlwZTogJ0lOVEVHRVInLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdcdThGRDRcdTU2REVcdTUyNEQgTiBcdTU0MERcdUZGMENcdTlFRDhcdThCQTRcdTUxNjhcdTkwRTgnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHJlcXVpcmVkOiBbJ2NsYXNzSWQnXSxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICAvLyBBY3Rpb24gRFx1RkYxQVx1NjdFNVx1OEJFMlx1NzlFRlx1NTIwNlx1NTM4Nlx1NTNGMlxuICAgIGF3YWl0IGFjdGlvblJlZ2lzdHJ5LnJlZ2lzdGVyKHtcbiAgICAgIGlkOiAnZXh0LWxlYWRlcmJvYXJkLWhpc3RvcnknLFxuICAgICAgY29tbWFuZFR5cGU6ICdsZWFkZXJib2FyZC5nZXRfaGlzdG9yeScsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgJ1x1MzAxMFx1NzlFRlx1NTIwNlx1NTM4Nlx1NTNGMlx1NjdFNVx1OEJFMlx1MzAxMVx1NjdFNVx1OEJFMlx1NjMwN1x1NUI5QVx1NUI2Nlx1NzUxRlx1NjIxNlx1NjU3NFx1NEUyQVx1NzNFRFx1N0VBN1x1NzY4NFx1NzlFRlx1NTIwNlx1NTNEOFx1NTJBOFx1NTM4Nlx1NTNGMlx1OEJCMFx1NUY1NVx1MzAwMicsXG4gICAgICBjYXBhYmlsaXR5UmVxdWlyZWQ6ICdtYW5hZ2VtZW50OnJlYWQnLFxuICAgICAgaW5wdXRTY2hlbWE6IHtcbiAgICAgICAgdHlwZTogJ09CSkVDVCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBzdHVkZW50SWQ6IHtcbiAgICAgICAgICAgIHR5cGU6ICdTVFJJTkcnLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdcdTVCNjZcdTc1MUYgSURcdUZGMDhcdTUzRUZcdTkwMDlcdUZGMENcdTRFMERcdTRGMjBcdTUyMTlcdTY3RTVcdTUxNjhcdTczRURcdUZGMDknLFxuICAgICAgICAgIH0sXG4gICAgICAgICAgY2xhc3NJZDoge1xuICAgICAgICAgICAgdHlwZTogJ1NUUklORycsXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogJ1x1NzNFRFx1N0VBNyBJRCcsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBsaW1pdDoge1xuICAgICAgICAgICAgdHlwZTogJ0lOVEVHRVInLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246ICdcdThGRDRcdTU2REVcdTY3MDBcdThGRDEgTiBcdTY3NjFcdThCQjBcdTVGNTVcdUZGMENcdTlFRDhcdThCQTQgNTAnLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHJlcXVpcmVkOiBbJ2NsYXNzSWQnXSxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICAvLyBBY3Rpb24gRVx1RkYxQVx1ODNCN1x1NTNENlx1NzlFRlx1NTIwNlx1OTg4NFx1OEJCRVx1NkEyMVx1Njc3RlxuICAgIGF3YWl0IGFjdGlvblJlZ2lzdHJ5LnJlZ2lzdGVyKHtcbiAgICAgIGlkOiAnZXh0LWxlYWRlcmJvYXJkLXByZXNldHMnLFxuICAgICAgY29tbWFuZFR5cGU6ICdsZWFkZXJib2FyZC5nZXRfcHJlc2V0cycsXG4gICAgICBkZXNjcmlwdGlvbjpcbiAgICAgICAgJ1x1MzAxMFx1NzlFRlx1NTIwNlx1NTM5Rlx1NTZFMFx1NkEyMVx1Njc3Rlx1MzAxMVx1ODNCN1x1NTNENlx1NzlFRlx1NTIwNlx1NTJBMFx1NTFDRlx1NzY4NFx1OTg4NFx1OEJCRVx1NTM5Rlx1NTZFMFx1NkEyMVx1Njc3Rlx1NTIxN1x1ODg2OFx1RkYwQ1x1NTMwNVx1NTQyQlx1NUVGQVx1OEJBRVx1NzY4NFx1NTIwNlx1NTAzQ1x1NTQ4Q1x1NTIwNlx1N0M3Qlx1MzAwMicsXG4gICAgICBjYXBhYmlsaXR5UmVxdWlyZWQ6ICcnLFxuICAgICAgaW5wdXRTY2hlbWE6IHtcbiAgICAgICAgdHlwZTogJ09CSkVDVCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHt9LFxuICAgICAgICByZXF1aXJlZDogW10sXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coJ1tMZWFkZXJib2FyZF0gXHUyNzA1IEFJIEFjdGlvbnMgXHU2Q0U4XHU1MThDXHU1QjhDXHU2MjEwICg1IFx1NEUyQSknKTtcblxuICAgIC8vIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuICAgIC8vIDMuIFx1NkNFOFx1NTE4Q1x1NTQ3RFx1NEVFNFx1NTkwNFx1NzQwNlx1NTY2OFxuICAgIC8vIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuXG4gICAgLy8gXHUyNTAwXHUyNTAwIFx1NTkwNFx1NzQwNlx1NTY2OCBBOiBcdTUyQTBcdTUxQ0ZcdTc5RUZcdTUyMDYgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgYXdhaXQgY29tbWFuZEJ1cy5yZWdpc3RlckhhbmRsZXIoJ2xlYWRlcmJvYXJkLmFkZF9wb2ludHMnLCB7XG4gICAgICBleGVjdXRlOiBhc3luYyAoY29tbWFuZCkgPT4ge1xuICAgICAgICBjb25zdCBwYXlsb2FkID0gY29tbWFuZC5wYXlsb2FkIGFzIGFueTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIHN0dWRlbnRJZCxcbiAgICAgICAgICBzdHVkZW50TmFtZSxcbiAgICAgICAgICBjbGFzc0lkLFxuICAgICAgICAgIHBvaW50cyxcbiAgICAgICAgICByZWFzb24sXG4gICAgICAgICAgY2F0ZWdvcnkgPSAnXHU1MTc2XHU0RUQ2JyxcbiAgICAgICAgfSA9IHBheWxvYWQ7XG5cbiAgICAgICAgLy8gXHU1M0MyXHU2NTcwXHU2ODIxXHU5QThDXG4gICAgICAgIGlmICghc3R1ZGVudElkIHx8ICFzdHVkZW50TmFtZSB8fCAhY2xhc3NJZCB8fCBwb2ludHMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICAgIGVycm9yOiAnXHU3RjNBXHU1QzExXHU1RkM1XHU5NzAwXHU1M0MyXHU2NTcwXHVGRjFBc3R1ZGVudElkLCBzdHVkZW50TmFtZSwgY2xhc3NJZCwgcG9pbnRzJyxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHR5cGVvZiBwb2ludHMgIT09ICdudW1iZXInIHx8IHBvaW50cyA9PT0gMCkge1xuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgICAgIGVycm9yOiAnXHU3OUVGXHU1MjA2XHU1MDNDXHU1RkM1XHU5ODdCXHU0RTNBXHU5NzVFXHU5NkY2XHU2NTcwXHU1QjU3JyxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBkYiA9IChhd2FpdCBjdHgucmVzb2x2ZShJRGF0YWJhc2VUb2tlbikpIGFzIGFueTtcbiAgICAgICAgICBjb25zdCByZWNvcmRJZCA9ICdsYnJfJyArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIsIDEwKTtcbiAgICAgICAgICBjb25zdCB0aW1lc3RhbXAgPSBEYXRlLm5vdygpO1xuXG4gICAgICAgICAgLy8gXHU1MTk5XHU1MTY1XHU3OUVGXHU1MjA2XHU4QkIwXHU1RjU1XG4gICAgICAgICAgZGIucHJlcGFyZShcbiAgICAgICAgICAgIGBJTlNFUlQgSU5UTyAke2N0eC5kYi50YWJsZSgncmVjb3JkcycpfVxuICAgICAgICAgICAgIChpZCwgc3R1ZGVudF9pZCwgc3R1ZGVudF9uYW1lLCBjbGFzc19pZCwgcG9pbnRzLCByZWFzb24sIGNhdGVnb3J5LCBvcGVyYXRvciwgY3JlYXRlZF9hdClcbiAgICAgICAgICAgICBWQUxVRVMgKD8sID8sID8sID8sID8sID8sID8sID8sID8pYCxcbiAgICAgICAgICApLnJ1bihcbiAgICAgICAgICAgIHJlY29yZElkLFxuICAgICAgICAgICAgc3R1ZGVudElkLFxuICAgICAgICAgICAgc3R1ZGVudE5hbWUsXG4gICAgICAgICAgICBjbGFzc0lkLFxuICAgICAgICAgICAgcG9pbnRzLFxuICAgICAgICAgICAgcmVhc29uLFxuICAgICAgICAgICAgY2F0ZWdvcnksXG4gICAgICAgICAgICBjb21tYW5kLmFjdG9ySWQgfHwgJ3RlYWNoZXInLFxuICAgICAgICAgICAgdGltZXN0YW1wLFxuICAgICAgICAgICk7XG5cbiAgICAgICAgICAvLyBcdTY3RTVcdThCRTJcdTVGNTNcdTUyNERcdTYwM0JcdTc5RUZcdTUyMDZcbiAgICAgICAgICBjb25zdCB0b3RhbFJvdyA9IGRiXG4gICAgICAgICAgICAucHJlcGFyZShcbiAgICAgICAgICAgICAgYFNFTEVDVCBDT0FMRVNDRShTVU0ocG9pbnRzKSwgMCkgYXMgdG90YWxcbiAgICAgICAgICAgICAgIEZST00gJHtjdHguZGIudGFibGUoJ3JlY29yZHMnKX1cbiAgICAgICAgICAgICAgIFdIRVJFIHN0dWRlbnRfaWQgPSA/IEFORCBjbGFzc19pZCA9ID9gLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLmdldChzdHVkZW50SWQsIGNsYXNzSWQpIGFzIHsgdG90YWw6IG51bWJlciB9IHwgdW5kZWZpbmVkO1xuXG4gICAgICAgICAgY29uc3QgdG90YWxQb2ludHMgPSB0b3RhbFJvdz8udG90YWwgPz8gcG9pbnRzO1xuXG4gICAgICAgICAgLy8gXHU2N0U1XHU4QkUyXHU1RjUzXHU1MjREXHU2MzkyXHU1NDBEXG4gICAgICAgICAgY29uc3QgcmFua1JvdyA9IGRiXG4gICAgICAgICAgICAucHJlcGFyZShcbiAgICAgICAgICAgICAgYFNFTEVDVCBDT1VOVCgqKSArIDEgYXMgcmFuayBGUk9NIChcbiAgICAgICAgICAgICAgICAgU0VMRUNUIHN0dWRlbnRfaWQsIFNVTShwb2ludHMpIGFzIHRvdGFsXG4gICAgICAgICAgICAgICAgIEZST00gJHtjdHguZGIudGFibGUoJ3JlY29yZHMnKX1cbiAgICAgICAgICAgICAgICAgV0hFUkUgY2xhc3NfaWQgPSA/XG4gICAgICAgICAgICAgICAgIEdST1VQIEJZIHN0dWRlbnRfaWRcbiAgICAgICAgICAgICAgICAgSEFWSU5HIHRvdGFsID4gP1xuICAgICAgICAgICAgICAgKWAsXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuZ2V0KGNsYXNzSWQsIHRvdGFsUG9pbnRzKSBhcyB7IHJhbms6IG51bWJlciB9IHwgdW5kZWZpbmVkO1xuXG4gICAgICAgICAgY29uc3QgcmFuayA9IHJhbmtSb3c/LnJhbmsgPz8gMTtcblxuICAgICAgICAgIC8vIFx1NTNEMVx1NUUwM1x1NzlFRlx1NTIwNlx1NTNEOFx1NTJBOFx1NEU4Qlx1NEVGNlxuICAgICAgICAgIGF3YWl0IGV2ZW50QnVzLnB1Ymxpc2goe1xuICAgICAgICAgICAgaWQ6IGBldnRfJHtyZWNvcmRJZH1gLFxuICAgICAgICAgICAgdHlwZTogJ2xlYWRlcmJvYXJkLnBvaW50c19jaGFuZ2VkJyxcbiAgICAgICAgICAgIHNvdXJjZTogY3R4LnBsdWdpbklkLFxuICAgICAgICAgICAgcGF5bG9hZDoge1xuICAgICAgICAgICAgICByZWNvcmRJZCxcbiAgICAgICAgICAgICAgc3R1ZGVudElkLFxuICAgICAgICAgICAgICBzdHVkZW50TmFtZSxcbiAgICAgICAgICAgICAgY2xhc3NJZCxcbiAgICAgICAgICAgICAgcG9pbnRzLFxuICAgICAgICAgICAgICByZWFzb24sXG4gICAgICAgICAgICAgIGNhdGVnb3J5LFxuICAgICAgICAgICAgICB0b3RhbFBvaW50cyxcbiAgICAgICAgICAgICAgcmFuayxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0aW1lc3RhbXAsXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjb25zdCBlbW9qaSA9IHBvaW50cyA+IDAgPyAnXHVEODNEXHVEQzREJyA6ICdcdTI2QTBcdUZFMEYnO1xuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgYFtMZWFkZXJib2FyZF0gJHtlbW9qaX0gJHtzdHVkZW50TmFtZX0gJHtwb2ludHMgPiAwID8gJysnIDogJyd9JHtwb2ludHN9XHU1MjA2IGAgK1xuICAgICAgICAgICAgICBgXHUyMTkyIFx1N0QyRlx1OEJBMSAke3RvdGFsUG9pbnRzfSBcdTUyMDYgKFx1N0IyQyAke3Jhbmt9IFx1NTQwRCkgfCBcdTUzOUZcdTU2RTA6ICR7cmVhc29ufWAsXG4gICAgICAgICAgKTtcblxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgcmVjb3JkSWQsXG4gICAgICAgICAgICBzdHVkZW50TmFtZSxcbiAgICAgICAgICAgIHBvaW50c0NoYW5nZWQ6IHBvaW50cyxcbiAgICAgICAgICAgIHRvdGFsUG9pbnRzLFxuICAgICAgICAgICAgcmFuayxcbiAgICAgICAgICAgIG1lc3NhZ2U6XG4gICAgICAgICAgICAgIHBvaW50cyA+IDBcbiAgICAgICAgICAgICAgICA/IGAke3N0dWRlbnROYW1lfSArJHtwb2ludHN9XHU1MjA2XHVGRjAxXHU1RjUzXHU1MjREXHU3RDJGXHU4QkExICR7dG90YWxQb2ludHN9IFx1NTIwNlx1RkYwQ1x1NjM5Mlx1NTQwRFx1N0IyQyAke3Jhbmt9YFxuICAgICAgICAgICAgICAgIDogYCR7c3R1ZGVudE5hbWV9ICR7cG9pbnRzfVx1NTIwNlx1MzAwMlx1NUY1M1x1NTI0RFx1N0QyRlx1OEJBMSAke3RvdGFsUG9pbnRzfSBcdTUyMDZcdUZGMENcdTYzOTJcdTU0MERcdTdCMkMgJHtyYW5rfWAsXG4gICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdbTGVhZGVyYm9hcmRdIFx1NzlFRlx1NTIwNlx1NjRDRFx1NEY1Q1x1NTkzMVx1OEQyNTonLCBlcnIubWVzc2FnZSk7XG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnIubWVzc2FnZSB9O1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgLy8gXHUyNTAwXHUyNTAwIFx1NTkwNFx1NzQwNlx1NTY2OCBCOiBcdTgzQjdcdTUzRDZcdTYzOTJcdTg4NENcdTY5OUNcdTY1NzBcdTYzNkUgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgYXdhaXQgY29tbWFuZEJ1cy5yZWdpc3RlckhhbmRsZXIoJ2xlYWRlcmJvYXJkLmdldF9yYW5raW5nJywge1xuICAgICAgZXhlY3V0ZTogYXN5bmMgKGNvbW1hbmQpID0+IHtcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IGNvbW1hbmQucGF5bG9hZCBhcyBhbnk7XG4gICAgICAgIGNvbnN0IHsgY2xhc3NJZCwgbW9kZSA9ICdwZXJzb25hbCcsIGxpbWl0ID0gNTAgfSA9IHBheWxvYWQ7XG5cbiAgICAgICAgaWYgKCFjbGFzc0lkKSB7XG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnXHU3RjNBXHU1QzExXHU1RkM1XHU5NzAwXHU1M0MyXHU2NTcwXHVGRjFBY2xhc3NJZCcgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgZGIgPSAoYXdhaXQgY3R4LnJlc29sdmUoSURhdGFiYXNlVG9rZW4pKSBhcyBhbnk7XG5cbiAgICAgICAgICBjb25zdCByb3dzID0gZGJcbiAgICAgICAgICAgIC5wcmVwYXJlKFxuICAgICAgICAgICAgICBgU0VMRUNUXG4gICAgICAgICAgICAgICAgIHN0dWRlbnRfaWQsXG4gICAgICAgICAgICAgICAgIHN0dWRlbnRfbmFtZSxcbiAgICAgICAgICAgICAgICAgU1VNKHBvaW50cykgYXMgdG90YWxfcG9pbnRzLFxuICAgICAgICAgICAgICAgICBDT1VOVCgqKSBhcyByZWNvcmRfY291bnQsXG4gICAgICAgICAgICAgICAgIE1BWChjcmVhdGVkX2F0KSBhcyBsYXN0X3VwZGF0ZWRcbiAgICAgICAgICAgICAgIEZST00gJHtjdHguZGIudGFibGUoJ3JlY29yZHMnKX1cbiAgICAgICAgICAgICAgIFdIRVJFIGNsYXNzX2lkID0gP1xuICAgICAgICAgICAgICAgR1JPVVAgQlkgc3R1ZGVudF9pZFxuICAgICAgICAgICAgICAgT1JERVIgQlkgdG90YWxfcG9pbnRzIERFU0NcbiAgICAgICAgICAgICAgIExJTUlUID9gLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLmFsbChjbGFzc0lkLCBsaW1pdCkgYXMgYW55W107XG5cbiAgICAgICAgICBjb25zdCByYW5raW5nID0gcm93cy5tYXAoKHJvdzogYW55LCBpbmRleDogbnVtYmVyKSA9PiAoe1xuICAgICAgICAgICAgcmFuazogaW5kZXggKyAxLFxuICAgICAgICAgICAgc3R1ZGVudElkOiByb3cuc3R1ZGVudF9pZCxcbiAgICAgICAgICAgIHN0dWRlbnROYW1lOiByb3cuc3R1ZGVudF9uYW1lLFxuICAgICAgICAgICAgdG90YWxQb2ludHM6IHJvdy50b3RhbF9wb2ludHMsXG4gICAgICAgICAgICByZWNvcmRDb3VudDogcm93LnJlY29yZF9jb3VudCxcbiAgICAgICAgICAgIGxhc3RVcGRhdGVkOiByb3cubGFzdF91cGRhdGVkLFxuICAgICAgICAgICAgbWVkYWw6XG4gICAgICAgICAgICAgIGluZGV4ID09PSAwID8gJ1x1RDgzRVx1REQ0NycgOiBpbmRleCA9PT0gMSA/ICdcdUQ4M0VcdURENDgnIDogaW5kZXggPT09IDIgPyAnXHVEODNFXHVERDQ5JyA6ICcnLFxuICAgICAgICAgIH0pKTtcblxuICAgICAgICAgIC8vIFx1N0VERlx1OEJBMVx1NEZFMVx1NjA2RlxuICAgICAgICAgIGNvbnN0IHN0YXRzID0gZGJcbiAgICAgICAgICAgIC5wcmVwYXJlKFxuICAgICAgICAgICAgICBgU0VMRUNUXG4gICAgICAgICAgICAgICAgIENPVU5UKERJU1RJTkNUIHN0dWRlbnRfaWQpIGFzIHRvdGFsX3N0dWRlbnRzLFxuICAgICAgICAgICAgICAgICBTVU0ocG9pbnRzKSBhcyBjbGFzc190b3RhbF9wb2ludHMsXG4gICAgICAgICAgICAgICAgIEFWRyhwb2ludHMpIGFzIGF2Z19wZXJfcmVjb3JkXG4gICAgICAgICAgICAgICBGUk9NICR7Y3R4LmRiLnRhYmxlKCdyZWNvcmRzJyl9XG4gICAgICAgICAgICAgICBXSEVSRSBjbGFzc19pZCA9ID9gLFxuICAgICAgICAgICAgKVxuICAgICAgICAgICAgLmdldChjbGFzc0lkKSBhcyBhbnk7XG5cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIGNsYXNzSWQsXG4gICAgICAgICAgICBtb2RlLFxuICAgICAgICAgICAgcmFua2luZyxcbiAgICAgICAgICAgIHN0YXRzOiB7XG4gICAgICAgICAgICAgIHRvdGFsU3R1ZGVudHM6IHN0YXRzPy50b3RhbF9zdHVkZW50cyA/PyAwLFxuICAgICAgICAgICAgICBjbGFzc1RvdGFsUG9pbnRzOiBzdGF0cz8uY2xhc3NfdG90YWxfcG9pbnRzID8/IDAsXG4gICAgICAgICAgICAgIGF2Z1BlclJlY29yZDogc3RhdHM/LmF2Z19wZXJfcmVjb3JkXG4gICAgICAgICAgICAgICAgPyBNYXRoLnJvdW5kKHN0YXRzLmF2Z19wZXJfcmVjb3JkICogMTApIC8gMTBcbiAgICAgICAgICAgICAgICA6IDAsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2VuZXJhdGVkQXQ6IERhdGUubm93KCksXG4gICAgICAgICAgfTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdbTGVhZGVyYm9hcmRdIFx1NjdFNVx1OEJFMlx1NjM5Mlx1ODg0Q1x1NTkzMVx1OEQyNTonLCBlcnIubWVzc2FnZSk7XG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnIubWVzc2FnZSB9O1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgLy8gXHUyNTAwXHUyNTAwIFx1NTkwNFx1NzQwNlx1NTY2OCBDOiBcdTc2N0RcdTY3N0ZcdTVDNTVcdTc5M0FcdTYzOTJcdTg4NENcdTY5OUMgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgYXdhaXQgY29tbWFuZEJ1cy5yZWdpc3RlckhhbmRsZXIoJ2xlYWRlcmJvYXJkLnNob3dfYm9hcmQnLCB7XG4gICAgICBleGVjdXRlOiBhc3luYyAoY29tbWFuZCkgPT4ge1xuICAgICAgICBjb25zdCBwYXlsb2FkID0gY29tbWFuZC5wYXlsb2FkIGFzIGFueTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIGxlc3NvbklkLFxuICAgICAgICAgIGNsYXNzSWQsXG4gICAgICAgICAgbW9kZSA9ICdwZXJzb25hbCcsXG4gICAgICAgICAgdG9wTiA9IDEwLFxuICAgICAgICB9ID0gcGF5bG9hZDtcblxuICAgICAgICBpZiAoIWxlc3NvbklkIHx8ICFjbGFzc0lkKSB7XG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnXHU3RjNBXHU1QzExXHU1RkM1XHU5NzAwXHU1M0MyXHU2NTcwXHVGRjFBbGVzc29uSWQsIGNsYXNzSWQnIH07XG4gICAgICAgIH1cblxuICAgICAgICB0cnkge1xuICAgICAgICAgIC8vIFx1NTE0OFx1ODNCN1x1NTNENlx1NjM5Mlx1ODg0Q1x1NjU3MFx1NjM2RVxuICAgICAgICAgIGNvbnN0IHJhbmtpbmdSZXN1bHQgPSBhd2FpdCBjb21tYW5kQnVzLmV4ZWN1dGUoe1xuICAgICAgICAgICAgaWQ6ICdpbnRfJyArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpLFxuICAgICAgICAgICAgdHlwZTogJ2xlYWRlcmJvYXJkLmdldF9yYW5raW5nJyxcbiAgICAgICAgICAgIGFjdG9ySWQ6IGNvbW1hbmQuYWN0b3JJZCB8fCBgcGx1Z2luOiR7Y3R4LnBsdWdpbklkfWAsXG4gICAgICAgICAgICBwYXlsb2FkOiB7IGNsYXNzSWQsIG1vZGUsIGxpbWl0OiB0b3BOIH0sXG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpZiAoIShyYW5raW5nUmVzdWx0IGFzIGFueSk/LnN1Y2Nlc3MpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgYFx1ODNCN1x1NTNENlx1NjM5Mlx1ODg0Q1x1NjU3MFx1NjM2RVx1NTkzMVx1OEQyNTogJHsocmFua2luZ1Jlc3VsdCBhcyBhbnkpPy5lcnJvciB8fCAnXHU2NzJBXHU3N0U1XHU5NTE5XHU4QkVGJ31gLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCByYW5raW5nID0gKHJhbmtpbmdSZXN1bHQgYXMgYW55KS5yYW5raW5nIHx8IFtdO1xuICAgICAgICAgIGNvbnN0IHN0YXRzID0gKHJhbmtpbmdSZXN1bHQgYXMgYW55KS5zdGF0cyB8fCB7fTtcblxuICAgICAgICAgIC8vIFx1Njc4NFx1NUVGQVx1NjM5Mlx1ODg0Q1x1Njk5Q1x1NjU4N1x1NjcyQ1xuICAgICAgICAgIGNvbnN0IHRpdGxlID1cbiAgICAgICAgICAgIG1vZGUgPT09ICdncm91cCdcbiAgICAgICAgICAgICAgPyBCT0FSRF9TVFlMRS5ncm91cFRpdGxlXG4gICAgICAgICAgICAgIDogQk9BUkRfU1RZTEUucGVyc29uYWxUaXRsZTtcblxuICAgICAgICAgIGxldCBib2FyZFRleHQgPSBgJHt0aXRsZX1cXG4ke0JPQVJEX1NUWUxFLmRpdmlkZXJ9XFxuYDtcblxuICAgICAgICAgIGlmIChyYW5raW5nLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgYm9hcmRUZXh0ICs9ICdcXG4gICBcdUQ4M0RcdURDRUQgXHU2NjgyXHU2NUUwXHU3OUVGXHU1MjA2XHU4QkIwXHU1RjU1XFxuICAgXHU1RkVCXHU1M0JCXHU3RUQ5XHU1NDBDXHU1QjY2XHU0RUVDXHU1MkEwXHU1MjA2XHU1NDI3XHVGRjAxXFxuJztcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByYW5raW5nLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSByYW5raW5nW2ldO1xuICAgICAgICAgICAgICBjb25zdCBtZWRhbCA9IGl0ZW0ubWVkYWwgfHwgYCR7aSArIDF9LmA7XG4gICAgICAgICAgICAgIGNvbnN0IGJhckxlbmd0aCA9IE1hdGgubWF4KFxuICAgICAgICAgICAgICAgIDEsXG4gICAgICAgICAgICAgICAgTWF0aC5yb3VuZChcbiAgICAgICAgICAgICAgICAgIChpdGVtLnRvdGFsUG9pbnRzIC9cbiAgICAgICAgICAgICAgICAgICAgTWF0aC5tYXgoMSwgcmFua2luZ1swXT8udG90YWxQb2ludHMgfHwgMSkpICpcbiAgICAgICAgICAgICAgICAgICAgMTAsXG4gICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgY29uc3QgYmFyID0gJ1x1MjU4OCcucmVwZWF0KGJhckxlbmd0aCkgKyAnXHUyNTkxJy5yZXBlYXQoMTAgLSBiYXJMZW5ndGgpO1xuICAgICAgICAgICAgICBib2FyZFRleHQgKz0gYCR7bWVkYWx9ICR7aXRlbS5zdHVkZW50TmFtZS5wYWRFbmQoOCl9ICR7YmFyfSAke2l0ZW0udG90YWxQb2ludHN9XHU1MjA2XFxuYDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBib2FyZFRleHQgKz0gYCR7Qk9BUkRfU1RZTEUuZGl2aWRlcn1cXG5gO1xuICAgICAgICAgIGJvYXJkVGV4dCArPSBgXHVEODNEXHVEQ0NBIFx1NTE3MSAke3N0YXRzLnRvdGFsU3R1ZGVudHMgfHwgcmFua2luZy5sZW5ndGh9IFx1NEVCQSB8IGA7XG4gICAgICAgICAgYm9hcmRUZXh0ICs9IGBcdTYwM0JcdTUyMDY6ICR7c3RhdHMuY2xhc3NUb3RhbFBvaW50cyB8fCAwfWA7XG5cbiAgICAgICAgICAvLyBcdTU3MjhcdTc2N0RcdTY3N0ZcdTRFMEFcdTdFRDhcdTUyMzZcdTYzOTJcdTg4NENcdTY5OUNcbiAgICAgICAgICBjb25zdCBkcmF3UmVzdWx0ID0gYXdhaXQgY29tbWFuZEJ1cy5leGVjdXRlKHtcbiAgICAgICAgICAgIGlkOiAnaW50X2RyYXdfJyArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpLFxuICAgICAgICAgICAgdHlwZTogJ3doaXRlYm9hcmQuZHJhdycsXG4gICAgICAgICAgICBhY3RvcklkOiBjb21tYW5kLmFjdG9ySWQgfHwgYHBsdWdpbjoke2N0eC5wbHVnaW5JZH1gLFxuICAgICAgICAgICAgcGF5bG9hZDoge1xuICAgICAgICAgICAgICBsZXNzb25JZCxcbiAgICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgICAgICBkYXRhOiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgdGV4dDogYm9hcmRUZXh0LFxuICAgICAgICAgICAgICAgIHg6IDYwLFxuICAgICAgICAgICAgICAgIHk6IDQwLFxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiAxNixcbiAgICAgICAgICAgICAgICBmaWxsOiAnIzFlMjkzYicsXG4gICAgICAgICAgICAgICAgZm9udEZhbWlseTogJ21vbm9zcGFjZScsXG4gICAgICAgICAgICAgICAgd2lkdGg6IDQyMCxcbiAgICAgICAgICAgICAgICBhbGlnbjogJ2xlZnQnLFxuICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjb25zdCBlbGVtZW50SWQgPSAoZHJhd1Jlc3VsdCBhcyBhbnkpPy5lbGVtZW50SWQ7XG5cbiAgICAgICAgICAvLyBcdTVCNThcdTUwQThcdTVGNTNcdTUyNERcdTYzOTJcdTg4NENcdTY5OUNcdTc2ODRcdTc2N0RcdTY3N0ZcdTUxNDNcdTdEMjAgSURcdUZGMENcdTY1QjlcdTRGQkZcdTU0MEVcdTdFRURcdTY2RjRcdTY1QjBcbiAgICAgICAgICBhd2FpdCBzdG9yYWdlLnNldCgnbGFzdF9ib2FyZF9lbGVtZW50Jywge1xuICAgICAgICAgICAgbGVzc29uSWQsXG4gICAgICAgICAgICBlbGVtZW50SWQsXG4gICAgICAgICAgICBjbGFzc0lkLFxuICAgICAgICAgICAgbW9kZSxcbiAgICAgICAgICAgIHRvcE4sXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgIGBbTGVhZGVyYm9hcmRdIFx1RDgzRFx1RENDQSBcdTYzOTJcdTg4NENcdTY5OUNcdTVERjJcdTVDNTVcdTc5M0FcdTUyMzBcdTc2N0RcdTY3N0YgKGVsZW1lbnRJZDogJHtlbGVtZW50SWR9KWAsXG4gICAgICAgICAgKTtcblxuICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgICAgZWxlbWVudElkLFxuICAgICAgICAgICAgcmFua2luZyxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBcdTYzOTJcdTg4NENcdTY5OUNcdTVERjJcdTVDNTVcdTc5M0FcdTUyMzBcdTc2N0RcdTY3N0ZcdUZGMDFcdTUxNzEgJHtyYW5raW5nLmxlbmd0aH0gXHU1NDBEXHU1QjY2XHU3NTFGXHU0RTBBXHU2OTlDXHUzMDAyYCxcbiAgICAgICAgICB9O1xuICAgICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tMZWFkZXJib2FyZF0gXHU3NjdEXHU2NzdGXHU1QzU1XHU3OTNBXHU1OTMxXHU4RDI1OicsIGVyci5tZXNzYWdlKTtcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVyci5tZXNzYWdlIH07XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICAvLyBcdTI1MDBcdTI1MDAgXHU1OTA0XHU3NDA2XHU1NjY4IEQ6IFx1NjdFNVx1OEJFMlx1NzlFRlx1NTIwNlx1NTM4Nlx1NTNGMiBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcdTI1MDBcbiAgICBhd2FpdCBjb21tYW5kQnVzLnJlZ2lzdGVySGFuZGxlcignbGVhZGVyYm9hcmQuZ2V0X2hpc3RvcnknLCB7XG4gICAgICBleGVjdXRlOiBhc3luYyAoY29tbWFuZCkgPT4ge1xuICAgICAgICBjb25zdCBwYXlsb2FkID0gY29tbWFuZC5wYXlsb2FkIGFzIGFueTtcbiAgICAgICAgY29uc3QgeyBzdHVkZW50SWQsIGNsYXNzSWQsIGxpbWl0ID0gNTAgfSA9IHBheWxvYWQ7XG5cbiAgICAgICAgaWYgKCFjbGFzc0lkKSB7XG4gICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnXHU3RjNBXHU1QzExXHU1RkM1XHU5NzAwXHU1M0MyXHU2NTcwXHVGRjFBY2xhc3NJZCcgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgZGIgPSAoYXdhaXQgY3R4LnJlc29sdmUoSURhdGFiYXNlVG9rZW4pKSBhcyBhbnk7XG5cbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtjdHguZGIudGFibGUoJ3JlY29yZHMnKX0gV0hFUkUgY2xhc3NfaWQgPSA/YDtcbiAgICAgICAgICBjb25zdCBwYXJhbXM6IGFueVtdID0gW2NsYXNzSWRdO1xuXG4gICAgICAgICAgaWYgKHN0dWRlbnRJZCkge1xuICAgICAgICAgICAgc3FsICs9ICcgQU5EIHN0dWRlbnRfaWQgPSA/JztcbiAgICAgICAgICAgIHBhcmFtcy5wdXNoKHN0dWRlbnRJZCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgc3FsICs9ICcgT1JERVIgQlkgY3JlYXRlZF9hdCBERVNDIExJTUlUID8nO1xuICAgICAgICAgIHBhcmFtcy5wdXNoKGxpbWl0KTtcblxuICAgICAgICAgIGNvbnN0IHJvd3MgPSBkYi5wcmVwYXJlKHNxbCkuYWxsKC4uLnBhcmFtcykgYXMgYW55W107XG5cbiAgICAgICAgICAvLyBcdThCQTFcdTdCOTdcdTZDNDdcdTYwM0JcdTdFREZcdThCQTFcbiAgICAgICAgICBjb25zdCBzdW1tYXJ5U3FsID0gc3R1ZGVudElkXG4gICAgICAgICAgICA/IGBTRUxFQ1RcbiAgICAgICAgICAgICAgICAgU1VNKHBvaW50cykgYXMgdG90YWxfcG9pbnRzLFxuICAgICAgICAgICAgICAgICBDT1VOVCgqKSBhcyB0b3RhbF9yZWNvcmRzLFxuICAgICAgICAgICAgICAgICBTVU0oQ0FTRSBXSEVOIHBvaW50cyA+IDAgVEhFTiBwb2ludHMgRUxTRSAwIEVORCkgYXMgcG9zaXRpdmVfcG9pbnRzLFxuICAgICAgICAgICAgICAgICBTVU0oQ0FTRSBXSEVOIHBvaW50cyA8IDAgVEhFTiBwb2ludHMgRUxTRSAwIEVORCkgYXMgbmVnYXRpdmVfcG9pbnRzXG4gICAgICAgICAgICAgICBGUk9NICR7Y3R4LmRiLnRhYmxlKCdyZWNvcmRzJyl9XG4gICAgICAgICAgICAgICBXSEVSRSBjbGFzc19pZCA9ID8gQU5EIHN0dWRlbnRfaWQgPSA/YFxuICAgICAgICAgICAgOiBgU0VMRUNUXG4gICAgICAgICAgICAgICAgIFNVTShwb2ludHMpIGFzIHRvdGFsX3BvaW50cyxcbiAgICAgICAgICAgICAgICAgQ09VTlQoKikgYXMgdG90YWxfcmVjb3JkcyxcbiAgICAgICAgICAgICAgICAgU1VNKENBU0UgV0hFTiBwb2ludHMgPiAwIFRIRU4gcG9pbnRzIEVMU0UgMCBFTkQpIGFzIHBvc2l0aXZlX3BvaW50cyxcbiAgICAgICAgICAgICAgICAgU1VNKENBU0UgV0hFTiBwb2ludHMgPCAwIFRIRU4gcG9pbnRzIEVMU0UgMCBFTkQpIGFzIG5lZ2F0aXZlX3BvaW50c1xuICAgICAgICAgICAgICAgRlJPTSAke2N0eC5kYi50YWJsZSgncmVjb3JkcycpfVxuICAgICAgICAgICAgICAgV0hFUkUgY2xhc3NfaWQgPSA/YDtcblxuICAgICAgICAgIGNvbnN0IHN1bW1hcnlQYXJhbXMgPSBzdHVkZW50SWRcbiAgICAgICAgICAgID8gW2NsYXNzSWQsIHN0dWRlbnRJZF1cbiAgICAgICAgICAgIDogW2NsYXNzSWRdO1xuICAgICAgICAgIGNvbnN0IHN1bW1hcnkgPSBkYi5wcmVwYXJlKHN1bW1hcnlTcWwpLmdldCguLi5zdW1tYXJ5UGFyYW1zKSBhcyBhbnk7XG5cbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgICAgICAgIGNsYXNzSWQsXG4gICAgICAgICAgICBzdHVkZW50SWQ6IHN0dWRlbnRJZCB8fCBudWxsLFxuICAgICAgICAgICAgcmVjb3Jkczogcm93cyxcbiAgICAgICAgICAgIHN1bW1hcnk6IHtcbiAgICAgICAgICAgICAgdG90YWxQb2ludHM6IHN1bW1hcnk/LnRvdGFsX3BvaW50cyA/PyAwLFxuICAgICAgICAgICAgICB0b3RhbFJlY29yZHM6IHN1bW1hcnk/LnRvdGFsX3JlY29yZHMgPz8gMCxcbiAgICAgICAgICAgICAgcG9zaXRpdmVQb2ludHM6IHN1bW1hcnk/LnBvc2l0aXZlX3BvaW50cyA/PyAwLFxuICAgICAgICAgICAgICBuZWdhdGl2ZVBvaW50czogc3VtbWFyeT8ubmVnYXRpdmVfcG9pbnRzID8/IDAsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH07XG4gICAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcignW0xlYWRlcmJvYXJkXSBcdTY3RTVcdThCRTJcdTUzODZcdTUzRjJcdTU5MzFcdThEMjU6JywgZXJyLm1lc3NhZ2UpO1xuICAgICAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyLm1lc3NhZ2UgfTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIC8vIFx1MjUwMFx1MjUwMCBcdTU5MDRcdTc0MDZcdTU2NjggRTogXHU4M0I3XHU1M0Q2XHU3OUVGXHU1MjA2XHU5ODg0XHU4QkJFXHU2QTIxXHU2NzdGIFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFx1MjUwMFxuICAgIGF3YWl0IGNvbW1hbmRCdXMucmVnaXN0ZXJIYW5kbGVyKCdsZWFkZXJib2FyZC5nZXRfcHJlc2V0cycsIHtcbiAgICAgIGV4ZWN1dGU6IGFzeW5jICgpID0+IHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdWNjZXNzOiB0cnVlLFxuICAgICAgICAgIHByZXNldHM6IFBPSU5UX1BSRVNFVFMsXG4gICAgICAgIH07XG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgLy8gXHUyNTAwXHUyNTAwIFx1NTkwNFx1NzQwNlx1NTY2OCBGOiBcdTkxQ0RcdTdGNkVcdTc5RUZcdTUyMDZcdUZGMDhcdTVCNjZcdTY3MUZcdTdFRDNcdTY3NUZcdUZGMDkgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gICAgYXdhaXQgY29tbWFuZEJ1cy5yZWdpc3RlckhhbmRsZXIoJ2xlYWRlcmJvYXJkLnJlc2V0Jywge1xuICAgICAgZXhlY3V0ZTogYXN5bmMgKGNvbW1hbmQpID0+IHtcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IGNvbW1hbmQucGF5bG9hZCBhcyBhbnk7XG4gICAgICAgIGNvbnN0IHsgY2xhc3NJZCB9ID0gcGF5bG9hZDtcblxuICAgICAgICBpZiAoIWNsYXNzSWQpIHtcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdcdTdGM0FcdTVDMTFcdTVGQzVcdTk3MDBcdTUzQzJcdTY1NzBcdUZGMUFjbGFzc0lkJyB9O1xuICAgICAgICB9XG5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCBkYiA9IChhd2FpdCBjdHgucmVzb2x2ZShJRGF0YWJhc2VUb2tlbikpIGFzIGFueTtcblxuICAgICAgICAgIC8vIFx1OTFDRFx1N0Y2RVx1NTI0RFx1NTE0OFx1NUJGQ1x1NTFGQVx1NkM0N1x1NjAzQlx1NjU3MFx1NjM2RVx1NTIzMCBzdG9yYWdlIFx1NTA1QVx1NTkwN1x1NEVGRFxuICAgICAgICAgIGNvbnN0IHJhbmtpbmdSZXN1bHQgPSBhd2FpdCBjb21tYW5kQnVzLmV4ZWN1dGUoe1xuICAgICAgICAgICAgaWQ6ICdpbnRfYmFja3VwXycgKyBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKSxcbiAgICAgICAgICAgIHR5cGU6ICdsZWFkZXJib2FyZC5nZXRfcmFua2luZycsXG4gICAgICAgICAgICBhY3RvcklkOiBjb21tYW5kLmFjdG9ySWQgfHwgYHBsdWdpbjoke2N0eC5wbHVnaW5JZH1gLFxuICAgICAgICAgICAgcGF5bG9hZDogeyBjbGFzc0lkLCBsaW1pdDogMTAwMCB9LFxuICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgY29uc3QgYmFja3VwS2V5ID0gYHNlbWVzdGVyX2JhY2t1cF8ke2NsYXNzSWR9XyR7RGF0ZS5ub3coKX1gO1xuICAgICAgICAgIGF3YWl0IHN0b3JhZ2Uuc2V0KGJhY2t1cEtleSwge1xuICAgICAgICAgICAgY2xhc3NJZCxcbiAgICAgICAgICAgIHJhbmtpbmc6IChyYW5raW5nUmVzdWx0IGFzIGFueSk/LnJhbmtpbmcgfHwgW10sXG4gICAgICAgICAgICBzdGF0czogKHJhbmtpbmdSZXN1bHQgYXMgYW55KT8uc3RhdHMgfHwge30sXG4gICAgICAgICAgICBhcmNoaXZlZEF0OiBEYXRlLm5vdygpLFxuICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgLy8gXHU2RTA1XHU3QTdBXHU4QkU1XHU3M0VEXHU3RUE3XHU3Njg0XHU2MjQwXHU2NzA5XHU3OUVGXHU1MjA2XHU4QkIwXHU1RjU1XG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gZGJcbiAgICAgICAgICAgIC5wcmVwYXJlKFxuICAgICAgICAgICAgICBgREVMRVRFIEZST00gJHtjdHguZGIudGFibGUoJ3JlY29yZHMnKX0gV0hFUkUgY2xhc3NfaWQgPSA/YCxcbiAgICAgICAgICAgIClcbiAgICAgICAgICAgIC5ydW4oY2xhc3NJZCk7XG5cbiAgICAgICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgICAgIGBbTGVhZGVyYm9hcmRdIFx1RDgzRFx1REQwNCBcdTczRURcdTdFQTcgJHtjbGFzc0lkfSBcdTc5RUZcdTUyMDZcdTVERjJcdTkxQ0RcdTdGNkVcdUZGMENgICtcbiAgICAgICAgICAgICAgYFx1NTIyMFx1OTY2NCAke3Jlc3VsdC5jaGFuZ2VzfSBcdTY3NjFcdThCQjBcdTVGNTVcdUZGMENcdTU5MDdcdTRFRkRcdTgxRjMgJHtiYWNrdXBLZXl9YCxcbiAgICAgICAgICApO1xuXG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICBkZWxldGVkUmVjb3JkczogcmVzdWx0LmNoYW5nZXMsXG4gICAgICAgICAgICBiYWNrdXBLZXksXG4gICAgICAgICAgICBtZXNzYWdlOiBgXHU3OUVGXHU1MjA2XHU1REYyXHU5MUNEXHU3RjZFXHVGRjAxXHU1MTcxXHU1RjUyXHU2ODYzICR7cmVzdWx0LmNoYW5nZXN9IFx1Njc2MVx1OEJCMFx1NUY1NVx1RkYwQ1x1NTkwN1x1NEVGRFx1NTFFRFx1OEJDMTogJHtiYWNrdXBLZXl9YCxcbiAgICAgICAgICB9O1xuICAgICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tMZWFkZXJib2FyZF0gXHU5MUNEXHU3RjZFXHU1OTMxXHU4RDI1OicsIGVyci5tZXNzYWdlKTtcbiAgICAgICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVyci5tZXNzYWdlIH07XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBjb25zb2xlLmxvZygnW0xlYWRlcmJvYXJkXSBcdTI3MDUgXHU1NDdEXHU0RUU0XHU1OTA0XHU3NDA2XHU1NjY4XHU2Q0U4XHU1MThDXHU1QjhDXHU2MjEwICg2IFx1NEUyQSknKTtcblxuICAgIC8vIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuICAgIC8vIDQuIFx1OEJBMlx1OTYwNVx1N0NGQlx1N0VERlx1NEU4Qlx1NEVGNlxuICAgIC8vIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuXG4gICAgLy8gXHU3NkQxXHU1NDJDXHU1QjY2XHU3NTFGXHU2Q0U4XHU1MThDXHU0RThCXHU0RUY2IFx1MjAxNFx1MjAxNCBcdTgxRUFcdTUyQThcdTUyMURcdTU5Q0JcdTUzMTZcdThCRTVcdTVCNjZcdTc1MUZcdTU3MjhcdTVGNTNcdTUyNERcdTZEM0JcdThEQzNcdTczRURcdTdFQTdcdTc2ODRcdTc5RUZcdTUyMDZcbiAgICBhd2FpdCBldmVudEJ1cy5zdWJzY3JpYmUoJ3N0dWRlbnQucmVnaXN0ZXJlZCcsIGFzeW5jIChldmVudCkgPT4ge1xuICAgICAgY29uc3QgcGF5bG9hZCA9IGV2ZW50LnBheWxvYWQgYXMgYW55O1xuICAgICAgY29uc3Qgc3R1ZGVudElkID0gcGF5bG9hZD8uaWQ7XG4gICAgICBjb25zdCBzdHVkZW50TmFtZSA9IHBheWxvYWQ/Lm5hbWU7XG4gICAgICBpZiAoIXN0dWRlbnRJZCkgcmV0dXJuO1xuXG4gICAgICBjb25zb2xlLmxvZyhcbiAgICAgICAgYFtMZWFkZXJib2FyZF0gXHVEODNEXHVEQzRCIFx1NjhDMFx1NkQ0Qlx1NTIzMFx1NjVCMFx1NUI2Nlx1NzUxRlx1NkNFOFx1NTE4QzogJHtzdHVkZW50TmFtZSB8fCBzdHVkZW50SWR9XHVGRjBDYCArXG4gICAgICAgICAgJ1x1NTk4Mlx1OTcwMFx1NTIxRFx1NTlDQlx1NTMxNlx1NzlFRlx1NTIwNlx1OEJGN1x1NEY3Rlx1NzUyOCBsZWFkZXJib2FyZC5hZGRfcG9pbnRzJyxcbiAgICAgICk7XG4gICAgfSk7XG5cbiAgICAvLyBcdTc2RDFcdTU0MkNcdTc5RUZcdTUyMDZcdTUzRDhcdTUyQThcdTRFOEJcdTRFRjYgXHUyMDE0XHUyMDE0IFx1ODFFQVx1NTJBOFx1NjZGNFx1NjVCMFx1NzY3RFx1Njc3Rlx1RkYwOFx1NTk4Mlx1Njc5Q1x1NUY1M1x1NTI0RFx1NjcwOVx1NUM1NVx1NzkzQVx1NzY4NFx1NjM5Mlx1ODg0Q1x1Njk5Q1x1RkYwOVxuICAgIGF3YWl0IGV2ZW50QnVzLnN1YnNjcmliZSgnbGVhZGVyYm9hcmQucG9pbnRzX2NoYW5nZWQnLCBhc3luYyAoX2V2ZW50KSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBsYXN0Qm9hcmQgPSBhd2FpdCBzdG9yYWdlLmdldCgnbGFzdF9ib2FyZF9lbGVtZW50JykgYXMgYW55O1xuICAgICAgICBpZiAoIWxhc3RCb2FyZD8ubGVzc29uSWQgfHwgIWxhc3RCb2FyZD8uY2xhc3NJZCkgcmV0dXJuO1xuXG4gICAgICAgIGNvbnN0IHsgbGVzc29uSWQsIGNsYXNzSWQsIG1vZGUsIHRvcE4gfSA9IGxhc3RCb2FyZCBhcyBhbnk7XG5cbiAgICAgICAgLy8gXHU4MUVBXHU1MkE4XHU1MjM3XHU2NUIwXHU3NjdEXHU2NzdGXHU2MzkyXHU4ODRDXHU2OTlDXG4gICAgICAgIGF3YWl0IGNvbW1hbmRCdXMuZXhlY3V0ZSh7XG4gICAgICAgICAgaWQ6ICdpbnRfcmVmcmVzaF8nICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMiksXG4gICAgICAgICAgdHlwZTogJ2xlYWRlcmJvYXJkLnNob3dfYm9hcmQnLFxuICAgICAgICAgIGFjdG9ySWQ6IGBwbHVnaW46JHtjdHgucGx1Z2luSWR9YCxcbiAgICAgICAgICBwYXlsb2FkOiB7IGxlc3NvbklkLCBjbGFzc0lkLCBtb2RlLCB0b3BOIH0sXG4gICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgICB9KTtcblxuICAgICAgICBjb25zb2xlLmxvZygnW0xlYWRlcmJvYXJkXSBcdUQ4M0RcdUREMDQgXHU2MzkyXHU4ODRDXHU2OTlDXHU4MUVBXHU1MkE4XHU1MjM3XHU2NUIwJyk7XG4gICAgICB9IGNhdGNoIHtcbiAgICAgICAgLy8gXHU5NzU5XHU5RUQ4XHU1OTMxXHU4RDI1XHVGRjBDXHU5MDdGXHU1MTREXHU0RThCXHU0RUY2XHU1OTA0XHU3NDA2XHU1RjAyXHU1RTM4XHU1RjcxXHU1NENEXHU0RTNCXHU2RDQxXHU3QTBCXG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcbiAgICAvLyA1LiBcdTUyMURcdTU5Q0JcdTUzMTZcdTlFRDhcdThCQTRcdTkxNERcdTdGNkVcbiAgICAvLyBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcdTI1NTBcblxuICAgIGNvbnN0IGV4aXN0aW5nQ29uZmlnID0gYXdhaXQgc3RvcmFnZS5nZXQoJ2NvbmZpZycpO1xuICAgIGlmICghZXhpc3RpbmdDb25maWcpIHtcbiAgICAgIGF3YWl0IHN0b3JhZ2Uuc2V0KCdjb25maWcnLCB7XG4gICAgICAgIGRlZmF1bHRUb3BOOiAxMCxcbiAgICAgICAgYXV0b1JlZnJlc2hCb2FyZDogdHJ1ZSxcbiAgICAgICAgcG9pbnRQcmVzZXRzOiBQT0lOVF9QUkVTRVRTLFxuICAgICAgICBib2FyZFBvc2l0aW9uOiB7IHg6IDYwLCB5OiA0MCB9LFxuICAgICAgICBib2FyZEZvbnRTaXplOiAxNixcbiAgICAgIH0pO1xuICAgICAgY29uc29sZS5sb2coJ1tMZWFkZXJib2FyZF0gXHUyNjk5XHVGRTBGIFx1OUVEOFx1OEJBNFx1OTE0RFx1N0Y2RVx1NURGMlx1NTIxRFx1NTlDQlx1NTMxNicpO1xuICAgIH1cblxuICAgIC8vIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuICAgIC8vIDYuIFx1NUI5QVx1NjVGNlx1NEVGQlx1NTJBMVx1RkYwOFx1NkJDRlx1NTQ2OFx1NTQ2OFx1NjJBNVx1RkYwOVx1MjAxNFx1MjAxNCBcdTY2ODJcdTY1RjZcdThERjNcdThGQzdcbiAgICAvLyAgICBcdTZDRThcdTYxMEZcdUZGMUFjb250ZXh0LWJ1aWxkZXIgXHU0RTJEIHJlZ2lzdGVySW50ZXJ2YWwgXHU3Njg0XHU1MzA1XHU4OEM1XHU1QjU4XHU1NzI4IGJ1Z1xuICAgIC8vICAgIFx1RkYwOFx1NUJGOVx1OTc1RSBQcm9taXNlIFx1OEZENFx1NTZERVx1NTAzQ1x1OEMwM1x1NzUyOCAudGhlbigpXHVGRjA5XHVGRjBDXHU1Rjg1XHU2ODQ2XHU2N0I2XHU0RkVFXHU1OTBEXHU1NDBFXHU1NDJGXHU3NTI4XHUzMDAyXG4gICAgLy8gICAgXHU1RjUzXHU1MjREXHU1M0VGXHU5MDFBXHU4RkM3IGxlYWRlcmJvYXJkLmdldF9yYW5raW5nIFx1NjI0Qlx1NTJBOFx1NjdFNVx1OEJFMlx1NjM5Mlx1ODg0Q1x1NjU3MFx1NjM2RVx1MzAwMlxuICAgIC8vIFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFx1MjU1MFxuICAgIC8vIEZJWE1FOiBcdTdCNDkgY29udGV4dC1idWlsZGVyLnRzIFx1NEZFRVx1NTkwRFx1NTQwRVx1NTNENlx1NkQ4OFx1NkNFOFx1OTFDQVxuICAgIC8qXG4gICAgYXdhaXQgcHJvY2Vzc01hbmFnZXIucmVnaXN0ZXJJbnRlcnZhbChcbiAgICAgICdsZWFkZXJib2FyZC13ZWVrbHktcmVwb3J0JyxcbiAgICAgIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwLFxuICAgICAgYXN5bmMgKGxvZykgPT4ge1xuICAgICAgICBsb2coJ1tMZWFkZXJib2FyZF0gXHVEODNEXHVEQ0NCIFx1NUYwMFx1NTlDQlx1NzUxRlx1NjIxMFx1NTQ2OFx1NjJBNS4uLicpO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IGRiID0gKGF3YWl0IGN0eC5yZXNvbHZlKElEYXRhYmFzZVRva2VuKSkgYXMgYW55O1xuICAgICAgICAgIGNvbnN0IGNsYXNzZXMgPSBkYlxuICAgICAgICAgICAgLnByZXBhcmUoXG4gICAgICAgICAgICAgIGBTRUxFQ1QgRElTVElOQ1QgY2xhc3NfaWQgRlJPTSAke2N0eC5kYi50YWJsZSgncmVjb3JkcycpfWAsXG4gICAgICAgICAgICApXG4gICAgICAgICAgICAuYWxsKCkgYXMgYW55W107XG5cbiAgICAgICAgICBmb3IgKGNvbnN0IHsgY2xhc3NfaWQgfSBvZiBjbGFzc2VzKSB7XG4gICAgICAgICAgICBjb25zdCByYW5raW5nID0gYXdhaXQgY29tbWFuZEJ1cy5leGVjdXRlKHtcbiAgICAgICAgICAgICAgaWQ6ICdpbnRfd2Vla2x5XycgKyBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zbGljZSgyKSxcbiAgICAgICAgICAgICAgdHlwZTogJ2xlYWRlcmJvYXJkLmdldF9yYW5raW5nJyxcbiAgICAgICAgICAgICAgYWN0b3JJZDogYHBsdWdpbjoke2N0eC5wbHVnaW5JZH1gLFxuICAgICAgICAgICAgICBwYXlsb2FkOiB7IGNsYXNzSWQ6IGNsYXNzX2lkLCBsaW1pdDogNSB9LFxuICAgICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgYXdhaXQgc3RvcmFnZS5zZXQoYHdlZWtseV9yZXBvcnRfJHtjbGFzc19pZH1fJHtEYXRlLm5vdygpfWAsIHtcbiAgICAgICAgICAgICAgY2xhc3NJZDogY2xhc3NfaWQsXG4gICAgICAgICAgICAgIHRvcDU6IChyYW5raW5nIGFzIGFueSk/LnJhbmtpbmc/LnNsaWNlKDAsIDUpIHx8IFtdLFxuICAgICAgICAgICAgICBnZW5lcmF0ZWRBdDogRGF0ZS5ub3coKSxcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBsb2coYFtMZWFkZXJib2FyZF0gXHUyNzA1IFx1NzNFRFx1N0VBNyAke2NsYXNzX2lkfSBcdTU0NjhcdTYyQTVcdTVERjJcdTc1MUZcdTYyMTBgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbG9nKCdbTGVhZGVyYm9hcmRdIFx1RDgzRFx1RENDQiBcdTU0NjhcdTYyQTVcdTc1MUZcdTYyMTBcdTVCOENcdTYyMTAnKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgICBsb2coYFtMZWFkZXJib2FyZF0gXHUyNzRDIFx1NTQ2OFx1NjJBNVx1NzUxRlx1NjIxMFx1NTkzMVx1OEQyNTogJHtlcnIubWVzc2FnZX1gKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICApO1xuICAgICovXG5cbiAgICBjb25zb2xlLmxvZygnW0xlYWRlcmJvYXJkXSBcdTI3MDUgXHU0RThCXHU0RUY2XHU4QkEyXHU5NjA1XHU1REYyXHU4QkJFXHU3RjZFJyk7XG4gICAgY29uc29sZS5sb2coJ1tMZWFkZXJib2FyZF0gXHVEODNDXHVERjg5IFx1NjNEMlx1NEVGNlx1NkZDMFx1NkQzQlx1NUI4Q1x1NjIxMFx1RkYwMScpO1xuICB9LFxuXG4gIC8vIFx1MjUwMFx1MjUwMCBcdTYzRDJcdTRFRjZcdTUwNUNcdTc1MjhcdTZFMDVcdTc0MDYgXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXHUyNTAwXG4gIGRlYWN0aXZhdGU6IGFzeW5jICgpID0+IHtcbiAgICBjb25zb2xlLmxvZygnW0xlYWRlcmJvYXJkXSBcdUQ4M0RcdURDNEIgXHU2M0QyXHU0RUY2XHU1REYyXHU1MDVDXHU3NTI4XHVGRjBDXHU4RDQ0XHU2RTkwXHU3NTMxIFBsdWdpbkhvc3QgXHU4MUVBXHU1MkE4XHU2RTA1XHU3NDA2Jyk7XG4gIH0sXG59O1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQVlPLElBQU0sYUFBTixjQUF5QixNQUFNO0FBQUEsRUFDcEMsWUFBWSxTQUFpQjtBQUMzQixVQUFNLFdBQVcsT0FBTyxFQUFFO0FBQzFCLFNBQUssT0FBTztBQUFBLEVBQ2Q7QUFDRjs7O0FDWUEsSUFBTSxnQkFBZ0I7QUFFZixJQUFNLFFBQU4sTUFBZTtBQUFBLEVBYXBCLFlBQVksTUFBYyxVQUFrQixTQUFTO0FBQ25ELFFBQUksQ0FBQyxRQUFRLE9BQU8sU0FBUyxVQUFVO0FBQ3JDLFlBQU0sSUFBSTtBQUFBLFFBQ1IsK0NBQStDLE9BQU8sSUFBSSxDQUFDO0FBQUEsTUFDN0Q7QUFBQSxJQUNGO0FBRUEsUUFBSSxDQUFDLGNBQWMsS0FBSyxJQUFJLEdBQUc7QUFDN0IsWUFBTSxJQUFJO0FBQUEsUUFDUiwrQkFBK0IsSUFBSTtBQUFBLE1BRXJDO0FBQUEsSUFDRjtBQUVBLFNBQUssT0FBTztBQUNaLFNBQUssVUFBVTtBQUFBLEVBQ2pCO0FBQ0Y7OztBQzZNTyxJQUFNLDBCQUEwQixJQUFJO0FBQUEsRUFDekM7QUFDRjtBQU1PLElBQU0sd0JBQXdCLElBQUk7QUFBQSxFQUN2QztBQUNGO0FBTU8sSUFBTSw4QkFBOEIsSUFBSTtBQUFBLEVBQzdDO0FBQ0Y7QUFNTyxJQUFNLDBCQUEwQixJQUFJO0FBQUEsRUFDekM7QUFDRjtBQU1PLElBQU0sdUJBQXVCLElBQUk7QUFBQSxFQUN0QztBQUNGO0FBTU8sSUFBTSx1QkFBdUIsSUFBSTtBQUFBLEVBQ3RDO0FBQ0Y7QUFNTyxJQUFNLGtCQUFrQixJQUFJO0FBQUEsRUFDakM7QUFDRjtBQU1PLElBQU0saUJBQWlCLElBQUk7QUFBQSxFQUNoQztBQUNGO0FBUU8sSUFBTSxtQkFBbUIsSUFBSTtBQUFBLEVBQ2xDO0FBQ0Y7QUFtQk8sSUFBTSw2QkFBNkIsSUFBSTtBQUFBLEVBQzVDO0FBQ0Y7OztBQ3pVQSxJQUFNLGdCQUFnQjtBQUFBLEVBQ3BCLFVBQVU7QUFBQSxJQUNSLEVBQUUsUUFBUSx3Q0FBVSxRQUFRLEdBQUcsVUFBVSwyQkFBTztBQUFBLElBQ2hELEVBQUUsUUFBUSx3Q0FBVSxRQUFRLElBQUksVUFBVSwyQkFBTztBQUFBLElBQ2pELEVBQUUsUUFBUSx3Q0FBVSxRQUFRLEdBQUcsVUFBVSwyQkFBTztBQUFBLElBQ2hELEVBQUUsUUFBUSx3Q0FBVSxRQUFRLEdBQUcsVUFBVSwyQkFBTztBQUFBLElBQ2hELEVBQUUsUUFBUSx3Q0FBVSxRQUFRLEdBQUcsVUFBVSwyQkFBTztBQUFBLElBQ2hELEVBQUUsUUFBUSx3Q0FBVSxRQUFRLElBQUksVUFBVSwyQkFBTztBQUFBLElBQ2pELEVBQUUsUUFBUSxvREFBWSxRQUFRLEdBQUcsVUFBVSwyQkFBTztBQUFBLElBQ2xELEVBQUUsUUFBUSx3Q0FBVSxRQUFRLEdBQUcsVUFBVSwyQkFBTztBQUFBLEVBQ2xEO0FBQUEsRUFDQSxVQUFVO0FBQUEsSUFDUixFQUFFLFFBQVEsNEJBQVEsUUFBUSxJQUFJLFVBQVUsMkJBQU87QUFBQSxJQUMvQyxFQUFFLFFBQVEsOENBQVcsUUFBUSxJQUFJLFVBQVUsMkJBQU87QUFBQSxJQUNsRCxFQUFFLFFBQVEsb0RBQVksUUFBUSxJQUFJLFVBQVUsMkJBQU87QUFBQSxJQUNuRCxFQUFFLFFBQVEsb0RBQVksUUFBUSxJQUFJLFVBQVUsMkJBQU87QUFBQSxJQUNuRCxFQUFFLFFBQVEsd0NBQVUsUUFBUSxLQUFLLFVBQVUsMkJBQU87QUFBQSxFQUNwRDtBQUNGO0FBR0EsSUFBTSxjQUFjO0FBQUEsRUFDbEIsT0FBTztBQUFBLEVBQ1AsZUFBZTtBQUFBLEVBQ2YsWUFBWTtBQUFBLEVBQ1osU0FBUyxTQUFJLE9BQU8sRUFBRTtBQUFBLEVBQ3RCLGFBQWEsQ0FBQyxXQUFXLFdBQVcsU0FBUztBQUFBO0FBQy9DO0FBRUEsSUFBTyxnQkFBUTtBQUFBLEVBQ2IsVUFBVTtBQUFBLElBQ1IsSUFBSTtBQUFBLElBQ0osTUFBTTtBQUFBLElBQ04sU0FBUztBQUFBLEVBQ1g7QUFBQTtBQUFBLEVBR0EsVUFBVSxPQUFPLFFBQXVCO0FBQ3RDLFVBQU0sRUFBRSxZQUFZLGdCQUFnQixVQUFVLFFBQVEsSUFDcEQsSUFBSTtBQUVOLFlBQVEsSUFBSSxxREFBMEIsSUFBSSxRQUFRLEtBQUssSUFBSSxTQUFTLE9BQU8sRUFBRTtBQUs3RSxVQUFNLElBQUksR0FBRztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBU0Y7QUFFQSxZQUFRLElBQUksNkVBQTJCO0FBT3ZDLFVBQU0sZUFBZSxTQUFTO0FBQUEsTUFDNUIsSUFBSTtBQUFBLE1BQ0osYUFBYTtBQUFBLE1BQ2IsYUFDRTtBQUFBLE1BSUYsb0JBQW9CO0FBQUEsTUFDcEIsYUFBYTtBQUFBLFFBQ1gsTUFBTTtBQUFBLFFBQ04sWUFBWTtBQUFBLFVBQ1YsV0FBVztBQUFBLFlBQ1QsTUFBTTtBQUFBLFlBQ04sYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBLGFBQWE7QUFBQSxZQUNYLE1BQU07QUFBQSxZQUNOLGFBQWE7QUFBQSxVQUNmO0FBQUEsVUFDQSxTQUFTO0FBQUEsWUFDUCxNQUFNO0FBQUEsWUFDTixhQUFhO0FBQUEsVUFDZjtBQUFBLFVBQ0EsUUFBUTtBQUFBLFlBQ04sTUFBTTtBQUFBLFlBQ04sYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBLFFBQVE7QUFBQSxZQUNOLE1BQU07QUFBQSxZQUNOLGFBQWE7QUFBQSxVQUNmO0FBQUEsVUFDQSxVQUFVO0FBQUEsWUFDUixNQUFNO0FBQUEsWUFDTixhQUFhO0FBQUEsVUFDZjtBQUFBLFFBQ0Y7QUFBQSxRQUNBLFVBQVUsQ0FBQyxhQUFhLGVBQWUsV0FBVyxVQUFVLFFBQVE7QUFBQSxNQUN0RTtBQUFBLElBQ0YsQ0FBQztBQUdELFVBQU0sZUFBZSxTQUFTO0FBQUEsTUFDNUIsSUFBSTtBQUFBLE1BQ0osYUFBYTtBQUFBLE1BQ2IsYUFDRTtBQUFBLE1BR0Ysb0JBQW9CO0FBQUEsTUFDcEIsYUFBYTtBQUFBLFFBQ1gsTUFBTTtBQUFBLFFBQ04sWUFBWTtBQUFBLFVBQ1YsVUFBVTtBQUFBLFlBQ1IsTUFBTTtBQUFBLFlBQ04sYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBLFNBQVM7QUFBQSxZQUNQLE1BQU07QUFBQSxZQUNOLGFBQWE7QUFBQSxVQUNmO0FBQUEsVUFDQSxNQUFNO0FBQUEsWUFDSixNQUFNO0FBQUEsWUFDTixhQUFhO0FBQUEsVUFDZjtBQUFBLFVBQ0EsTUFBTTtBQUFBLFlBQ0osTUFBTTtBQUFBLFlBQ04sYUFBYTtBQUFBLFVBQ2Y7QUFBQSxRQUNGO0FBQUEsUUFDQSxVQUFVLENBQUMsWUFBWSxTQUFTO0FBQUEsTUFDbEM7QUFBQSxJQUNGLENBQUM7QUFHRCxVQUFNLGVBQWUsU0FBUztBQUFBLE1BQzVCLElBQUk7QUFBQSxNQUNKLGFBQWE7QUFBQSxNQUNiLGFBQ0U7QUFBQSxNQUNGLG9CQUFvQjtBQUFBLE1BQ3BCLGFBQWE7QUFBQSxRQUNYLE1BQU07QUFBQSxRQUNOLFlBQVk7QUFBQSxVQUNWLFNBQVM7QUFBQSxZQUNQLE1BQU07QUFBQSxZQUNOLGFBQWE7QUFBQSxVQUNmO0FBQUEsVUFDQSxNQUFNO0FBQUEsWUFDSixNQUFNO0FBQUEsWUFDTixhQUFhO0FBQUEsVUFDZjtBQUFBLFVBQ0EsT0FBTztBQUFBLFlBQ0wsTUFBTTtBQUFBLFlBQ04sYUFBYTtBQUFBLFVBQ2Y7QUFBQSxRQUNGO0FBQUEsUUFDQSxVQUFVLENBQUMsU0FBUztBQUFBLE1BQ3RCO0FBQUEsSUFDRixDQUFDO0FBR0QsVUFBTSxlQUFlLFNBQVM7QUFBQSxNQUM1QixJQUFJO0FBQUEsTUFDSixhQUFhO0FBQUEsTUFDYixhQUNFO0FBQUEsTUFDRixvQkFBb0I7QUFBQSxNQUNwQixhQUFhO0FBQUEsUUFDWCxNQUFNO0FBQUEsUUFDTixZQUFZO0FBQUEsVUFDVixXQUFXO0FBQUEsWUFDVCxNQUFNO0FBQUEsWUFDTixhQUFhO0FBQUEsVUFDZjtBQUFBLFVBQ0EsU0FBUztBQUFBLFlBQ1AsTUFBTTtBQUFBLFlBQ04sYUFBYTtBQUFBLFVBQ2Y7QUFBQSxVQUNBLE9BQU87QUFBQSxZQUNMLE1BQU07QUFBQSxZQUNOLGFBQWE7QUFBQSxVQUNmO0FBQUEsUUFDRjtBQUFBLFFBQ0EsVUFBVSxDQUFDLFNBQVM7QUFBQSxNQUN0QjtBQUFBLElBQ0YsQ0FBQztBQUdELFVBQU0sZUFBZSxTQUFTO0FBQUEsTUFDNUIsSUFBSTtBQUFBLE1BQ0osYUFBYTtBQUFBLE1BQ2IsYUFDRTtBQUFBLE1BQ0Ysb0JBQW9CO0FBQUEsTUFDcEIsYUFBYTtBQUFBLFFBQ1gsTUFBTTtBQUFBLFFBQ04sWUFBWSxDQUFDO0FBQUEsUUFDYixVQUFVLENBQUM7QUFBQSxNQUNiO0FBQUEsSUFDRixDQUFDO0FBRUQsWUFBUSxJQUFJLHFFQUF1QztBQU9uRCxVQUFNLFdBQVcsZ0JBQWdCLDBCQUEwQjtBQUFBLE1BQ3pELFNBQVMsT0FBTyxZQUFZO0FBQzFCLGNBQU0sVUFBVSxRQUFRO0FBQ3hCLGNBQU07QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFVBQ0E7QUFBQSxVQUNBO0FBQUEsVUFDQTtBQUFBLFVBQ0EsV0FBVztBQUFBLFFBQ2IsSUFBSTtBQUdKLFlBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLFdBQVcsV0FBVyxRQUFXO0FBQ2xFLGlCQUFPO0FBQUEsWUFDTCxTQUFTO0FBQUEsWUFDVCxPQUFPO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFFQSxZQUFJLE9BQU8sV0FBVyxZQUFZLFdBQVcsR0FBRztBQUM5QyxpQkFBTztBQUFBLFlBQ0wsU0FBUztBQUFBLFlBQ1QsT0FBTztBQUFBLFVBQ1Q7QUFBQSxRQUNGO0FBRUEsWUFBSTtBQUNGLGdCQUFNLEtBQU0sTUFBTSxJQUFJLFFBQVEsY0FBYztBQUM1QyxnQkFBTSxXQUFXLFNBQVMsS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFDaEUsZ0JBQU0sWUFBWSxLQUFLLElBQUk7QUFHM0IsYUFBRztBQUFBLFlBQ0QsZUFBZSxJQUFJLEdBQUcsTUFBTSxTQUFTLENBQUM7QUFBQTtBQUFBO0FBQUEsVUFHeEMsRUFBRTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBLFFBQVEsV0FBVztBQUFBLFlBQ25CO0FBQUEsVUFDRjtBQUdBLGdCQUFNLFdBQVcsR0FDZDtBQUFBLFlBQ0M7QUFBQSxzQkFDUSxJQUFJLEdBQUcsTUFBTSxTQUFTLENBQUM7QUFBQTtBQUFBLFVBRWpDLEVBQ0MsSUFBSSxXQUFXLE9BQU87QUFFekIsZ0JBQU0sY0FBYyxVQUFVLFNBQVM7QUFHdkMsZ0JBQU0sVUFBVSxHQUNiO0FBQUEsWUFDQztBQUFBO0FBQUEsd0JBRVUsSUFBSSxHQUFHLE1BQU0sU0FBUyxDQUFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQUtuQyxFQUNDLElBQUksU0FBUyxXQUFXO0FBRTNCLGdCQUFNLE9BQU8sU0FBUyxRQUFRO0FBRzlCLGdCQUFNLFNBQVMsUUFBUTtBQUFBLFlBQ3JCLElBQUksT0FBTyxRQUFRO0FBQUEsWUFDbkIsTUFBTTtBQUFBLFlBQ04sUUFBUSxJQUFJO0FBQUEsWUFDWixTQUFTO0FBQUEsY0FDUDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQTtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsWUFDRjtBQUFBLFlBQ0E7QUFBQSxVQUNGLENBQUM7QUFFRCxnQkFBTSxRQUFRLFNBQVMsSUFBSSxjQUFPO0FBQ2xDLGtCQUFRO0FBQUEsWUFDTixpQkFBaUIsS0FBSyxJQUFJLFdBQVcsSUFBSSxTQUFTLElBQUksTUFBTSxFQUFFLEdBQUcsTUFBTSw4QkFDN0QsV0FBVyxtQkFBUyxJQUFJLDRCQUFhLE1BQU07QUFBQSxVQUN2RDtBQUVBLGlCQUFPO0FBQUEsWUFDTCxTQUFTO0FBQUEsWUFDVDtBQUFBLFlBQ0E7QUFBQSxZQUNBLGVBQWU7QUFBQSxZQUNmO0FBQUEsWUFDQTtBQUFBLFlBQ0EsU0FDRSxTQUFTLElBQ0wsR0FBRyxXQUFXLEtBQUssTUFBTSx3Q0FBVSxXQUFXLG1DQUFVLElBQUksS0FDNUQsR0FBRyxXQUFXLElBQUksTUFBTSx3Q0FBVSxXQUFXLG1DQUFVLElBQUk7QUFBQSxVQUNuRTtBQUFBLFFBQ0YsU0FBUyxLQUFVO0FBQ2pCLGtCQUFRLE1BQU0sdURBQXlCLElBQUksT0FBTztBQUNsRCxpQkFBTyxFQUFFLFNBQVMsT0FBTyxPQUFPLElBQUksUUFBUTtBQUFBLFFBQzlDO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUdELFVBQU0sV0FBVyxnQkFBZ0IsMkJBQTJCO0FBQUEsTUFDMUQsU0FBUyxPQUFPLFlBQVk7QUFDMUIsY0FBTSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxFQUFFLFNBQVMsT0FBTyxZQUFZLFFBQVEsR0FBRyxJQUFJO0FBRW5ELFlBQUksQ0FBQyxTQUFTO0FBQ1osaUJBQU8sRUFBRSxTQUFTLE9BQU8sT0FBTyxvREFBaUI7QUFBQSxRQUNuRDtBQUVBLFlBQUk7QUFDRixnQkFBTSxLQUFNLE1BQU0sSUFBSSxRQUFRLGNBQWM7QUFFNUMsZ0JBQU0sT0FBTyxHQUNWO0FBQUEsWUFDQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFNUSxJQUFJLEdBQUcsTUFBTSxTQUFTLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBS2pDLEVBQ0MsSUFBSSxTQUFTLEtBQUs7QUFFckIsZ0JBQU0sVUFBVSxLQUFLLElBQUksQ0FBQyxLQUFVLFdBQW1CO0FBQUEsWUFDckQsTUFBTSxRQUFRO0FBQUEsWUFDZCxXQUFXLElBQUk7QUFBQSxZQUNmLGFBQWEsSUFBSTtBQUFBLFlBQ2pCLGFBQWEsSUFBSTtBQUFBLFlBQ2pCLGFBQWEsSUFBSTtBQUFBLFlBQ2pCLGFBQWEsSUFBSTtBQUFBLFlBQ2pCLE9BQ0UsVUFBVSxJQUFJLGNBQU8sVUFBVSxJQUFJLGNBQU8sVUFBVSxJQUFJLGNBQU87QUFBQSxVQUNuRSxFQUFFO0FBR0YsZ0JBQU0sUUFBUSxHQUNYO0FBQUEsWUFDQztBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQUlRLElBQUksR0FBRyxNQUFNLFNBQVMsQ0FBQztBQUFBO0FBQUEsVUFFakMsRUFDQyxJQUFJLE9BQU87QUFFZCxpQkFBTztBQUFBLFlBQ0wsU0FBUztBQUFBLFlBQ1Q7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0EsT0FBTztBQUFBLGNBQ0wsZUFBZSxPQUFPLGtCQUFrQjtBQUFBLGNBQ3hDLGtCQUFrQixPQUFPLHNCQUFzQjtBQUFBLGNBQy9DLGNBQWMsT0FBTyxpQkFDakIsS0FBSyxNQUFNLE1BQU0saUJBQWlCLEVBQUUsSUFBSSxLQUN4QztBQUFBLFlBQ047QUFBQSxZQUNBLGFBQWEsS0FBSyxJQUFJO0FBQUEsVUFDeEI7QUFBQSxRQUNGLFNBQVMsS0FBVTtBQUNqQixrQkFBUSxNQUFNLHVEQUF5QixJQUFJLE9BQU87QUFDbEQsaUJBQU8sRUFBRSxTQUFTLE9BQU8sT0FBTyxJQUFJLFFBQVE7QUFBQSxRQUM5QztBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFHRCxVQUFNLFdBQVcsZ0JBQWdCLDBCQUEwQjtBQUFBLE1BQ3pELFNBQVMsT0FBTyxZQUFZO0FBQzFCLGNBQU0sVUFBVSxRQUFRO0FBQ3hCLGNBQU07QUFBQSxVQUNKO0FBQUEsVUFDQTtBQUFBLFVBQ0EsT0FBTztBQUFBLFVBQ1AsT0FBTztBQUFBLFFBQ1QsSUFBSTtBQUVKLFlBQUksQ0FBQyxZQUFZLENBQUMsU0FBUztBQUN6QixpQkFBTyxFQUFFLFNBQVMsT0FBTyxPQUFPLDhEQUEyQjtBQUFBLFFBQzdEO0FBRUEsWUFBSTtBQUVGLGdCQUFNLGdCQUFnQixNQUFNLFdBQVcsUUFBUTtBQUFBLFlBQzdDLElBQUksU0FBUyxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUM7QUFBQSxZQUMvQyxNQUFNO0FBQUEsWUFDTixTQUFTLFFBQVEsV0FBVyxVQUFVLElBQUksUUFBUTtBQUFBLFlBQ2xELFNBQVMsRUFBRSxTQUFTLE1BQU0sT0FBTyxLQUFLO0FBQUEsWUFDdEMsV0FBVyxLQUFLLElBQUk7QUFBQSxVQUN0QixDQUFDO0FBRUQsY0FBSSxDQUFFLGVBQXVCLFNBQVM7QUFDcEMsa0JBQU0sSUFBSTtBQUFBLGNBQ1IscURBQWMsZUFBdUIsU0FBUywwQkFBTTtBQUFBLFlBQ3REO0FBQUEsVUFDRjtBQUVBLGdCQUFNLFVBQVcsY0FBc0IsV0FBVyxDQUFDO0FBQ25ELGdCQUFNLFFBQVMsY0FBc0IsU0FBUyxDQUFDO0FBRy9DLGdCQUFNLFFBQ0osU0FBUyxVQUNMLFlBQVksYUFDWixZQUFZO0FBRWxCLGNBQUksWUFBWSxHQUFHLEtBQUs7QUFBQSxFQUFLLFlBQVksT0FBTztBQUFBO0FBRWhELGNBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIseUJBQWE7QUFBQSxVQUNmLE9BQU87QUFDTCxxQkFBUyxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztBQUN2QyxvQkFBTSxPQUFPLFFBQVEsQ0FBQztBQUN0QixvQkFBTSxRQUFRLEtBQUssU0FBUyxHQUFHLElBQUksQ0FBQztBQUNwQyxvQkFBTSxZQUFZLEtBQUs7QUFBQSxnQkFDckI7QUFBQSxnQkFDQSxLQUFLO0FBQUEsa0JBQ0YsS0FBSyxjQUNKLEtBQUssSUFBSSxHQUFHLFFBQVEsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxJQUN4QztBQUFBLGdCQUNKO0FBQUEsY0FDRjtBQUNBLG9CQUFNLE1BQU0sU0FBSSxPQUFPLFNBQVMsSUFBSSxTQUFJLE9BQU8sS0FBSyxTQUFTO0FBQzdELDJCQUFhLEdBQUcsS0FBSyxJQUFJLEtBQUssWUFBWSxPQUFPLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxLQUFLLFdBQVc7QUFBQTtBQUFBLFlBQ2hGO0FBQUEsVUFDRjtBQUVBLHVCQUFhLEdBQUcsWUFBWSxPQUFPO0FBQUE7QUFDbkMsdUJBQWEsb0JBQVEsTUFBTSxpQkFBaUIsUUFBUSxNQUFNO0FBQzFELHVCQUFhLGlCQUFPLE1BQU0sb0JBQW9CLENBQUM7QUFHL0MsZ0JBQU0sYUFBYSxNQUFNLFdBQVcsUUFBUTtBQUFBLFlBQzFDLElBQUksY0FBYyxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUM7QUFBQSxZQUNwRCxNQUFNO0FBQUEsWUFDTixTQUFTLFFBQVEsV0FBVyxVQUFVLElBQUksUUFBUTtBQUFBLFlBQ2xELFNBQVM7QUFBQSxjQUNQO0FBQUEsY0FDQSxNQUFNO0FBQUEsY0FDTixNQUFNLEtBQUssVUFBVTtBQUFBLGdCQUNuQixNQUFNO0FBQUEsZ0JBQ04sR0FBRztBQUFBLGdCQUNILEdBQUc7QUFBQSxnQkFDSCxVQUFVO0FBQUEsZ0JBQ1YsTUFBTTtBQUFBLGdCQUNOLFlBQVk7QUFBQSxnQkFDWixPQUFPO0FBQUEsZ0JBQ1AsT0FBTztBQUFBLGNBQ1QsQ0FBQztBQUFBLFlBQ0g7QUFBQSxZQUNBLFdBQVcsS0FBSyxJQUFJO0FBQUEsVUFDdEIsQ0FBQztBQUVELGdCQUFNLFlBQWEsWUFBb0I7QUFHdkMsZ0JBQU0sUUFBUSxJQUFJLHNCQUFzQjtBQUFBLFlBQ3RDO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0YsQ0FBQztBQUVELGtCQUFRO0FBQUEsWUFDTiw4RkFBMEMsU0FBUztBQUFBLFVBQ3JEO0FBRUEsaUJBQU87QUFBQSxZQUNMLFNBQVM7QUFBQSxZQUNUO0FBQUEsWUFDQTtBQUFBLFlBQ0EsU0FBUyxzRUFBZSxRQUFRLE1BQU07QUFBQSxVQUN4QztBQUFBLFFBQ0YsU0FBUyxLQUFVO0FBQ2pCLGtCQUFRLE1BQU0sdURBQXlCLElBQUksT0FBTztBQUNsRCxpQkFBTyxFQUFFLFNBQVMsT0FBTyxPQUFPLElBQUksUUFBUTtBQUFBLFFBQzlDO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUdELFVBQU0sV0FBVyxnQkFBZ0IsMkJBQTJCO0FBQUEsTUFDMUQsU0FBUyxPQUFPLFlBQVk7QUFDMUIsY0FBTSxVQUFVLFFBQVE7QUFDeEIsY0FBTSxFQUFFLFdBQVcsU0FBUyxRQUFRLEdBQUcsSUFBSTtBQUUzQyxZQUFJLENBQUMsU0FBUztBQUNaLGlCQUFPLEVBQUUsU0FBUyxPQUFPLE9BQU8sb0RBQWlCO0FBQUEsUUFDbkQ7QUFFQSxZQUFJO0FBQ0YsZ0JBQU0sS0FBTSxNQUFNLElBQUksUUFBUSxjQUFjO0FBRTVDLGNBQUksTUFBTSxpQkFBaUIsSUFBSSxHQUFHLE1BQU0sU0FBUyxDQUFDO0FBQ2xELGdCQUFNLFNBQWdCLENBQUMsT0FBTztBQUU5QixjQUFJLFdBQVc7QUFDYixtQkFBTztBQUNQLG1CQUFPLEtBQUssU0FBUztBQUFBLFVBQ3ZCO0FBRUEsaUJBQU87QUFDUCxpQkFBTyxLQUFLLEtBQUs7QUFFakIsZ0JBQU0sT0FBTyxHQUFHLFFBQVEsR0FBRyxFQUFFLElBQUksR0FBRyxNQUFNO0FBRzFDLGdCQUFNLGFBQWEsWUFDZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBS1EsSUFBSSxHQUFHLE1BQU0sU0FBUyxDQUFDO0FBQUEsd0RBRS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFLUSxJQUFJLEdBQUcsTUFBTSxTQUFTLENBQUM7QUFBQTtBQUduQyxnQkFBTSxnQkFBZ0IsWUFDbEIsQ0FBQyxTQUFTLFNBQVMsSUFDbkIsQ0FBQyxPQUFPO0FBQ1osZ0JBQU0sVUFBVSxHQUFHLFFBQVEsVUFBVSxFQUFFLElBQUksR0FBRyxhQUFhO0FBRTNELGlCQUFPO0FBQUEsWUFDTCxTQUFTO0FBQUEsWUFDVDtBQUFBLFlBQ0EsV0FBVyxhQUFhO0FBQUEsWUFDeEIsU0FBUztBQUFBLFlBQ1QsU0FBUztBQUFBLGNBQ1AsYUFBYSxTQUFTLGdCQUFnQjtBQUFBLGNBQ3RDLGNBQWMsU0FBUyxpQkFBaUI7QUFBQSxjQUN4QyxnQkFBZ0IsU0FBUyxtQkFBbUI7QUFBQSxjQUM1QyxnQkFBZ0IsU0FBUyxtQkFBbUI7QUFBQSxZQUM5QztBQUFBLFVBQ0Y7QUFBQSxRQUNGLFNBQVMsS0FBVTtBQUNqQixrQkFBUSxNQUFNLHVEQUF5QixJQUFJLE9BQU87QUFDbEQsaUJBQU8sRUFBRSxTQUFTLE9BQU8sT0FBTyxJQUFJLFFBQVE7QUFBQSxRQUM5QztBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFHRCxVQUFNLFdBQVcsZ0JBQWdCLDJCQUEyQjtBQUFBLE1BQzFELFNBQVMsWUFBWTtBQUNuQixlQUFPO0FBQUEsVUFDTCxTQUFTO0FBQUEsVUFDVCxTQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFHRCxVQUFNLFdBQVcsZ0JBQWdCLHFCQUFxQjtBQUFBLE1BQ3BELFNBQVMsT0FBTyxZQUFZO0FBQzFCLGNBQU0sVUFBVSxRQUFRO0FBQ3hCLGNBQU0sRUFBRSxRQUFRLElBQUk7QUFFcEIsWUFBSSxDQUFDLFNBQVM7QUFDWixpQkFBTyxFQUFFLFNBQVMsT0FBTyxPQUFPLG9EQUFpQjtBQUFBLFFBQ25EO0FBRUEsWUFBSTtBQUNGLGdCQUFNLEtBQU0sTUFBTSxJQUFJLFFBQVEsY0FBYztBQUc1QyxnQkFBTSxnQkFBZ0IsTUFBTSxXQUFXLFFBQVE7QUFBQSxZQUM3QyxJQUFJLGdCQUFnQixLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUM7QUFBQSxZQUN0RCxNQUFNO0FBQUEsWUFDTixTQUFTLFFBQVEsV0FBVyxVQUFVLElBQUksUUFBUTtBQUFBLFlBQ2xELFNBQVMsRUFBRSxTQUFTLE9BQU8sSUFBSztBQUFBLFlBQ2hDLFdBQVcsS0FBSyxJQUFJO0FBQUEsVUFDdEIsQ0FBQztBQUVELGdCQUFNLFlBQVksbUJBQW1CLE9BQU8sSUFBSSxLQUFLLElBQUksQ0FBQztBQUMxRCxnQkFBTSxRQUFRLElBQUksV0FBVztBQUFBLFlBQzNCO0FBQUEsWUFDQSxTQUFVLGVBQXVCLFdBQVcsQ0FBQztBQUFBLFlBQzdDLE9BQVEsZUFBdUIsU0FBUyxDQUFDO0FBQUEsWUFDekMsWUFBWSxLQUFLLElBQUk7QUFBQSxVQUN2QixDQUFDO0FBR0QsZ0JBQU0sU0FBUyxHQUNaO0FBQUEsWUFDQyxlQUFlLElBQUksR0FBRyxNQUFNLFNBQVMsQ0FBQztBQUFBLFVBQ3hDLEVBQ0MsSUFBSSxPQUFPO0FBRWQsa0JBQVE7QUFBQSxZQUNOLHdDQUF1QixPQUFPLHFEQUN0QixPQUFPLE9BQU8sK0NBQVksU0FBUztBQUFBLFVBQzdDO0FBRUEsaUJBQU87QUFBQSxZQUNMLFNBQVM7QUFBQSxZQUNULGdCQUFnQixPQUFPO0FBQUEsWUFDdkI7QUFBQSxZQUNBLFNBQVMsMERBQWEsT0FBTyxPQUFPLHNEQUFjLFNBQVM7QUFBQSxVQUM3RDtBQUFBLFFBQ0YsU0FBUyxLQUFVO0FBQ2pCLGtCQUFRLE1BQU0sMkNBQXVCLElBQUksT0FBTztBQUNoRCxpQkFBTyxFQUFFLFNBQVMsT0FBTyxPQUFPLElBQUksUUFBUTtBQUFBLFFBQzlDO0FBQUEsTUFDRjtBQUFBLElBQ0YsQ0FBQztBQUVELFlBQVEsSUFBSSx3RkFBaUM7QUFPN0MsVUFBTSxTQUFTLFVBQVUsc0JBQXNCLE9BQU8sVUFBVTtBQUM5RCxZQUFNLFVBQVUsTUFBTTtBQUN0QixZQUFNLFlBQVksU0FBUztBQUMzQixZQUFNLGNBQWMsU0FBUztBQUM3QixVQUFJLENBQUMsVUFBVztBQUVoQixjQUFRO0FBQUEsUUFDTiw2RUFBOEIsZUFBZSxTQUFTO0FBQUEsTUFFeEQ7QUFBQSxJQUNGLENBQUM7QUFHRCxVQUFNLFNBQVMsVUFBVSw4QkFBOEIsT0FBTyxXQUFXO0FBQ3ZFLFVBQUk7QUFDRixjQUFNLFlBQVksTUFBTSxRQUFRLElBQUksb0JBQW9CO0FBQ3hELFlBQUksQ0FBQyxXQUFXLFlBQVksQ0FBQyxXQUFXLFFBQVM7QUFFakQsY0FBTSxFQUFFLFVBQVUsU0FBUyxNQUFNLEtBQUssSUFBSTtBQUcxQyxjQUFNLFdBQVcsUUFBUTtBQUFBLFVBQ3ZCLElBQUksaUJBQWlCLEtBQUssT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLE1BQU0sQ0FBQztBQUFBLFVBQ3ZELE1BQU07QUFBQSxVQUNOLFNBQVMsVUFBVSxJQUFJLFFBQVE7QUFBQSxVQUMvQixTQUFTLEVBQUUsVUFBVSxTQUFTLE1BQU0sS0FBSztBQUFBLFVBQ3pDLFdBQVcsS0FBSyxJQUFJO0FBQUEsUUFDdEIsQ0FBQztBQUVELGdCQUFRLElBQUksb0VBQTBCO0FBQUEsTUFDeEMsUUFBUTtBQUFBLE1BRVI7QUFBQSxJQUNGLENBQUM7QUFNRCxVQUFNLGlCQUFpQixNQUFNLFFBQVEsSUFBSSxRQUFRO0FBQ2pELFFBQUksQ0FBQyxnQkFBZ0I7QUFDbkIsWUFBTSxRQUFRLElBQUksVUFBVTtBQUFBLFFBQzFCLGFBQWE7QUFBQSxRQUNiLGtCQUFrQjtBQUFBLFFBQ2xCLGNBQWM7QUFBQSxRQUNkLGVBQWUsRUFBRSxHQUFHLElBQUksR0FBRyxHQUFHO0FBQUEsUUFDOUIsZUFBZTtBQUFBLE1BQ2pCLENBQUM7QUFDRCxjQUFRLElBQUksNkVBQTJCO0FBQUEsSUFDekM7QUFnREEsWUFBUSxJQUFJLGlFQUF5QjtBQUNyQyxZQUFRLElBQUksb0VBQTBCO0FBQUEsRUFDeEM7QUFBQTtBQUFBLEVBR0EsWUFBWSxZQUFZO0FBQ3RCLFlBQVEsSUFBSSxvSEFBNEM7QUFBQSxFQUMxRDtBQUNGOyIsCiAgIm5hbWVzIjogW10KfQo=
