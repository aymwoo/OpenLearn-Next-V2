// node_modules/uuid/dist/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
}

// node_modules/uuid/dist/rng.js
var rnds8 = new Uint8Array(16);
function rng() {
  return crypto.getRandomValues(rnds8);
}

// node_modules/uuid/dist/v7.js
var _state = {};
function v7(options, buf, offset) {
  let bytes;
  if (options) {
    bytes = v7Bytes(options.random ?? options.rng?.() ?? rng(), options.msecs, options.seq, buf, offset);
  } else {
    const now = Date.now();
    const rnds = rng();
    updateV7State(_state, now, rnds);
    bytes = v7Bytes(rnds, _state.msecs, _state.seq, buf, offset);
  }
  return buf ?? unsafeStringify(bytes);
}
function updateV7State(state, now, rnds) {
  state.msecs ??= -Infinity;
  state.seq ??= 0;
  if (now > state.msecs) {
    state.seq = rnds[6] << 23 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
    state.msecs = now;
  } else {
    state.seq = state.seq + 1 | 0;
    if (state.seq === 0) {
      state.msecs++;
    }
  }
  return state;
}
function v7Bytes(rnds, msecs, seq, buf, offset = 0) {
  if (rnds.length < 16) {
    throw new Error("Random bytes length must be >= 16");
  }
  if (!buf) {
    buf = new Uint8Array(16);
    offset = 0;
  } else {
    if (offset < 0 || offset + 16 > buf.length) {
      throw new RangeError(`UUID byte range ${offset}:${offset + 15} is out of buffer bounds`);
    }
  }
  msecs ??= Date.now();
  seq ??= rnds[6] * 127 << 24 | rnds[7] << 16 | rnds[8] << 8 | rnds[9];
  buf[offset++] = msecs / 1099511627776 & 255;
  buf[offset++] = msecs / 4294967296 & 255;
  buf[offset++] = msecs / 16777216 & 255;
  buf[offset++] = msecs / 65536 & 255;
  buf[offset++] = msecs / 256 & 255;
  buf[offset++] = msecs & 255;
  buf[offset++] = 112 | seq >>> 28 & 15;
  buf[offset++] = seq >>> 20 & 255;
  buf[offset++] = 128 | seq >>> 14 & 63;
  buf[offset++] = seq >>> 6 & 255;
  buf[offset++] = seq << 2 & 255 | rnds[10] & 3;
  buf[offset++] = rnds[11];
  buf[offset++] = rnds[12];
  buf[offset++] = rnds[13];
  buf[offset++] = rnds[14];
  buf[offset++] = rnds[15];
  return buf;
}
var v7_default = v7;

// packages/core/di/errors.ts
var TokenError = class extends Error {
  constructor(message) {
    super(`[Token] ${message}`);
    this.name = "TokenError";
  }
};

// packages/core/di/token.ts
var TOKEN_NAME_RE = /^@[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+:[a-zA-Z0-9_]+$/;
var Token = class {
  constructor(name, version = "1.0.0") {
    if (!name || typeof name !== "string") {
      throw new TokenError(
        `Token name must be a non-empty string, got: ${String(name)}`
      );
    }
    if (!TOKEN_NAME_RE.test(name)) {
      throw new TokenError(
        `Invalid Token name format: "${name}". Expected: @scope/domain:ServiceName`
      );
    }
    this.name = name;
    this.version = version;
  }
};

// packages/core/di/interfaces.ts
var ICommandBusServiceToken = new Token(
  "@openlearn/core:ICommandBusService"
);
var IEventBusServiceToken = new Token(
  "@openlearn/core:IEventBusService"
);
var IActionRegistryServiceToken = new Token(
  "@openlearn/core:IActionRegistryService"
);
var ICapabilityServiceToken = new Token(
  "@openlearn/core:ICapabilityService"
);
var IProcessServiceToken = new Token(
  "@openlearn/core:IProcessService"
);
var IStorageServiceToken = new Token(
  "@openlearn/core:IStorageService"
);
var IAIServiceToken = new Token(
  "@openlearn/core:IAIService"
);
var IDatabaseToken = new Token(
  "@openlearn/core:IDatabase"
);
var IPluginHostToken = new Token(
  "@openlearn/core:IPluginHost"
);
var ISemesterGradeServiceToken = new Token(
  "@openlearn/core:ISemesterGradeService"
);

// packages/plugins/ext-student-groups/index.ts
var GROUPS_TABLE = "";
var MEMBERS_TABLE = "";
var _db = null;
async function getDb(ctx) {
  if (!_db) {
    _db = await ctx.resolve(IDatabaseToken);
  }
  return _db;
}
var index_default = {
  manifest: {
    id: "ext-student-groups",
    name: "\u5B66\u751F\u5206\u7EC4\u7BA1\u7406",
    version: "1.0.0",
    main: "index.js",
    description: "\u5B66\u751F\u5206\u7EC4\u7BA1\u7406\uFF0C\u652F\u6301\u81EA\u5EFA\u5C0F\u7EC4/\u8001\u5E08\u5206\u914D/\u81EA\u52A8\u5206\u7EC4/\u7EC4\u957F\u4EFB\u547D",
    author: "Edu-OS \u63D2\u4EF6\u751F\u6001\u793E\u533A",
    requires: [
      "@openlearn/core:ICommandBusService@^1.0.0",
      "@openlearn/core:IActionRegistryService@^1.0.0",
      "@openlearn/core:IEventBusService@^1.0.0",
      "@openlearn/core:IDatabase@^1.0.0",
      "@openlearn/core:IStorageService@^1.0.0"
    ],
    capabilitiesProposed: ["management:read", "management:write"],
    classroomTools: [
      {
        id: "tool-group-create",
        name: "\u521B\u5EFA\u5C0F\u7EC4",
        icon: "Users",
        description: "\u5728\u5F53\u524D\u73ED\u7EA7\u4E2D\u624B\u52A8\u521B\u5EFA\u4E00\u4E2A\u65B0\u7684\u5B66\u751F\u5C0F\u7EC4",
        commandType: "group.create",
        payload: { classId: "$classId", name: "", description: "\u6559\u5E08\u624B\u52A8\u521B\u5EFA" }
      },
      {
        id: "tool-group-auto-assign",
        name: "\u81EA\u52A8\u5206\u7EC4",
        icon: "Shuffle",
        description: "\u5C06\u5F53\u524D\u73ED\u7EA7\u5B66\u751F\u968F\u673A\u81EA\u52A8\u5206\u914D\u5230\u5C0F\u7EC4",
        commandType: "group.auto_assign",
        payload: { classId: "$classId", groupCount: 4, strategy: "random" }
      },
      {
        id: "tool-group-list",
        name: "\u67E5\u770B\u5206\u7EC4",
        icon: "List",
        description: "\u67E5\u770B\u5F53\u524D\u73ED\u7EA7\u6240\u6709\u5C0F\u7EC4\u53CA\u6210\u5458",
        commandType: "group.list",
        payload: { classId: "$classId" }
      }
    ]
  },
  activate: async (ctx) => {
    const commandBus = ctx.services.commandBus;
    const actionRegistry = ctx.services.actionRegistry;
    const eventBus = ctx.services.eventBus;
    GROUPS_TABLE = ctx.db.table("student_groups");
    MEMBERS_TABLE = ctx.db.table("student_group_members");
    await ctx.db.ensureTable("student_groups", [
      "id TEXT PRIMARY KEY",
      "class_id TEXT NOT NULL",
      "name TEXT NOT NULL",
      "description TEXT DEFAULT ''",
      "created_by TEXT NOT NULL",
      "created_by_name TEXT DEFAULT ''",
      "created_at INTEGER NOT NULL"
    ].join(", "));
    await ctx.db.ensureTable("student_group_members", [
      "group_id TEXT NOT NULL",
      "student_id TEXT NOT NULL",
      "student_name TEXT DEFAULT ''",
      "role TEXT NOT NULL DEFAULT 'member'",
      "joined_at INTEGER NOT NULL",
      "PRIMARY KEY (group_id, student_id)"
    ].join(", "));
    console.log(`[ext-student-groups] Tables created: ${GROUPS_TABLE}, ${MEMBERS_TABLE}`);
    await actionRegistry.register({
      id: "ext-student-groups-create",
      commandType: "group.create",
      description: "\u521B\u5EFA\u4E00\u4E2A\u65B0\u7684\u5B66\u751F\u5C0F\u7EC4\u3002\u5B66\u751F\u53EF\u81EA\u884C\u521B\u5EFA\uFF08\u81EA\u5DF1\u81EA\u52A8\u52A0\u5165\uFF09\uFF0C\u6559\u5E08\u53EF\u4E3A\u73ED\u7EA7\u521B\u5EFA\u5C0F\u7EC4\u3002",
      capabilityRequired: "management:write",
      inputSchema: {
        type: "OBJECT",
        properties: {
          classId: { type: "STRING", description: "\u73ED\u7EA7 ID" },
          name: { type: "STRING", description: '\u5C0F\u7EC4\u540D\u79F0\uFF08\u5982 "\u7B2C\u4E00\u7EC4"\u3001"\u6570\u5B66\u5174\u8DA3\u7EC4"\uFF09' },
          description: { type: "STRING", description: "\u5C0F\u7EC4\u63CF\u8FF0\uFF08\u53EF\u9009\uFF09" }
        },
        required: ["classId", "name"]
      }
    });
    await commandBus.registerHandler("group.create", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const actorId = command.actorId || "system";
        const groupId = v7_default();
        const now = Date.now();
        let createdByName = actorId;
        if (actorId.startsWith("student:")) {
          const studentId = actorId.replace("student:", "");
          const student = db.prepare("SELECT name FROM students WHERE id = ?").get(studentId);
          if (student) createdByName = student.name;
        } else if (actorId.startsWith("user:")) {
          const userId = actorId.replace("user:", "");
          const user = db.prepare("SELECT name FROM users WHERE id = ?").get(userId);
          if (user) createdByName = user.name;
        }
        db.prepare(
          `INSERT INTO ${GROUPS_TABLE} (id, class_id, name, description, created_by, created_by_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`
        ).run(groupId, payload.classId, payload.name, payload.description || "", actorId, createdByName, now);
        await eventBus.publish({
          id: v7_default(),
          type: "group.created",
          source: "ext-student-groups",
          payload: { groupId, classId: payload.classId, name: payload.name, createdBy: actorId },
          timestamp: now,
          correlationId: command.id
        });
        return { success: true, groupId, name: payload.name };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-join",
      commandType: "group.join",
      description: "\u5B66\u751F\u52A0\u5165\u6307\u5B9A\u7684\u5DF2\u6709\u5C0F\u7EC4",
      capabilityRequired: "management:write",
      inputSchema: {
        type: "OBJECT",
        properties: {
          groupId: { type: "STRING", description: "\u8981\u52A0\u5165\u7684\u5C0F\u7EC4 ID" },
          studentId: { type: "STRING", description: "\u5B66\u751F\u7684 ID" },
          studentName: { type: "STRING", description: "\u5B66\u751F\u59D3\u540D\uFF08\u53EF\u9009\uFF0C\u81EA\u52A8\u4ECE\u6570\u636E\u5E93\u83B7\u53D6\uFF09" }
        },
        required: ["groupId", "studentId"]
      }
    });
    await commandBus.registerHandler("group.join", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const now = Date.now();
        const group = db.prepare(`SELECT * FROM ${GROUPS_TABLE} WHERE id = ?`).get(payload.groupId);
        if (!group) {
          throw new Error(`\u5C0F\u7EC4 ${payload.groupId} \u4E0D\u5B58\u5728`);
        }
        let studentName = payload.studentName || "";
        if (!studentName) {
          const student = db.prepare("SELECT name FROM students WHERE id = ?").get(payload.studentId);
          if (student) studentName = student.name;
        }
        const existing = db.prepare(
          `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? AND student_id = ?`
        ).get(payload.groupId, payload.studentId);
        if (existing) {
          throw new Error(`\u5B66\u751F ${studentName || payload.studentId} \u5DF2\u5728\u8BE5\u5C0F\u7EC4\u4E2D`);
        }
        const otherGroup = db.prepare(`
          SELECT m.* FROM ${MEMBERS_TABLE} m
          JOIN ${GROUPS_TABLE} g ON m.group_id = g.id
          WHERE m.student_id = ? AND g.class_id = ?
        `).get(payload.studentId, group.class_id);
        if (otherGroup) {
          db.prepare(`DELETE FROM ${MEMBERS_TABLE} WHERE group_id = ? AND student_id = ?`).run(
            otherGroup.group_id,
            payload.studentId
          );
        }
        const memberCount = db.prepare(
          `SELECT COUNT(*) as count FROM ${MEMBERS_TABLE} WHERE group_id = ?`
        ).get(payload.groupId);
        const role = memberCount.count === 0 ? "leader" : "member";
        db.prepare(
          `INSERT INTO ${MEMBERS_TABLE} (group_id, student_id, student_name, role, joined_at) VALUES (?, ?, ?, ?, ?)`
        ).run(payload.groupId, payload.studentId, studentName, role, now);
        await eventBus.publish({
          id: v7_default(),
          type: "group.member_joined",
          source: "ext-student-groups",
          payload: {
            groupId: payload.groupId,
            classId: group.class_id,
            studentId: payload.studentId,
            studentName,
            role
          },
          timestamp: now,
          correlationId: command.id
        });
        return {
          success: true,
          groupId: payload.groupId,
          studentId: payload.studentId,
          studentName,
          role,
          message: `\u5B66\u751F ${studentName || payload.studentId} \u5DF2\u52A0\u5165\u5C0F\u7EC4\u300C${group.name}\u300D${role === "leader" ? "\uFF0C\u5E76\u81EA\u52A8\u6210\u4E3A\u7EC4\u957F" : ""}`
        };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-leave",
      commandType: "group.leave",
      description: "\u5B66\u751F\u9000\u51FA\u5F53\u524D\u6240\u5728\u5C0F\u7EC4",
      capabilityRequired: "management:write",
      inputSchema: {
        type: "OBJECT",
        properties: {
          groupId: { type: "STRING", description: "\u5C0F\u7EC4 ID" },
          studentId: { type: "STRING", description: "\u5B66\u751F ID" }
        },
        required: ["groupId", "studentId"]
      }
    });
    await commandBus.registerHandler("group.leave", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const now = Date.now();
        const member = db.prepare(
          `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? AND student_id = ?`
        ).get(payload.groupId, payload.studentId);
        if (!member) {
          throw new Error("\u8BE5\u5B66\u751F\u4E0D\u5728\u8BE5\u5C0F\u7EC4\u4E2D");
        }
        db.prepare(`DELETE FROM ${MEMBERS_TABLE} WHERE group_id = ? AND student_id = ?`).run(
          payload.groupId,
          payload.studentId
        );
        if (member.role === "leader") {
          const nextMember = db.prepare(
            `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? ORDER BY joined_at ASC LIMIT 1`
          ).get(payload.groupId);
          if (nextMember) {
            db.prepare(`UPDATE ${MEMBERS_TABLE} SET role = 'leader' WHERE group_id = ? AND student_id = ?`).run(
              payload.groupId,
              nextMember.student_id
            );
          }
        }
        await eventBus.publish({
          id: v7_default(),
          type: "group.member_left",
          source: "ext-student-groups",
          payload: { groupId: payload.groupId, studentId: payload.studentId, wasLeader: member.role === "leader" },
          timestamp: now,
          correlationId: command.id
        });
        return { success: true, message: "\u5DF2\u9000\u51FA\u5C0F\u7EC4" };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-assign-leader",
      commandType: "group.assign_leader",
      description: "\u4EFB\u547D\u6307\u5B9A\u5B66\u751F\u4E3A\u5C0F\u7EC4\u7EC4\u957F\uFF08\u539F\u7EC4\u957F\u964D\u4E3A\u666E\u901A\u6210\u5458\uFF09",
      capabilityRequired: "management:write",
      inputSchema: {
        type: "OBJECT",
        properties: {
          groupId: { type: "STRING", description: "\u5C0F\u7EC4 ID" },
          studentId: { type: "STRING", description: "\u8981\u4EFB\u547D\u4E3A\u7EC4\u957F\u7684\u5B66\u751F ID" }
        },
        required: ["groupId", "studentId"]
      }
    });
    await commandBus.registerHandler("group.assign_leader", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const now = Date.now();
        const member = db.prepare(
          `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? AND student_id = ?`
        ).get(payload.groupId, payload.studentId);
        if (!member) {
          throw new Error("\u8BE5\u5B66\u751F\u4E0D\u5728\u8BE5\u5C0F\u7EC4\u4E2D");
        }
        db.prepare(`UPDATE ${MEMBERS_TABLE} SET role = 'member' WHERE group_id = ?`).run(payload.groupId);
        db.prepare(`UPDATE ${MEMBERS_TABLE} SET role = 'leader' WHERE group_id = ? AND student_id = ?`).run(
          payload.groupId,
          payload.studentId
        );
        const group = db.prepare(`SELECT name FROM ${GROUPS_TABLE} WHERE id = ?`).get(payload.groupId);
        await eventBus.publish({
          id: v7_default(),
          type: "group.leader_assigned",
          source: "ext-student-groups",
          payload: { groupId: payload.groupId, studentId: payload.studentId, studentName: member.student_name },
          timestamp: now,
          correlationId: command.id
        });
        return {
          success: true,
          message: `\u5DF2\u5C06 ${member.student_name || payload.studentId} \u4EFB\u547D\u4E3A\u5C0F\u7EC4\u300C${group?.name || payload.groupId}\u300D\u7684\u7EC4\u957F`
        };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-auto-assign",
      commandType: "group.auto_assign",
      description: "\u81EA\u52A8\u5C06\u73ED\u7EA7\u4E2D\u7684\u6240\u6709\u5B66\u751F\u968F\u673A\u5206\u914D\u5230\u6307\u5B9A\u6570\u91CF\u7684\u5C0F\u7EC4\u3002\u53EF\u9009\u6E05\u7A7A\u73B0\u6709\u5206\u7EC4\u540E\u91CD\u65B0\u5206\u914D\u3002",
      capabilityRequired: "management:write",
      isHighRisk: true,
      inputSchema: {
        type: "OBJECT",
        properties: {
          classId: { type: "STRING", description: "\u73ED\u7EA7 ID" },
          groupCount: { type: "INTEGER", description: "\u5206\u7EC4\u6570\u91CF\uFF08\u9ED8\u8BA4 4 \u7EC4\uFF09" },
          strategy: { type: "STRING", description: "\u5206\u914D\u7B56\u7565\uFF1Arandom\uFF08\u968F\u673A\uFF09\u6216 balanced\uFF08\u5747\u8861\uFF09\uFF08\u53EF\u9009\uFF0C\u9ED8\u8BA4 random\uFF09" },
          clearExisting: { type: "BOOLEAN", description: "\u662F\u5426\u6E05\u7A7A\u8BE5\u73ED\u7EA7\u73B0\u6709\u5206\u7EC4\u540E\u91CD\u65B0\u5206\u914D\uFF08\u53EF\u9009\uFF0C\u9ED8\u8BA4 true\uFF09" }
        },
        required: ["classId"]
      }
    });
    await commandBus.registerHandler("group.auto_assign", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const now = Date.now();
        const groupCount = payload.groupCount || 4;
        const strategy = payload.strategy || "random";
        const clearExisting = payload.clearExisting !== false;
        let students = [];
        try {
          const result = await commandBus.execute({
            id: v7_default(),
            type: "class.get_students",
            actorId: "plugin-ext-student-groups",
            payload: { classId: payload.classId },
            timestamp: Date.now()
          });
          if (result && result.students) {
            students = result.students;
          }
        } catch (e) {
          console.error("[ext-student-groups] \u83B7\u53D6\u73ED\u7EA7\u5B66\u751F\u5931\u8D25:", e);
          throw new Error("\u65E0\u6CD5\u83B7\u53D6\u73ED\u7EA7\u5B66\u751F\u5217\u8868");
        }
        if (students.length === 0) {
          throw new Error("\u8BE5\u73ED\u7EA7\u4E2D\u6CA1\u6709\u5B66\u751F\uFF0C\u65E0\u6CD5\u5206\u7EC4");
        }
        if (groupCount > students.length) {
          throw new Error(`\u5206\u7EC4\u6570\u91CF\uFF08${groupCount}\uFF09\u4E0D\u80FD\u8D85\u8FC7\u5B66\u751F\u4EBA\u6570\uFF08${students.length}\uFF09`);
        }
        if (groupCount < 1) {
          throw new Error("\u5206\u7EC4\u6570\u91CF\u81F3\u5C11\u4E3A 1");
        }
        if (clearExisting) {
          const oldGroups = db.prepare(`SELECT id FROM ${GROUPS_TABLE} WHERE class_id = ?`).all(payload.classId);
          for (const g of oldGroups) {
            db.prepare(`DELETE FROM ${MEMBERS_TABLE} WHERE group_id = ?`).run(g.id);
          }
          db.prepare(`DELETE FROM ${GROUPS_TABLE} WHERE class_id = ?`).run(payload.classId);
        }
        const shuffled = [...students];
        for (let i = shuffled.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        const groupIds = [];
        const groupNames = [];
        for (let i = 0; i < groupCount; i++) {
          const groupId = v7_default();
          const groupName = `\u7B2C${i + 1}\u7EC4`;
          groupIds.push(groupId);
          groupNames.push(groupName);
          db.prepare(
            `INSERT INTO ${GROUPS_TABLE} (id, class_id, name, description, created_by, created_by_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)`
          ).run(groupId, payload.classId, groupName, "\u7CFB\u7EDF\u81EA\u52A8\u5206\u7EC4", "system", "\u7CFB\u7EDF\u81EA\u52A8\u5206\u914D", now);
        }
        const assignments = [];
        for (let i = 0; i < shuffled.length; i++) {
          const groupIndex = i % groupCount;
          const student = shuffled[i];
          const isFirstInGroup = i < groupCount;
          const role = isFirstInGroup ? "leader" : "member";
          db.prepare(
            `INSERT INTO ${MEMBERS_TABLE} (group_id, student_id, student_name, role, joined_at) VALUES (?, ?, ?, ?, ?)`
          ).run(groupIds[groupIndex], student.id, student.name, role, now);
          assignments.push({
            groupId: groupIds[groupIndex],
            groupName: groupNames[groupIndex],
            studentId: student.id,
            studentName: student.name,
            isLeader: isFirstInGroup
          });
        }
        await eventBus.publish({
          id: v7_default(),
          type: "group.auto_assigned",
          source: "ext-student-groups",
          payload: {
            classId: payload.classId,
            groupCount,
            studentCount: students.length,
            strategy
          },
          timestamp: now,
          correlationId: command.id
        });
        return {
          success: true,
          groupCount,
          studentCount: students.length,
          strategy,
          groups: groupIds.map((id, i) => ({ id, name: groupNames[i] })),
          assignments: assignments.map((a) => ({
            groupName: a.groupName,
            studentName: a.studentName,
            isLeader: a.isLeader
          })),
          message: `\u5DF2\u5C06 ${students.length} \u540D\u5B66\u751F\u968F\u673A\u5206\u914D\u5230 ${groupCount} \u4E2A\u5C0F\u7EC4`
        };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-list",
      commandType: "group.list",
      description: "\u5217\u51FA\u6307\u5B9A\u73ED\u7EA7\u7684\u6240\u6709\u5C0F\u7EC4\u53CA\u5176\u6210\u5458",
      capabilityRequired: "management:read",
      inputSchema: {
        type: "OBJECT",
        properties: {
          classId: { type: "STRING", description: "\u73ED\u7EA7 ID" }
        },
        required: ["classId"]
      }
    });
    await commandBus.registerHandler("group.list", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const groups = db.prepare(
          `SELECT * FROM ${GROUPS_TABLE} WHERE class_id = ? ORDER BY created_at ASC`
        ).all(payload.classId);
        const result = [];
        for (const group of groups) {
          const members = db.prepare(
            `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? ORDER BY role DESC, joined_at ASC`
          ).all(group.id);
          result.push({ ...group, members, memberCount: members.length });
        }
        return { success: true, classId: payload.classId, groups: result, totalGroups: result.length };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-get-members",
      commandType: "group.get_members",
      description: "\u83B7\u53D6\u6307\u5B9A\u5C0F\u7EC4\u7684\u6240\u6709\u6210\u5458\u4FE1\u606F",
      capabilityRequired: "management:read",
      inputSchema: {
        type: "OBJECT",
        properties: {
          groupId: { type: "STRING", description: "\u5C0F\u7EC4 ID" }
        },
        required: ["groupId"]
      }
    });
    await commandBus.registerHandler("group.get_members", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const group = db.prepare(`SELECT * FROM ${GROUPS_TABLE} WHERE id = ?`).get(payload.groupId);
        if (!group) {
          throw new Error(`\u5C0F\u7EC4 ${payload.groupId} \u4E0D\u5B58\u5728`);
        }
        const members = db.prepare(
          `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? ORDER BY role DESC, joined_at ASC`
        ).all(payload.groupId);
        return { success: true, group, members, memberCount: members.length };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-delete",
      commandType: "group.delete",
      description: "\u5220\u9664\u6307\u5B9A\u5C0F\u7EC4\u53CA\u5176\u6240\u6709\u6210\u5458\u5173\u7CFB\uFF08\u9AD8\u98CE\u9669\u64CD\u4F5C\uFF09",
      capabilityRequired: "management:write",
      isHighRisk: true,
      inputSchema: {
        type: "OBJECT",
        properties: {
          groupId: { type: "STRING", description: "\u8981\u5220\u9664\u7684\u5C0F\u7EC4 ID" }
        },
        required: ["groupId"]
      }
    });
    await commandBus.registerHandler("group.delete", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const now = Date.now();
        const group = db.prepare(`SELECT * FROM ${GROUPS_TABLE} WHERE id = ?`).get(payload.groupId);
        if (!group) {
          throw new Error(`\u5C0F\u7EC4 ${payload.groupId} \u4E0D\u5B58\u5728`);
        }
        db.prepare(`DELETE FROM ${MEMBERS_TABLE} WHERE group_id = ?`).run(payload.groupId);
        db.prepare(`DELETE FROM ${GROUPS_TABLE} WHERE id = ?`).run(payload.groupId);
        await eventBus.publish({
          id: v7_default(),
          type: "group.deleted",
          source: "ext-student-groups",
          payload: { groupId: payload.groupId, classId: group.class_id, name: group.name },
          timestamp: now,
          correlationId: command.id
        });
        return { success: true, message: `\u5C0F\u7EC4\u300C${group.name}\u300D\u5DF2\u5220\u9664` };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-kick",
      commandType: "group.kick",
      description: "\u5C06\u6307\u5B9A\u5B66\u751F\u4ECE\u5C0F\u7EC4\u4E2D\u79FB\u9664\uFF08\u8E22\u51FA\uFF09",
      capabilityRequired: "management:write",
      inputSchema: {
        type: "OBJECT",
        properties: {
          groupId: { type: "STRING", description: "\u5C0F\u7EC4 ID" },
          studentId: { type: "STRING", description: "\u8981\u79FB\u9664\u7684\u5B66\u751F ID" }
        },
        required: ["groupId", "studentId"]
      }
    });
    await commandBus.registerHandler("group.kick", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const now = Date.now();
        const member = db.prepare(
          `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? AND student_id = ?`
        ).get(payload.groupId, payload.studentId);
        if (!member) {
          throw new Error("\u8BE5\u5B66\u751F\u4E0D\u5728\u8BE5\u5C0F\u7EC4\u4E2D");
        }
        db.prepare(`DELETE FROM ${MEMBERS_TABLE} WHERE group_id = ? AND student_id = ?`).run(
          payload.groupId,
          payload.studentId
        );
        if (member.role === "leader") {
          const nextMember = db.prepare(
            `SELECT * FROM ${MEMBERS_TABLE} WHERE group_id = ? ORDER BY joined_at ASC LIMIT 1`
          ).get(payload.groupId);
          if (nextMember) {
            db.prepare(`UPDATE ${MEMBERS_TABLE} SET role = 'leader' WHERE group_id = ? AND student_id = ?`).run(
              payload.groupId,
              nextMember.student_id
            );
          }
        }
        await eventBus.publish({
          id: v7_default(),
          type: "group.member_kicked",
          source: "ext-student-groups",
          payload: { groupId: payload.groupId, studentId: payload.studentId, studentName: member.student_name },
          timestamp: now,
          correlationId: command.id
        });
        return { success: true, message: `\u5DF2\u5C06 ${member.student_name || payload.studentId} \u4ECE\u5C0F\u7EC4\u4E2D\u79FB\u9664` };
      }
    });
    await actionRegistry.register({
      id: "ext-student-groups-get-student-group",
      commandType: "group.get_student_group",
      description: "\u67E5\u8BE2\u6307\u5B9A\u5B66\u751F\u5728\u67D0\u4E2A\u73ED\u7EA7\u4E2D\u6240\u5C5E\u7684\u5C0F\u7EC4",
      capabilityRequired: "management:read",
      inputSchema: {
        type: "OBJECT",
        properties: {
          classId: { type: "STRING", description: "\u73ED\u7EA7 ID" },
          studentId: { type: "STRING", description: "\u5B66\u751F ID" }
        },
        required: ["classId", "studentId"]
      }
    });
    await commandBus.registerHandler("group.get_student_group", {
      async execute(command) {
        const payload = command.payload;
        const db = await getDb(ctx);
        const memberRow = db.prepare(`
          SELECT m.*, g.name as group_name, g.description as group_description
          FROM ${MEMBERS_TABLE} m
          JOIN ${GROUPS_TABLE} g ON m.group_id = g.id
          WHERE m.student_id = ? AND g.class_id = ?
        `).get(payload.studentId, payload.classId);
        if (!memberRow) {
          return { success: true, group: null, message: "\u8BE5\u5B66\u751F\u5C1A\u672A\u52A0\u5165\u4EFB\u4F55\u5C0F\u7EC4" };
        }
        return {
          success: true,
          group: {
            groupId: memberRow.group_id,
            groupName: memberRow.group_name,
            groupDescription: memberRow.group_description,
            role: memberRow.role,
            joinedAt: memberRow.joined_at
          }
        };
      }
    });
    console.log("[ext-student-groups] \u5B66\u751F\u5206\u7EC4\u7BA1\u7406\u63D2\u4EF6\u5DF2\u6FC0\u6D3B\uFF0810 \u6761\u547D\u4EE4\u5DF2\u6CE8\u518C\uFF09");
  }
};
export {
  index_default as default
};
